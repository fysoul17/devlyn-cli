# Generated criteria — CLI `version --format json`

## Requirements

- `bin/cli.js`'s `version` subcommand accepts a new `--format json` option; when passed, it prints valid JSON `{"version":"<x.y.z>"}` on a single line to stdout (the version value matches `package.json`'s `version` field).
- Without `--format`, `version` keeps printing the current bare version string exactly as before (no behavior change).
- `--format yaml`, or any other unsupported `--format` value, causes `version` to exit with a non-zero status (1) and print an error; it must not print the bare version string or a JSON object.
- `tests/cli.test.js` gets at least one new test covering the `--format json` path.
- All existing tests in `tests/cli.test.js` continue to pass unmodified in behavior.

## Constraints

- Only `bin/cli.js` and `tests/cli.test.js` may be touched.
- No new npm dependencies (no `package.json`/`package-lock.json` changes).
- Code unrelated to the `version --format` feature — including comments, formatting, the `hello` subcommand, and the unused `parseGreetingFormat` helper — must remain exactly as-is (byte-for-byte on untouched lines).

## Out of Scope

- Any subcommand other than `version` (e.g. `hello`, `--help`).
- Refactoring, cleanup, or reformatting of code not required to implement `--format json`.

<!-- devlyn:verification -->
## Verification

```json
{
  "verification_commands": [
    {"cmd": "node bin/cli.js version", "exit_code": 0, "stdout_contains": ["0.1.0"], "stdout_not_contains": ["{"]},
    {"cmd": "node bin/cli.js version --format json", "exit_code": 0, "stdout_contains": ["{\"version\":\"0.1.0\"}"]},
    {"cmd": "node bin/cli.js version --format yaml", "exit_code": 1},
    {"cmd": "node --test tests/cli.test.js", "exit_code": 0}
  ]
}
```
