# Plan — CLI `version --format json`

<!-- devlyn:authorized-surface -->
## Files to touch

- `bin/cli.js` — edit. In the `case 'version':` block (bin/cli.js:59-62), add parsing of a `--format` flag from `rest` (the args after `version`). Requirement: no `--format` → keep `console.log(readPackageVersion())` unchanged (bin/cli.js:60, Requirement "Without `--format` ... no behavior change"). `--format json` → print `{"version":"<x.y.z>"}` as a single line to stdout (Requirement "prints valid JSON ... on a single line"). Any other `--format` value (including `yaml` or a missing value) → print an error to stderr and `process.exit(1)`, without printing the bare version or a JSON object (Requirement "`--format yaml`, or any other unsupported `--format` value ... exit ... 1"). New parsing logic follows the existing `parseNameFlag` style (bin/cli.js:33-42) for consistency with the file's established flag-parsing convention.
- `tests/cli.test.js` — edit. Add at least one new `test(...)` block covering `version --format json` (Requirement "gets at least one new test covering the `--format json` path"), asserting stdout is exactly `{"version":"<pkg version>"}`. The three existing tests (tests/cli.test.js:12-25) are left byte-for-byte unchanged (Requirement "All existing tests ... continue to pass unmodified in behavior").

```json
{"authorized_surface": ["bin/cli.js", "tests/cli.test.js"]}
```

## Risks

- **Out of scope, do not touch**: the unused `parseGreetingFormat` helper (bin/cli.js:29-31) and its TODO comment, the `hello` subcommand and its own TODO comment (bin/cli.js:54), and `USAGE` (bin/cli.js:8-19) stay byte-for-byte unchanged — no requirement touches them, and the criteria's Out-of-Scope section names `hello` and unrelated refactoring explicitly.
- **Missing `--format` value** (e.g. `version --format` with nothing after it) is not covered by any verification command or Requirement line. Resolve strictly per Requirement 3's literal wording — "any other unsupported `--format` value" — by treating "no value present" as not equal to `json` and therefore an error+exit 1, not a crash and not silent fallback to bare-version. This is the only interpretation consistent with "No silent fallbacks" (CLAUDE.md Error Handling Philosophy) and requires no extra branch beyond the json-vs-not-json check.
- **`--format=json` (equals-sign form)**: out of scope. No Requirement, verification command, or existing convention (parseNameFlag only supports space-separated `--name value`) calls for it; adding it would be speculative robustness for an unobserved case.
- **Error message text**: Requirement 3 only says "print an error" — no literal string is mandated and no verification command checks stderr content. Do not over-specify; any non-empty, accurate stderr message satisfies the contract. Do not silently match/replicate the `--name requires a value` phrasing unless it fits naturally — no requirement ties the two messages together.
- **JSON construction**: build via a plain template literal (`` `{"version":"${version}"}` ``) or `JSON.stringify({version})`, both zero-dependency and matching "No new npm dependencies." `JSON.stringify` is the standard-library primitive (CLAUDE.md "Best practice — use standard primitives") and guarantees valid JSON escaping without hand-rolling string concatenation, so it is the preferred implementation choice for IMPLEMENT.
- **Refusal**: no restructuring of `main()`'s switch statement, no new top-level helper beyond what's needed to keep the `version` case readable, no touching `hello`/`--help`/default branches. Any temptation to "also clean up" `parseNameFlag` or extract a shared flag-parsing utility is refused — not requested, and the existing two flag parsers (`--name`, `--format`) are small enough that a shared abstraction has no cited failure mode to justify it.

## Acceptance restatement

Verbatim from `.devlyn/criteria.generated.md` `## Verification`:

```json
{
  "verification_commands": [
    {"cmd": "node bin/cli.js version", "exit_code": 0, "stdout_contains": ["0.1.0"], "stdout_not_contains": ["{"]},
    {"cmd": "node bin/cli.js version --format json", "exit_code": 0, "stdout_contains": ["{\"version\":\"0.1.0\"}"]},
    {"cmd": "node bin/cli.js version --format yaml", "exit_code": 1},
    {"cmd": "node --test tests/cli.test.js", "exit_code": 0}
  ]
}
```
