# Generated criteria — version --format json

## Requirements

- The `version` subcommand in `bin/cli.js` supports a `--format json` flag; when passed, stdout is exactly one line of valid JSON: `{"version":"<x.y.z>"}`, where `<x.y.z>` is the version read from `package.json`.
- Without `--format`, `version` keeps printing the bare version string exactly as today (unchanged `console.log(readPackageVersion())` behavior).
- `--format yaml`, or any `--format` value other than `json`, makes the CLI exit with code 1 and print an error.
- All existing tests in `tests/cli.test.js` continue to pass.
- `tests/cli.test.js` gains at least one new test exercising the `version --format json` path.

## Constraints

- Only `bin/cli.js` and `tests/cli.test.js` may be modified.
- No new npm dependencies — `package.json` `dependencies`/`devDependencies` must not change.
- Code unrelated to the version/`--format` feature — including existing comments and formatting in `bin/cli.js` (e.g. the `hello` command, `parseGreetingFormat`, `parseNameFlag`, `USAGE` text) — must remain byte-for-byte unchanged.

## Out of Scope

- The `hello` subcommand and the unused `parseGreetingFormat` helper (already flagged in-code as leftover/out of scope) — do not modify.
- `--help` / `-h` output.
- Any refactor or cleanup of code not required by the `--format json` feature.

<!-- devlyn:verification -->
## Verification

```json
{
  "verification_commands": [
    {"cmd": "npm test", "exit_code": 0},
    {"cmd": "node bin/cli.js version --format json", "exit_code": 0, "stdout_contains": ["{\"version\":\"0.1.0\"}"]},
    {"cmd": "node bin/cli.js version", "exit_code": 0, "stdout_contains": ["0.1.0"], "stdout_not_contains": ["{"]},
    {"cmd": "node bin/cli.js version --format yaml", "exit_code": 1}
  ]
}
```
