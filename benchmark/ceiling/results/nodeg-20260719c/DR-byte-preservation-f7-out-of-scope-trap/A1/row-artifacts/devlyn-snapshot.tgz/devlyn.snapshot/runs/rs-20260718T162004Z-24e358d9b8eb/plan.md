# Plan — version --format json

<!-- devlyn:authorized-surface -->
## Files to touch

- `bin/cli.js` — edit. The `case 'version':` block (currently `bin/cli.js:59-62`, body `console.log(readPackageVersion());`) must branch on a `--format` flag read from `rest` (the `version` subcommand's argv tail, per the existing `[command, ...rest] = argv` destructuring at `bin/cli.js:45`): no `--format` → unchanged `console.log(readPackageVersion())` (Requirement: "Without `--format`, `version` keeps printing the bare version string exactly as today"); `--format json` → `console.log` a single-line JSON string `{"version":"<x.y.z>"}` (Requirement: "stdout is exactly one line of valid JSON"); any other `--format` value → print an error and `process.exit(1)` (Requirement: "`--format yaml`, or any `--format` value other than `json`, makes the CLI exit with code 1 and print an error").
- `tests/cli.test.js` — edit. Add at least one new `test(...)` exercising `version --format json` (Requirement: "`tests/cli.test.js` gains at least one new test exercising the `version --format json` path"). Existing three tests (`hello default`, `hello with --name`, `version prints package version`, lines 12-25) stay as-is — extension only, per "All existing tests in `tests/cli.test.js` continue to pass."

```json
{"authorized_surface": ["bin/cli.js", "tests/cli.test.js"]}
```

## Risks

- **Flag-parsing convention**: the codebase's existing flag reader (`parseNameFlag`, `bin/cli.js:33-42`) parses `--name` as two separate argv tokens via `argv.indexOf('--name')` + next element — it does not support `--flag=value` syntax. The new `--format` flag must follow the same convention (`--format json` as two tokens) for consistency; `--format=json` is not a stated requirement and must not be silently special-cased in.
- **Do not touch out-of-scope code**: `hello` case, `parseGreetingFormat` (unused, explicitly flagged leftover), `parseNameFlag`, `USAGE` text, and all comments/formatting elsewhere in `bin/cli.js` must remain byte-for-byte unchanged (Constraint). `--help`/`-h` output is out of scope (Out of Scope) — do not alter `USAGE` or the no-command branch.
- **No new abstraction beyond what's needed**: the format check is a single flag with two valid states (absent, `json`) plus a reject-everything-else branch. This does not warrant a new top-level helper function mirroring `parseGreetingFormat`/`parseNameFlag` unless reused elsewhere in this file — it is used exactly once, inline in the `version` case, keeping the diff minimal (Subtractive-first / No-overengineering).
- **Exact stdout shape**: `{"version":"<x.y.z>"}` must be the literal JSON shape — key `version`, no extra whitespace/keys, one line. `JSON.stringify({ version: readPackageVersion() })` produces exactly this with no pretty-printing. The bare-version path's stdout must contain no `{` character (verification: `stdout_not_contains: ["{"]`), which is automatically satisfied since that branch is untouched (`console.log(readPackageVersion())`).
- **Error path exit code**: unsupported `--format` values (e.g. `yaml`, or `--format` given with no following value) must `process.exit(1)` after printing an error — matching the existing error-handling pattern used by `parseNameFlag` (`console.error(...)` then `process.exit(1)`, `bin/cli.js:38-39`) and the `default:` unknown-command branch (`bin/cli.js:63-66`).
- **No new dependencies**: JSON output uses the built-in `JSON.stringify` / `JSON.parse` already imported implicitly (global) — `package.json` `dependencies`/`devDependencies` must not change (Constraint).
- **Test scope discipline**: only add test(s) covering the new `--format json` path (and, if needed for coverage of the reject branch, the exit-1 unsupported-format path) — do not refactor, rename, or restructure the existing three tests or the `run()` helper beyond what's mechanically required to assert exit codes (the current `run()` helper uses `execFileSync` which throws on nonzero exit; a test for the `--format yaml` exit-1 path must handle that thrown error rather than assuming `run()` needs restructuring — resolve this at IMPLEMENT time by catching/asserting on the thrown error's `status`, not by changing `run()`'s signature or unrelated tests).

## Acceptance restatement

```json
{
  "verification_commands": [
    {"cmd": "npm test", "exit_code": 0},
    {"cmd": "node bin/cli.js version --format json", "exit_code": 0, "stdout_contains": ["{\"version\":\"0.1.0\"}"]},
    {"cmd": "node bin/cli.js version", "exit_code": 0, "stdout_contains": ["0.1.0"], "stdout_not_contains": ["{"]},
    {"cmd": "node bin/cli.js version --format yaml", "exit_code": 1}
  ]
}
```
