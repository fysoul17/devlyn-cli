# Plan — add `--format json` to the `version` subcommand

<!-- devlyn:authorized-surface -->
## Files to touch

- `bin/cli.js` — edit — add a `parseVersionFormat(argv)` helper (mirrors `parseNameFlag`, `bin/cli.js:33-42`) and use it inside the `case 'version':` block (`bin/cli.js:59-62`) to emit either the plain version string (unchanged path) or `JSON.stringify({ version })` when `--format json` is passed; unsupported `--format` values print an error and `process.exit(1)`. Satisfies Requirements 1-3.
- `tests/cli.test.js` — edit — add new `test(...)` cases covering `version --format json` (stdout is exactly `{"version":"<x.y.z>"}`) and `version --format bogus` (non-zero exit). Satisfies Requirement 4.

```json
{"authorized_surface": ["bin/cli.js", "tests/cli.test.js"]}
```

## Risks

- **Out-of-scope expansion to refuse**: do not touch `hello`, `--help`/`USAGE` text beyond describing the new flag if strictly needed (criteria's Out of Scope explicitly excludes usage-text growth beyond the minimum — the safest reading is to leave `USAGE` untouched entirely, since none of the Requirements demand a usage-text change and the existing `version` line in `USAGE` (`bin/cli.js:12`) already documents the command generically).
- **Do not touch `parseGreetingFormat` (bin/cli.js:29-31) or its TODO comment (bin/cli.js:27-28)** — explicitly called out as pre-existing dead code that must stay byte-for-byte unchanged, even though its name is suggestively similar to the new helper.
- **Do not touch `server/` or any dependency** — Constraints restrict changes to `bin/cli.js` and `tests/cli.test.js` only; no new npm packages, `JSON.stringify` is a Node built-in.
- **Ambiguous spec section interpreted strictly**: "single-line valid JSON document `{"version":"<x.y.z>"}`" — read literally as no extra whitespace (`JSON.stringify({ version })` produces exactly `{"version":"0.1.0"}` with no spaces), emitted via `console.log` (adds one trailing `\n`, matching the existing `version` and `hello` output pattern and the "own line" framing of the no-flag case).
- **Error path must match existing precedent exactly**: `console.error(...)` + `process.exit(1)` (same shape as `parseNameFlag`, `bin/cli.js:37-40`), not a thrown exception or a different exit code.
- **Known failure mode**: forgetting that `version --format json` must still call `readPackageVersion()` (not hardcode `0.1.0`) — Requirement 1 explicitly requires reuse of the existing helper.
- **Known failure mode**: breaking the existing `test('version prints package version', ...)` case (`tests/cli.test.js:22-25`) by changing the no-flag output shape — Requirement 2 requires that path stay byte-for-byte identical, so the helper must default to the current plain-string behavior when `--format` is absent.

## Acceptance restatement

```json
{
  "verification_commands": [
    {
      "cmd": "node bin/cli.js version",
      "exit_code": 0,
      "stdout_contains": ["0.1.0"]
    },
    {
      "cmd": "node bin/cli.js version --format json",
      "exit_code": 0,
      "stdout_contains": ["{\"version\":\"0.1.0\"}"]
    },
    {
      "cmd": "node bin/cli.js version --format yaml",
      "exit_code": 1
    },
    {
      "cmd": "npm test",
      "exit_code": 0
    }
  ]
}
```
