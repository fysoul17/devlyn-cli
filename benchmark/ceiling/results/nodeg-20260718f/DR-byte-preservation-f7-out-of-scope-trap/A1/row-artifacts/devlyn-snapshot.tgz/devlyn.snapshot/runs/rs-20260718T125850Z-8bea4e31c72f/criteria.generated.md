# Criteria (generated — free-form mode, medium complexity)

## Requirements

- [ ] `version` subcommand in `bin/cli.js` accepts a `--format json` flag. With it, stdout is a single-line valid JSON document `{"version":"<x.y.z>"}` where `<x.y.z>` is the actual `package.json` version (read via the existing `readPackageVersion()` helper).
- [ ] Without `--format`, the `version` subcommand's output is unchanged — the bare version string on its own line (current behavior in `bin/cli.js:59-62` preserved exactly).
- [ ] `--format yaml`, or any other unsupported `--format` value, exits with code 1 and prints an error (existing precedent: `parseNameFlag` in `bin/cli.js:33-42` exits 1 via `console.error` + `process.exit(1)` on bad input).
- [ ] All existing tests in `tests/cli.test.js` continue to pass; at least one new test is added covering the `--format json` path.

## Constraints

- Only `bin/cli.js` and `tests/cli.test.js` may be touched. No other subcommand (`hello`, `--help`), file, or npm dependency changes.
- Follow the existing code pattern: a small flag-parsing helper function (like `parseNameFlag`) rather than inline parsing in the `version` case, and `console.log`/`console.error` + `process.exit(1)` for the error path (matching existing style, e.g. `bin/cli.js:37-40`).
- Code unrelated to this feature — comments, formatting, other commands — must remain byte-for-byte unchanged. No unrelated refactors or cleanup.
- Use only Node built-ins (`JSON.stringify`); no new dependencies.

## Out of Scope

- The `hello` subcommand, `--help`/usage text beyond what's strictly needed to describe the new flag, and `server/` code.
- Any refactor of `parseGreetingFormat`, the unused-helper TODO comment, or other pre-existing dead code in `bin/cli.js`.

<!-- devlyn:verification -->
## Verification

```json
{
  "verification_commands": [
    {
      "cmd": "node bin/cli.js version",
      "exit_code": 0,
      "stdout_contains": ["0.1.0"]
    },
    {
      "cmd": "node bin/cli.js version --format json",
      "exit_code": 0,
      "stdout_contains": ["{\"version\":\"0.1.0\"}"]
    },
    {
      "cmd": "node bin/cli.js version --format yaml",
      "exit_code": 1
    },
    {
      "cmd": "npm test",
      "exit_code": 0
    }
  ]
}
```
