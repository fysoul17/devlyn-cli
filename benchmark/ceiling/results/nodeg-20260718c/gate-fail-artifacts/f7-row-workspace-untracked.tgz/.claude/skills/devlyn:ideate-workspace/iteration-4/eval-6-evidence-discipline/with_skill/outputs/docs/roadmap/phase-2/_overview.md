# Phase 2: Identity, Documents, and Minimal Polish

## Goal

Turn the Phase 1 "one shareable URL, no accounts" prototype into a product a small team can actually use day to day: named users, a list of their documents, the ability to create new documents, and basic per-document access control.

## Why this phase exists

Phase 1 proves the collaboration loop. Phase 2 removes the two largest reasons a real team can't use it yet: (a) anyone with a URL can edit (no access control), and (b) there is no way to find or organize documents. These are product-surface items, not new core algorithmic work.

## Items (preview — specs to be finalized at the start of Phase 2)

| # | Item | One-liner |
|---|------|-----------|
| 2.1 | Authentication | Users sign in with a minimal auth method (specifics chosen at the start of Phase 2) and get a stable identity across sessions. |
| 2.2 | Document list and creation | A signed-in user sees their documents and can create a new one from the UI (no more manual URL-crafting). |
| 2.3 | Per-document access control | The document owner can decide who else can view or edit — at minimum a distinction between "anyone with the link" and "only specified users". |
| 2.4 | Presence with real identities | Replace session pseudonyms with the signed-in user's display name and avatar in the presence layer. |

## Sequencing rationale

- 2.1 first — every other item depends on there being a user identity.
- 2.2 before 2.3 — a user needs to own documents before access rules have meaning.
- 2.3 before 2.4 — once access is real, the presence identity upgrade (2.4) is safe to attach to real names.

## Deferred out of Phase 2

- Rich text formatting
- Comments / suggestions / track changes
- Document templates
- Team / workspace abstractions beyond per-document access
- Multi-instance relay and multi-region hosting
