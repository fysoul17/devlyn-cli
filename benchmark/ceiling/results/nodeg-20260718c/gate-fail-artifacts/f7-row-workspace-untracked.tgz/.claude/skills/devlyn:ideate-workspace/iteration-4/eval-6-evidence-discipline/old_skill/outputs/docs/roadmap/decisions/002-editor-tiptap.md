---
id: 002
title: "Use TipTap as the editor"
date: 2026-04-22
status: accepted
---

# 002 Use TipTap as the editor

## Context
Given decision 001 (Yjs), we need a rich-text editor that binds cleanly to a Yjs document. Candidates that can integrate with Yjs include TipTap (ProseMirror-based), a bare ProseMirror setup, Slate (with a community Yjs binding), and Lexical (also via community bindings).

## Decision
Use TipTap with its Collaboration and CollaborationCursor extensions (which wrap `y-prosemirror` under the hood).

## Alternatives Considered

### Bare ProseMirror + y-prosemirror
- Pros: Maximum control; TipTap is a thin layer on top of this anyway.
- Cons: Significantly more boilerplate for common features (headings, lists, marks). We'd end up reinventing a chunk of TipTap.
- Why rejected: No material benefit at Phase 1 scope and measurable productivity cost.

### Slate
- Pros: Popular, React-friendly API.
- Cons: Yjs integration is community-maintained and historically less robust for collaborative rich text than `y-prosemirror`.
- Why rejected: The Yjs + ProseMirror combination is the better-understood path for production collab editing; Slate's Yjs bindings are a riskier choice for our "boring, proven primitives" principle.

### Lexical
- Pros: Strong performance characteristics; Meta-backed.
- Cons: Yjs integration is less mature than `y-prosemirror`; ecosystem around collab is smaller.
- Why rejected: Same reasoning as Slate — we're optimizing for the best-trodden collab path, not the best editor in isolation.

## Consequences
- TipTap's extension model is the seam for adding features (lists, headings, marks, presence).
- We can adopt `@tiptap/extension-collaboration` and `@tiptap/extension-collaboration-cursor` directly; no custom Yjs glue.
- If we later need editor capabilities TipTap doesn't expose, we can drop to bare ProseMirror without swapping the CRDT — TipTap uses ProseMirror underneath.
- We accept a small TipTap tax (its abstractions, its licensing model for "Pro" extensions if we ever adopt them).
