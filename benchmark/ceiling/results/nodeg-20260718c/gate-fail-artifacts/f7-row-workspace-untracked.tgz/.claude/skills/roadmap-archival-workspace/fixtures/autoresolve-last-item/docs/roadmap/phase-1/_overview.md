# Phase 1: MVP Logging
The core logging loop.
