# ROADMAP.md — proposed addition

Add this row to the Phase 2 table in `docs/ROADMAP.md`:

| # | Feature | Status | Spec |
|---|---------|--------|------|
| 2.3 | Draft autosave and recovery | planned | [phase-2/2.3-draft-autosave-and-recovery.md](roadmap/phase-2/2.3-draft-autosave-and-recovery.md) |

Note: the user's original phrasing was "export draft as JSON file." Per the
Phase 3.5 CHALLENGE pass (see transcript.md), this was flagged as a roadmap
workaround on axis 1 (NO WORKAROUND) and axis 4 (WORLD-CLASS BEST PRACTICE),
and the user's "open to alternatives" note allowed surfacing the direct fix
(autosave + recovery) as the proposed item. If the user confirms they want the
original JSON export/import approach, swap the spec file before implementation.
