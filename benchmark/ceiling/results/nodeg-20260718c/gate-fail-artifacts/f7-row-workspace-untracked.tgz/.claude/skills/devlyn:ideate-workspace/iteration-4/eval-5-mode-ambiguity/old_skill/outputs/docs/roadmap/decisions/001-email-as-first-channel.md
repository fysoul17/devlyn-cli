---
id: "001"
title: "Email as the first out-of-app engagement channel"
status: accepted
date: 2026-04-22
---

# 001 — Email as the first out-of-app engagement channel

## Decision
Phase 3 engagement work will use email as the only outbound channel. Push notifications and SMS are deferred to backlog.

## Context
The app is local-first and has no accounts. Phases 1-2 produced the data to engage users with (streaks, activity), but no channel yet existed to reach them between sessions. Adding more than one channel at once would multiply scope (opt-in flows, delivery failure handling, per-channel preferences) before we've validated that any of them produce the desired engagement lift.

## Alternatives considered
- **Push notifications**: Lower friction than email once installed, but requires device-specific setup (web push vs. native push), account-like user identity per device, and a server component for each platform. Rejected for v1 on complexity grounds.
- **SMS**: Highest open rate but carries real per-message cost and regulatory overhead (A2P 10DLC, carrier filtering). Rejected for v1 — disproportionate to a weekly summary.
- **In-app only (no outbound)**: Zero additional surface area, but then there's nothing to build in Phase 3 — the user explicitly asked for a weekly email summary.

## Consequences
- Users must provide an email address (opt-in) to receive any engagement. This is the first time the app asks for any identifier; the settings UX needs to make the trade explicit.
- The app picks up an external dependency (transactional email provider) with deliverability, reputation, and key-management concerns. This is new operational surface area.
- When push notifications come off the backlog later, the opt-in and preferences UX from this decision becomes the template they plug into — it's worth making those pieces channel-shaped rather than email-shaped.
