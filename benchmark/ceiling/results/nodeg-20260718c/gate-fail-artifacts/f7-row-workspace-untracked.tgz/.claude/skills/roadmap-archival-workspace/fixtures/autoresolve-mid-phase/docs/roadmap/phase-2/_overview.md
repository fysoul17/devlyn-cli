# Phase 2: Core Editor
The editing loop users spend 90% of their time in.
