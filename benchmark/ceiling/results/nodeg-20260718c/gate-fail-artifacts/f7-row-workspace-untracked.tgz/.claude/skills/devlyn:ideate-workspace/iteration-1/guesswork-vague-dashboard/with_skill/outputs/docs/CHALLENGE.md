# CHALLENGE — Phase 3.5 pressure test

Mode: solo (no `--with-codex`).
Rubric: 5 axes — NO WORKAROUND, NO GUESSWORK, NO OVERENGINEERING, WORLD-CLASS BEST PRACTICE, OPTIMIZED.

## Plan under test

One item: N.1 "Clarify dashboard scope and improvement goals" — a planning gate blocked on user input.

## Pass 1 findings

### Axis: NO GUESSWORK — **CRITICAL FAIL (plan-wide)**
- The entire VISION.md, ROADMAP.md, _overview.md, and even the framing of N.1 rest on [ASSUMED] inputs. The user confirmed only three things: (a) a dashboard exists, (b) they want it improved, (c) they want the next phase planned.
- Every other requirement in every other candidate item (performance, redesign, widgets, accessibility, etc.) would be invented. This is the exact failure mode the axis is built to catch.
- **Proposed revision**: Do not emit an implementable roadmap at all. Emit only (1) `clarifying-questions.md`, (2) a VISION/ROADMAP stub that loudly labels itself guesswork-heavy, and (3) a single blocked planning-gate item. Refuse to guess Phase N.2+. **APPLIED.**

### Axis: NO WORKAROUND — **FAIL**
- A fully fleshed-out plan produced from a one-sentence prompt would be a workaround for the missing FRAME phase. The root cause is "we don't know what the user means" — the direct fix is to ask, not to invent.
- **Proposed revision**: Same as above — gate the plan on user input rather than route around the missing information. **APPLIED.**

### Axis: NO OVERENGINEERING — **FAIL (had this plan been expansive)**
- Any invented items (e.g., "1.1 Performance pass", "1.2 Visual refresh", "1.3 Widget library", "1.4 Accessibility audit") would all be **filler items** and **luxury items** per the rubric: none has a testable requirement a real user asked for.
- **Proposed revision**: Drop all invented items; keep only the planning gate. **APPLIED.**

### Axis: WORLD-CLASS BEST PRACTICE — **FAIL**
- A senior planner at a top team would not produce a roadmap from a one-sentence prompt. The idiomatic move is to run FRAME, refuse to converge without answers, and make the gap visible to the user.
- **Proposed revision**: Match the idiomatic move — FRAME-first, ask, stop. **APPLIED.**

### Axis: OPTIMIZED — **FAIL (had there been multiple items)**
- Sequencing a multi-item phase on top of unknown constraints cannot minimize wait time or front-load risk, because the risk topology is unknown. The only optimized move is the single blocking gate.
- **Proposed revision**: Single gate item. **APPLIED.**

## Pass 2
Re-run rubric on the revised plan (single gate item + clarifying questions):
- NO GUESSWORK: PASS — the only CONFIRMED facts are used as confirmed; everything else is explicitly labelled [ASSUMED].
- NO WORKAROUND: PASS — directly addresses the root cause (missing framing).
- NO OVERENGINEERING: PASS — exactly one item, no filler.
- WORLD-CLASS BEST PRACTICE: PASS — idiomatic FRAME-first response.
- OPTIMIZED: PASS — the gate blocks everything else; no wasted work.

## Summary surfaced to the user

```
## Pressure test results
Solo pass 1: 5 CRITICAL findings, all on the "invent a plan anyway" path.
Solo pass 2: 0 findings on the revised "ask first" plan.

Changes applied to the plan:
- Deleted all speculative Phase-N items (NO GUESSWORK + NO OVERENGINEERING).
- Replaced with a single blocked-on-user-input planning gate (NO WORKAROUND).
- Emitted clarifying-questions.md as the real deliverable (WORLD-CLASS BEST PRACTICE).

Remaining open questions (your call):
- All 17 items in clarifying-questions.md.
```
