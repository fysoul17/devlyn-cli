---
id: 003
title: "Next.js App Router with client components for interactive surfaces"
date: 2026-04-22
status: accepted
---

# 003 Next.js App Router with client components for interactive surfaces

## Context
User specified Next.js App Router deployed on Vercel, with Tailwind + shadcn/ui for styling [defaulted to shadcn/ui — user confirmed]. Data lives in localStorage (decision 001), which is a browser-only API. We need a clear rule for which components are server vs client.

## Decision
- **Server components (default) for layout, page shells, and any static chrome.** `app/layout.tsx`, `app/page.tsx` shell, `app/history/page.tsx` shell.
- **Client components for anything that reads or writes localStorage or handles user interaction.** The habit list with toggle buttons, the streak counter, the add-habit form, and the history calendar are all client components.
- Client components are pushed as **deep** in the tree as possible — the page itself stays a server component, and a single `<HabitListClient />` component owns the localStorage read and the interaction.
- All data access is guarded with a `typeof window !== "undefined"` check or done inside `useEffect` to avoid SSR crashes.

## Alternatives Considered

### Pages Router
- Pros: older, simpler mental model, `getStaticProps` works well with localStorage-hydrating pages
- Cons: user explicitly asked for App Router
- Why rejected: user intent is ground truth (CHALLENGE rubric hard rule).

### Make the whole app a single client component
- Pros: avoids any server/client boundary confusion
- Cons: loses App Router's default-server benefit, ships more JS to the client than needed, and goes against the user's global project convention of "build the server component first where possible and implement client component as deep as possible"
- Why rejected: the global convention is explicit — deep client components only.

### Server actions writing to a database
- Pros: data persists across devices
- Cons: requires a database, which is explicitly out of scope (decision 001, VISION anti-goals)
- Why rejected: out of scope for v1.

## Consequences
- Clear, shallow rule for reviewers: if a file touches `localStorage` or has an `onClick`, it has `"use client"`. If it doesn't, it shouldn't.
- SSR-safe by construction — the server never tries to read user data.
- Bundle size stays small because only the interactive leaves are client components.
- If v2 adds cloud storage, server components and server actions become natural — the client component boundary is already where mutations happen.
