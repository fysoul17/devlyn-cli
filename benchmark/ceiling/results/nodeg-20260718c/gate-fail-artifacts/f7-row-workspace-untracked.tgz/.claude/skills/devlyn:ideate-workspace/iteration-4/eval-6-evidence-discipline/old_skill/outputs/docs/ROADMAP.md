# Collaborative Doc Editor Roadmap

> **North Star**: A real-time collaborative document editor that two people can co-edit live in a browser without setup friction — simpler surface area than Google Docs, shipped in weeks, not years.

## Phase 1: Ship the collab loop (Target: 4–6 weeks)
Phase 1 ships the defining capability — two people co-editing the same document URL live — plus the minimum presence UX required for that experience to feel real. No extra features land in Phase 1.

| # | Feature | Status | Priority | Complexity | Spec |
|---|---------|--------|----------|-----------|------|
| 1.1 | Collaborative document editing (MVP) | Planned | High | High | [spec](roadmap/phase-1/1.1-collaborative-editing-mvp.md) |
| 1.2 | Presence indicators (cursors + user names) | Planned | High | Low | [spec](roadmap/phase-1/1.2-presence-indicators.md) |

## Backlog
| Feature | Reason Deferred | Revisit |
|---------|----------------|---------|
| Comments / threaded discussion | Adds collab-consistency complexity beyond text+presence | After Phase 1 proves stable in real use |
| Suggestion mode (tracked changes) | Same as above — an additional collab primitive layered on base text | Post-MVP |
| Document history / revision explorer | Requires snapshot strategy and UI surface; not needed to prove collab | Post-MVP |
| Rich export (PDF, DOCX) | Not part of the collab loop | As user demand surfaces |
| Folders / workspaces / permission roles | Enterprise surface area that contradicts "simpler than Docs" | Only if multi-team usage emerges |
| Managed collab service (Liveblocks) as alternative to self-hosted Hocuspocus | Considered and rejected at current MAU; revisit if ops burden grows | If self-hosted sync server ops becomes painful |
| Theming / light-dark / custom styles | Luxury; does not move collab loop | After the first active user cohort asks for it |

## Decisions
| # | Decision | Date | Record |
|---|----------|------|--------|
| 1 | Use Yjs as the CRDT | 2026-04-22 | [record](roadmap/decisions/001-crdt-choice-yjs.md) |
| 2 | Use TipTap as the editor | 2026-04-22 | [record](roadmap/decisions/002-editor-tiptap.md) |
| 3 | Self-host Hocuspocus + Postgres for sync and persistence | 2026-04-22 | [record](roadmap/decisions/003-sync-server-hocuspocus.md) |
| 4 | Deploy Next.js on Vercel, Hocuspocus on a persistent-connection host (Fly.io or similar) | 2026-04-22 | [record](roadmap/decisions/004-deploy-topology.md) |

## Open Questions (surfaced from CHALLENGE — defaults were assumed, not user-confirmed)
- Deploy topology assumes Vercel for frontend + Fly.io (or similar) for the sync server because Vercel's serverless model is not a natural fit for persistent WebSocket connections. Confirming this shape vs. a single-host deploy (e.g., Railway running both) is worthwhile before 1.1.
- Self-hosted vs managed sync (Liveblocks) at 500 MAU is a cost-vs-ops tradeoff. Default is self-hosted; switching is low-regret if ops gets painful.
- Auth is assumed to be Auth.js (email magic link) — not confirmed by the user. If the user prefers no auth (public share-link model) the scope of 1.1 shrinks.
