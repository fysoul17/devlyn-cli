---
id: 002
title: "Cold = 14 days since last touchpoint by default; rep-overridable per prospect"
date: 2026-04-22
status: accepted
---

# 002 Cold definition

## Context
The core signal of the app is "this prospect is going cold." We have to pick a default threshold and a model for overrides. Too tight and every prospect is always cold; too loose and the signal is useless. Sales cycles also legitimately vary per prospect (enterprise deal vs small biz).

## Decision
- Default cold threshold: **14 days** since the last logged touchpoint (or since prospect creation if no touchpoints exist).
- Per-prospect override: `prospects.cold_threshold_days` column, default 14, editable in the add/edit flow (1.3), range 1–365.
- No team-wide or segment-wide threshold configuration in v1. If reps need segment rules, that's a backlog conversation.

**Note for user**: The 14-day default is an [ASSUMED] starting point — the user's brief said "no other constraints, sensible defaults." If the team's cycles are systematically shorter or longer, this number should be revisited after 2–4 weeks of real use. Flagged as an open question in the initial summary.

## Alternatives Considered

### Single global threshold with no per-prospect override
- Pros: simpler schema, no editing UI for threshold.
- Cons: fails obviously for prospects on different sales cycles (a 90-day enterprise deal shouldn't be "cold" at day 15); forces reps to either mentally filter the signal or game the system with fake touchpoints.
- Why rejected: real sales books have mixed cycles; a one-size-fits-all threshold makes the signal noisy enough to be ignored.

### Team-configured threshold (admin sets default for all reps)
- Pros: centralized control.
- Cons: adds a settings page and an admin role; defers value to a later phase; no evidence reps need team-level rules beyond a sensible default.
- Why rejected: overengineering for an 8-person team in v1. Per-prospect override covers the real variation.

### Activity-based cold (ML / scoring model)
- Pros: theoretically more accurate signal.
- Cons: requires data volume we don't have on day 1; opaque to reps who can't reason about "why is this prospect flagged"; heavy engineering lift.
- Why rejected: premature. Time-since-touch is explainable, predictable, and good enough.

## Consequences
- Schema carries a per-prospect column from day 1 (slight complexity cost in 1.1, 1.3, and 2.1 queries — all of which must use `prospects.cold_threshold_days`, not a hardcoded 14).
- Reps can defend/tune the signal per-prospect, increasing trust in the cold list.
- The 14-day default is a team-level assumption that may need to be parameterized later (env var or settings row) if the team wants to move it as one. Deferred until evidence.
