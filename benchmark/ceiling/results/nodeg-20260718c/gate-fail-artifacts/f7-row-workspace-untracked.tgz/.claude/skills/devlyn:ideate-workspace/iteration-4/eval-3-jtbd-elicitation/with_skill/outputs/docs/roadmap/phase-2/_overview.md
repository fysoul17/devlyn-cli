# Phase 2: Team Visibility & Nudges

## Goal
Turn the tool from "a better spreadsheet for me" into "a shared signal the team acts on daily." Managers gain aggregate visibility without micromanaging; reps get a morning nudge so checking cold prospects becomes habit.

## Why this phase comes after Phase 1
These features assume prospects and touchpoints already exist in the system. Shipping team views before individual reps use the tool would show empty boards.

## Sequencing notes
- **2.1** and **2.2** both depend on Phase 1 being in use (real touchpoint data).
- **2.2** is lower complexity (one scheduled job + existing cold query) and can ship first if 2.1 needs design iteration.

## Out of scope for Phase 2
- Slack notifications (Backlog — email first)
- Customizable digest content / frequency (default is enough until reps ask)
- Reassignment / handoff workflows (Backlog)
