---
id: 002
title: "Ship default expense categories, user-editable later"
date: 2026-04-22
status: accepted
---

# 002 Ship default expense categories, user-editable later

## Context
The Add-expense form in item 1.1 needs a category field. We must decide whether Phase 1 ships a fixed default category set, lets users define their own, or both. This affects the simplicity of Phase 1 and how easily users get to the 10-second capture goal.

## Decision
Phase 1 ships a fixed default category set: **Software, Meals, Travel, Equipment, Office, Marketing, Professional Services, Other**. Users can NOT add or rename categories in Phase 1. User-defined categories are a backlog item to be considered after Phase 1 is used in practice.

[ASSUMED: this category set reflects common US-style freelancer deduction categories. The user did not specify categories; this should be confirmed by the user before shipping.]

## Alternatives Considered

### Let users create categories from day one
- Pros: each user gets exactly the taxonomy they want.
- Cons: pushes a category-management UI into Phase 1 that the user didn't ask for; category-management is its own mini-feature (create, rename, merge, delete-with-reassignment).
- Why rejected: violates NO OVERENGINEERING — adds a detour before the core log/summary/export loop is proven.

### No categories, free-text only
- Pros: simplest possible form.
- Cons: the Summary view (1.2) and the CSV export (1.4) both rely on category as a grouping dimension; free-text produces "Meals" vs "meals" vs "Meal" drift that ruins grouping.
- Why rejected: breaks the downstream items' core value.

### Categories inferred automatically from description
- Pros: zero-friction capture.
- Cons: requires an LLM or a heuristic, both of which are unreliable for this use case and add huge surface area.
- Why rejected: overengineering for Phase 1; consider revisiting as a Phase 3 polish if the fixed-list UX proves friction-y.

## Consequences
- The Add form stays dead-simple: a dropdown of 8 options.
- "Other" serves as the escape hatch when a user's expense doesn't fit neatly.
- If the default list is wrong for this specific user, they'll feel it fast in real use — that's the signal that triggers promoting user-defined categories from backlog to a phase.
