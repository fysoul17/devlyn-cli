---
id: 004
title: "Next.js on Vercel, sync server on a persistent-connection host"
date: 2026-04-22
status: accepted
---

# 004 Next.js on Vercel, sync server on a persistent-connection host

## Context
Decision 003 picks Hocuspocus as a self-hosted sync server. The frontend is Next.js. A natural question is "can one deploy target host both?" Vercel is the obvious Next.js host, but Vercel's serverless function model is not intended for long-lived WebSocket connections, which is exactly what Hocuspocus serves.

## Decision
Deploy the Next.js frontend on Vercel. Deploy the Hocuspocus sync server separately on a host designed for long-lived processes (Fly.io or Railway are the two reasonable defaults). The browser connects to `wss://sync.<domain>` for realtime traffic.

## Alternatives Considered

### Everything on Vercel (serverless Hocuspocus)
- Pros: One deploy target.
- Cons: Vercel serverless functions are not designed for long-lived WebSocket connections; sync workloads don't fit that runtime model.
- Why rejected: Fighting the hosting platform's intended model is a predictable source of bugs and cost surprises.

### Everything on Fly.io (including Next.js SSR)
- Pros: One deploy target; no cross-host DNS.
- Cons: Gives up Vercel's Next.js-specific deploy ergonomics (edge caching, preview deploys, image CDN) — all of which we'd have to recreate.
- Why rejected: Net ops burden is higher, not lower.

### Everything on Railway
- Pros: Railway can run both the Next.js app and a long-lived Node process. Simpler than splitting across two hosts.
- Cons: Less Next.js-native than Vercel (no automatic preview URLs tuned to Next.js, no Vercel-specific Next.js optimizations).
- Why rejected: Reasonable fallback, kept as a low-regret alternative if we ever want to consolidate.

## Consequences
- Two deploy pipelines to maintain (Vercel + Fly.io). Acceptable operational cost.
- DNS: `app.<domain>` → Vercel, `sync.<domain>` → sync host.
- Auth crosses the boundary: Auth.js session is validated server-side in Next.js and its token is also passed to Hocuspocus's `onAuthenticate` hook.
- CORS is not a concern for WebSockets; auth is enforced at connect time.
- If the split becomes painful, consolidating to Railway is a straightforward migration — no client protocol change, just two deploys on one host.
