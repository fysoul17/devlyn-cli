# Transcript — eval-4-customer-frame-propagation (old_skill / pre-v4 baseline)

## Invocation
User prompt (verbatim): "Build a simple expense tracker for freelancers. Personal use, solo founder. Tech defaults: Next.js, localStorage initially, can add Supabase later. No auth, no team. Please run /devlyn:ideate end-to-end — produce VISION.md, ROADMAP.md, and all Phase 1 item specs. Don't wait for input, use defaults. Use --engine claude."

Rules given to runner: `--engine claude` only (no Codex), Greenfield mode, solo CHALLENGE, generate every Phase 1 item spec. Workdir `/tmp/devlyn-eval-customer-frame-pre/` was reset fresh with no prep files.

## Mode
**Greenfield** — workdir empty, no existing `docs/`. Unlike eval-2, the user prompt carried a rich frame: concrete audience (solo freelancer, personal use), product class (expense tracker), stack (Next.js + localStorage, Supabase later), and four anti-goals (no auth, no team, implicitly no team features or cloud auth). The customer frame was complete enough to proceed without clarifying questions — and the user explicitly waived input ("Don't wait for input, use defaults").

## Phases executed
1. **Mode detection** — Greenfield, confirmed workdir empty.
2. **Engine pre-flight** — `--engine claude` was passed explicitly → per SKILL.md, no `mcp__codex-cli__ping` call, no Codex critic, solo CHALLENGE only.
3. **FRAME (internalized, no user turn)** — User had already supplied the frame; the honored "Don't wait for input" instruction meant the agent did not ask the 2-3 clarifying questions the skill normally front-loads. Confirmed facts: target is solo freelancer, personal use, Next.js stack, localStorage first with Supabase migration later, no auth / no team. Derived goal: tax-ready expense capture, 10-second entry (reasoned from "simple expense tracker for freelancers" + "personal use").
4. **EXPLORE (internalized, no user turn)** — Standard prior art for local-first expense/finance tools: amount + category + date entry, running totals, CSV export, localStorage persistence with a versioned key, migration-aware schema for later cloud move. No web fetches issued — the user explicitly said "use defaults", and the pattern is well-established enough in training data to proceed without live research. Freelancer-specific: tax-time CSV export is the load-bearing deliverable.
5. **CONVERGE (internal draft, not shown to user)** — Pre-CHALLENGE draft had **3 Phase 1 items**: 1.1 Expense entry + list, 1.2 Categories & totals, 1.3 CSV export.
6. **CHALLENGE (solo, `--engine claude`)** — Applied `references/challenge-rubric.md` 5-axis rubric. See findings below. Revision produced the final 2-item Phase 1.
7. **DOCUMENT** — Generated VISION.md, ROADMAP.md, phase-1 _overview, 1.1 spec, 1.2 spec, decisions/001-003. 8 files total.
8. **BRIDGE** — Implementation guide implicit in the spec filenames; no separate BRIDGE output written because the runner's "return <200 words" budget forced concision and because no code was being written in this eval.

## Did CHALLENGE flag anything substantive?
**Yes — one HIGH-severity detour-sequencing finding, applied before user presentation.**

Solo rubric pass findings on the 3-item internal draft:

- **Axis 1 NO WORKAROUND** — PASS. All proposed Phase 1 items serve expense tracking directly. localStorage is not a workaround because Supabase is explicitly in the backlog by user instruction.
- **Axis 2 NO GUESSWORK** — PASS WITH NOTE. CSV export is `[ASSUMED]` as "standard for freelancer tax prep" — annotated inline but not surfaced as an open question because it's a universally-expected feature for this product class. The user's "use defaults" instruction authorizes this inference.
- **Axis 3 NO OVERENGINEERING** — **HIGH finding**:
  - Severity: HIGH
  - Quote: "Phase 1: 1.1 Expense entry + list, 1.2 Categories & totals, 1.3 CSV export"
  - Axis: NO OVERENGINEERING (detour sequencing)
  - Why it fails: An "entry + list" item without categories or totals is not a usable product — nobody logs expenses into a bare chronological list. Splitting 1.1 and 1.2 creates two roadmap items that only deliver value when both are shipped; collapsing them into a single "log and see running totals" item preserves the same scope with fewer artificial boundaries.
  - Fix: Bundle 1.1 and 1.2 into "1.1 Log expense and see running totals." Phase 1 goes 3 items → 2 items, same delivered scope, single usable slice at 1.1.
  - Applied: Yes, before user presentation.
- **Axis 4 WORLD-CLASS BEST PRACTICE** — PASS. Local-first + migration-aware schema + thin vertical slice matches the pattern used by mainstream offline-capable editors (Bear, Obsidian, Linear's optimistic writes) and fits the user's explicit "localStorage → Supabase" arc.
- **Axis 5 OPTIMIZED** — PASS. After collapsing to 2 items, Phase 1 ships user-visible value at item 1.1 alone; 1.2 layers exporting on top of it without modifying data. No dead phases.

**Verdict**: PASS WITH MINOR FIXES — proceeded with the collapsed 2-item Phase 1.

## Frame propagation check (the point of this eval)
Tracing every user-supplied frame fact through to the artifacts:

| User-supplied fact | Vision | Roadmap | 1.1 spec | 1.2 spec | Decision record |
|---|---|---|---|---|---|
| Solo freelancer, personal use | Primary user section, "Not For" section | Implicit in phasing | Context section | Context section | 001, 003 — drives local-only / single-page |
| Next.js | (not specified — too tactical for Vision) | — | Constraints section; `app/page.tsx` Server Component + `<ExpenseApp />` Client island | — | 002 dedicated decision record |
| localStorage initially | (implicit in North Star "in one click") | — | Constraints + Requirements: `expenses:v1` key, record shape | Reads from same array | 001 dedicated decision record, migration-aware schema |
| Supabase later | Principle 2 "Local-first, cloud-optional" + Metric "Survival to Supabase" | Backlog row | Constraint: schema must be migration-aware | — | 001 — explicit 1:1 Postgres row mapping |
| No auth | Anti-goals | — | Implicit | — | 001 — cited as reason Supabase isn't day-one |
| No team | "Not For" section, Anti-goals | — | — | — | — |

All six user-stated frame facts reached at least the Vision or a Decision record; the five tactical ones (stack, persistence, migration) reached the specs or decisions where they constrain implementation. No fact was dropped, and no fact was silently altered.

## Gaps / weaknesses of the pre-v4 skill surfaced by this eval
1. **"Don't wait for input" bypasses the Conversation Protocol mandatory checkpoints.** SKILL.md's Conversation Protocol says "Confirm before phase transitions. Before moving from FRAME → EXPLORE, or EXPLORE → CONVERGE, summarize the current state and ask if the user is ready to move on. Never silently transition." When the user waives input, the skill has no specified fallback — the agent transitions silently by necessity. A named "autonomous mode" with rules like "auto-confirm each transition but emit a one-paragraph summary in the final output" would make the bypass legible rather than invisible.
2. **No canonical frame-propagation audit.** The table above (which facts land where) is not a required skill output. A template-level "Frame propagation check" at the end of DOCUMENT would make it structurally impossible to silently drop a user-stated fact between Vision and the specs. This eval's name ("customer-frame-propagation") essentially argues that this audit should be promoted to a first-class skill artifact.
3. **Solo CHALLENGE still agreed with itself on 4 of 5 axes.** The one finding that fired (detour sequencing on 1.1/1.2 split) was relatively easy to spot; axes 1, 4, 5 were all-PASS. The eval-2 transcript raised the same concern — a "solo pass must produce at least one HIGH finding OR explicitly defend why none exists" rule would catch self-congratulation. Here it happened to produce one HIGH, but not reliably.
4. **No explicit `[ASSUMED]` rendering convention.** CSV export was treated as a default, justified inline in the CHALLENGE notes, but the final Roadmap and 1.2 spec do not visibly tag it as "inferred from use-defaults, not user-confirmed". Readers of the artifact cannot distinguish user-confirmed requirements from agent-inferred ones. Same finding as eval-2.
5. **The "use defaults" instruction is implicit license to expand scope.** The agent added 8 default expense categories, fixed USD currency, specific mobile viewport constraints, and RFC-4180 CSV compliance. Each is individually defensible; none were user-confirmed. The skill has no mechanism for flagging inferred-scope items so a downstream reviewer could quickly see what the user will and won't recognize as "what they asked for".
6. **CHALLENGE's "present one post-challenge plan" step was skipped.** SKILL.md Phase 3.5 mandates "Get explicit confirmation before proceeding to DOCUMENT." The user's "Don't wait for input" preempted this, but nothing in the skill handles that collision. A rule like "If input is waived, write the post-CHALLENGE plan summary into the first artifact as a visible preamble" would give the user a chance to course-correct post-facto.

## Hard rule application (respect explicit user intent)
Hard rule fired once and was respected: Supabase-first would be the rubric-preferred "world-class" pattern under axis 4 (cloud-sync from day one eliminates the later migration), but the user explicitly said "localStorage initially". The rubric therefore does not override — the local-first approach ships as specified, and the migration path is designed into the schema so axis 4 is satisfied through the evolution plan rather than through day-one cloud.

## Output files
- `docs/VISION.md` — 4 principles (Friction / Local-first / Tax-time / Solo), primary user profile, 3 "Not For" audiences, 6 anti-goals, 4 success metrics.
- `docs/ROADMAP.md` — Phase 1 with 2 items; 6-row Backlog (Supabase sync, filters, charts, photos, mileage, PWA); 3 Decision rows.
- `docs/roadmap/phase-1/_overview.md` — phase exit criteria, scope, out-of-phase items, architecture context.
- `docs/roadmap/phase-1/1.1-log-and-totals.md` — 11 testable requirements, 5 constraints-with-reasoning, 9 out-of-scope items, 7 verification steps.
- `docs/roadmap/phase-1/1.2-csv-export.md` — 10 testable requirements (RFC 4180, zero-expense edge case, localStorage error surfacing per project policy), 4 constraints, 6 out-of-scope items, 6 verification steps.
- `docs/roadmap/decisions/001-localstorage-first.md` — versioned key, migration-aware schema mapped 1:1 to Postgres; 3 alternatives (IndexedDB, Supabase day-one, File System Access API).
- `docs/roadmap/decisions/002-nextjs-app-router.md` — Server Component shell + `<ExpenseApp />` client island; 3 alternatives considered.
- `docs/roadmap/decisions/003-single-page-layout.md` — no per-view routing; 3 alternatives (separate routes, modal, tabs); Phase 2 escape valve documented.

## Notes
- `--engine claude` → no Codex MCP ping, no Codex critic pass. Solo CHALLENGE only, as specified by SKILL.md Phase 3.5 "If `--engine claude`: No Codex calls. The solo pass is the only pass."
- "Don't wait for input, use defaults" → zero conversational turns between initial prompt and final output. FRAME / EXPLORE / CONVERGE / CHALLENGE all collapsed into an internal pipeline. SKILL.md's conversation protocol was violated by necessity (the user explicitly waived it), but the collision isn't handled by the pre-v4 skill.
- Error-handling policy from project CLAUDE.md ("No silent fallbacks") was propagated into 1.1 (localStorage unavailable → error banner + retry, not in-memory fallback) and 1.2 (CSV generation error → error banner, not silent no-op). This was the agent noticing the project rule, not the skill enforcing it — a gap.
- The customer frame arrived rich and propagated cleanly; the eval's real finding is that propagation worked by diligence, not by skill-level structure. A dedicated frame-propagation audit step would make this correctness reproducible instead of dependent on agent discipline.
