import { db } from '../db';
import { authMiddleware } from '../middleware/auth';

export async function createTask(req: Request) {
  const user = await authMiddleware(req);
  const { title, description } = await req.json();

  const task = await db.task.create({
    data: { title, description, status: 'todo', userId: user.id },
  });

  return Response.json(task);
}

export async function getTasks(req: Request) {
  const user = await authMiddleware(req);
  const tasks = await db.task.findMany({ where: { userId: user.id } });
  return Response.json(tasks);
}

export async function updateTask(req: Request, taskId: string) {
  const user = await authMiddleware(req);
  const { title, description, status } = await req.json();

  const task = await db.task.update({
    where: { id: taskId, userId: user.id },
    data: { title, description, status },
  });

  return Response.json(task);
}

export async function deleteTask(req: Request, taskId: string) {
  const user = await authMiddleware(req);
  await db.task.delete({ where: { id: taskId, userId: user.id } });
  return new Response(null, { status: 204 });
}
