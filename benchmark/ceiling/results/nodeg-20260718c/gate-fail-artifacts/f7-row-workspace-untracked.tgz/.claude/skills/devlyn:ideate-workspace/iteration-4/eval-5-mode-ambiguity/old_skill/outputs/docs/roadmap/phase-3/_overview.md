# Phase 3: Engagement

## Goal
Re-engage users between app sessions via low-friction, opt-in channels. The tracker is local-first, so outbound communication is the user's first reason to give us any network identity (email address).

## Why now
Phases 1 and 2 established the core loop (log + streak) and reflection surface (history + heatmap). Engagement depends on the data those produced — streaks to celebrate and gaps to nudge. Building engagement before the data existed would have produced generic notifications.

## Items
- 3.1 — Weekly email streak summary

## Anti-goals
- Do not turn this into a full notifications platform. One channel (email), one cadence (weekly), one content type (streak summary).
- Do not require an account. Email is an optional opt-in on top of the existing local-first storage.

## Constraints
- Local-first: the tracker still works fully without email. Email is strictly additive.
- No server-side copy of habit data beyond what is needed to render and send the email.
