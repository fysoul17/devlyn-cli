# Habit Tracker Roadmap

> **North Star**: A solo user logs "did it today" in one tap, sees their streak, and can look back at their history — nothing else gets in the way.

## Phase 1: MVP (Target: 1-2 weekends)
Ships a deployed, usable habit tracker on Vercel. Each item in this phase delivers user-visible value on its own — no infrastructure-only items. After Phase 1, the author can actually use the tool every day.

| # | Feature | Status | Priority | Complexity | Spec |
|---|---------|--------|----------|-----------|------|
| 1.1 | Log habits and see streak | Planned | High | Medium | [spec](roadmap/phase-1/1.1-log-and-streak.md) |
| 1.2 | History view | Planned | High | Low | [spec](roadmap/phase-1/1.2-history-view.md) |

## Backlog
Ideas acknowledged but not yet phased. Revisit only after the Phase 1 MVP has been in daily use for at least 2 weeks.

| Feature | Reason Deferred | Revisit |
|---------|----------------|---------|
| Cross-device sync (cloud storage) | Explicitly out of scope; user chose local-first. Real solution is cloud-backed storage, not an export/import workaround. | If the user starts using the app on a second device |
| Reminders / notifications | Not requested; scope creep (service workers, push permission). | If author misses log days due to forgetting |
| Quantitative logging (minutes, reps) | v1 is binary did-it/didn't. | If binary tracking proves insufficient |
| Habit categories, colors, or icons | Luxury / theming; does not move core job. | After 2+ weeks of daily use |
| Export data as JSON | Useful as a backup mechanism, not as sync. Low priority until data loss is a real concern. | After first month of accumulated data |
| Edit / backdate past entries | Secondary flow; v1 supports toggling today only. | If the user regularly forgets to log on the same day |

## Decisions
| # | Decision | Date | Record |
|---|----------|------|--------|
| 1 | Use localStorage for v1 persistence | 2026-04-22 | [record](roadmap/decisions/001-localstorage-persistence.md) |
| 2 | Bundle scaffold + store + log + streak into one shippable item | 2026-04-22 | [record](roadmap/decisions/002-bundle-phase-1-mvp.md) |
| 3 | Next.js App Router with client components for interactive surfaces | 2026-04-22 | [record](roadmap/decisions/003-app-router-client-components.md) |
