# Ideate Quick Add — Transcript

## Mode detected
Quick Add (existing Vision + Roadmap, single concrete user request for a new item in Phase 2).

## User request
> "Quick add to the roadmap: when a user's session expires while they're writing, they lose their draft. Add an item: let users export their draft as a JSON file they can re-upload later. I want this in Phase 2."

## Context read (treated as pre-existing)
- `docs/VISION.md` — solo-founder note-taking web app, Next.js + Postgres, email auth.
- `docs/ROADMAP.md` — Phase 1 (auth, create/edit/delete note) done; Phase 2 (sharing, folders) in progress.
- Stack note: drafts live only in React component state. No autosave, no server-side draft persistence.

## Assumed clarifications (per eval defaults)
- Draft exists only in React state — no autosave today. (confirmed)
- Users are frustrated enough to ask for the feature themselves. (confirmed)
- User is open to alternatives if there is a better way. (confirmed)

Next available ID in Phase 2: **2.3** (2.1 sharing, 2.2 folders already in progress).

---

## CHALLENGE phase — did it fire?

**YES. CHALLENGE fired and flagged the proposed JSON-export item as a roadmap workaround under axis 1 (NO WORKAROUND), axis 3 (NO OVERENGINEERING — "roadmap workaround" sub-category), axis 4 (WORLD-CLASS BEST PRACTICE), and axis 5 (OPTIMIZED).**

### 5-axis rubric applied to the originally-requested item
*"2.3 Export draft as JSON for re-upload"*

| Axis | Verdict | Why |
|---|---|---|
| 1. NO WORKAROUND | **FAIL (CRITICAL)** | Root cause is that drafts live only in React state and vanish on session expiry. The direct fix is *persisting* the draft. Manual export-to-file is the textbook "route around the missing capability" pattern called out explicitly in the skill's rubric. Users will not reliably click Export before a silent session timeout — the failure mode the item is supposed to fix will still happen. |
| 2. NO GUESSWORK | Pass | User confirmed the problem, the current state (React-only), and openness to alternatives. No silent assumptions. |
| 3. NO OVERENGINEERING | **FAIL (HIGH)** | The skill defines "roadmap workaround" as an overengineering failure — an item that routes around a missing capability instead of building it. JSON-file export is exactly that shape. |
| 4. WORLD-CLASS BEST PRACTICE | **FAIL (HIGH)** | A senior team at a top note-taking product in 2026 does not solve "session expired, draft lost" with a manual export button. The industry standard is debounced autosave (localStorage for instant recovery + server-side draft persistence keyed to user or anonymous session). Notion, Linear, Gmail, Google Docs all do this. |
| 5. OPTIMIZED | **FAIL (MEDIUM)** | Manual export adds user friction to solve a problem that should be invisible. Autosave ships user-visible value (drafts never lost) with no click required and also unblocks future features (draft history, multi-device continuation). |

### Proposed revision
Replace the workaround item with the direct-path item: **2.3 Draft persistence (autosave + recovery)**.

- Root cause is addressed: drafts survive session expiry because they are already saved.
- It is idiomatic for the 2026 note-taking app category.
- It is strictly simpler for the user (zero clicks) while being roughly equivalent effort for the solo founder: debounced write to a `note_drafts` row keyed by `user_id + note_id`, plus an immediate localStorage mirror for offline / pre-auth recovery.
- It creates leverage for future Phase 2+ items (draft history, cross-device continuation, collaborative editing groundwork).

JSON export/import is not retained even as a backlog item — it does not solve a problem that remains after autosave lands. If a "take my data out" need surfaces later, it belongs under a general Export/Backup item, not under a draft-loss story.

### User-facing diff (what would be shown)

```
## Pressure test results
Solo pass: 1 finding, 1 fixed (CRITICAL)

Changes applied to the plan:
- 2.3: REPLACED "Export draft as JSON for re-upload" with "Draft persistence (autosave + recovery)"
  Triggered axes: NO WORKAROUND (critical), NO OVERENGINEERING (roadmap workaround),
  WORLD-CLASS BEST PRACTICE, OPTIMIZED.
  Reason: the JSON-export item routes around the missing capability (persistence) instead
  of building it, and relies on the user clicking Export before the very session timeout
  the item is meant to protect against.

Remaining open questions (your call):
- Scope of autosave recovery UI: silent restore on reload vs. "We recovered your draft from
  [time]. Keep / discard?" banner. Recommendation: banner, because silent restore can
  surprise users who intentionally abandoned a draft.
- Anonymous drafts (pre-login typing): localStorage-only now, server-side later. Acceptable?
```

Per eval constraints, confirmation is granted and the plan proceeds with the revised item.

### Did I change the plan?
**Yes.** The item that ships to `docs/roadmap/phase-2/` is **2.3 Draft persistence (autosave + recovery)**, NOT the originally-requested JSON-export item.

### Before / After

**Before (user's literal request):**
- 2.3 Export draft as JSON — user can click "Export Draft", get a `.json` file, and later click "Import Draft" to restore it into the editor.

**After (post-CHALLENGE):**
- 2.3 Draft persistence (autosave + recovery) — drafts are debounced-autosaved to a server `note_drafts` row and mirrored to `localStorage`. On return after session expiry, the user is offered a "Recover draft from {time}" banner. Session-expiry no longer loses work without any user action.

---

## Files written
- `outputs/docs/roadmap/phase-2/2.3-draft-persistence.md` — new item spec
- `outputs/docs/ROADMAP.md` — updated index (new row for 2.3)
