---
id: 001
title: "Local-first storage via localStorage"
date: 2026-04-14
status: accepted
---

# 001 Local-first storage via localStorage

## Context
The app is a solo, single-user habit tracker. The user explicitly said "local-first is fine, data in localStorage initially." There is no requirement for multi-device access, backup, or multi-user collaboration in Phase 1.

## Decision
Store all habits and completions in the browser's `localStorage`. No database, no API routes for persistence, no auth. Access is gated behind a small store module (`lib/habits/store.ts`) so a future migration to a server-backed store can replace the implementation without touching the UI.

## Alternatives Considered

### Vercel Postgres / Neon + Drizzle
- Pros: proper backups, multi-device sync, schema migrations.
- Cons: requires accounts, auth, env vars, infra cost and setup; the user did not ask for any of this.
- Why rejected: violates the "build exactly what was asked" principle and adds significant scope.

### IndexedDB (via idb or Dexie)
- Pros: larger storage quota, structured queries, works for large datasets.
- Cons: overkill for tens of habits and hundreds of completions; async API makes the store module more complex.
- Why rejected: localStorage fits within expected data volumes and keeps the store synchronous and simple.

### File-based JSON via File System Access API
- Pros: user owns the file, portable backup.
- Cons: poor browser support (Safari), extra UX for opening/saving files.
- Why rejected: hurts the one-tap daily loop.

## Consequences
- The daily loop stays fast and offline-capable after first load.
- Data is tied to one browser profile on one device — losing it is a real risk the user has accepted.
- Future cloud sync is possible but is an explicit Phase 2+ effort, not a surprise.
- The store module must be the only place that touches `localStorage`, to keep migration cheap.
