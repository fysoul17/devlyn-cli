---
id: "002"
title: "Client-rendered pages with a server layout shell"
status: accepted
date: 2026-04-14
---

# 002 — Client-rendered pages with a server layout shell

## Decision
`app/layout.tsx` is a Server Component (the default). `app/page.tsx` and `app/history/page.tsx` use `'use client'` at the top of the file. Data loading (`localStorage`) and all interactive state live in client components. No Server Actions, no route handlers for data, no Server Components reading from storage.

## Why
All application data lives in `window.localStorage`, which is only available in the browser. Rendering any habit data on the server would require either:
(a) pretending there is no data during SSR and hydrating on the client anyway, or
(b) a full backend — which is an explicit anti-goal.

Option (a) is exactly what this decision codifies: the page is a client component whose initial render is the empty skeleton, and a `useEffect` on mount reads `localStorage` and populates state. This avoids hydration mismatches because both server and first client render produce the same skeleton.

Keeping the root layout as a Server Component preserves Next.js best practices (the app shell is still streamed/prerendered, fonts and metadata handled server-side) while keeping the interactive leaves on the client.

## Alternatives considered
1. **Entire app as client-only (`'use client'` in layout)** — rejected: loses server-rendered fonts/metadata and bundles the shell into the client unnecessarily. The principle from the user's global instructions is "build the server component first where possible and implement client component as deep as possible" — this decision honors that by keeping the client boundary at the page level, not the layout level.
2. **Server Components + API routes reading from a database** — rejected: explicit anti-goal. No backend.
3. **Server Components reading a cookie-backed store** — rejected: introduces a serialization format and middleware just to avoid localStorage, with no user-visible benefit.

## Consequences
- The user sees a brief empty state before their habits appear on first load. Acceptable for a personal tool; mitigate with a loading skeleton if it ever becomes noticeable.
- Static export (`output: 'export'`) would work if desired, but deploying on Vercel as a normal Next.js app is simpler and equivalent here.
- No Suspense boundaries needed for data — the data arrives via `useEffect`, not via an async boundary.
