---
id: T.1
complexity: low
priority: low
depends-on: []
source-spec: docs/roadmap/phase-test/T.1-footer-copyright.md
---

## Customer Frame
When a visitor lands on the site, they want to see basic trust signals, so they can verify the site is real.

## Objective
A footer appears at the bottom of every marketing page showing `© 2026 Devlyn. All rights reserved.`

## Requirements
- [ ] Footer component renders on marketing pages
- [ ] Text is `© 2026 Devlyn. All rights reserved.`
- [ ] Responsive on mobile

## Constraints
- No new dependencies — Why: trivial scope, no libraries needed

## Out of Scope
- Footer links (Phase 2)
- Newsletter signup (Phase 3)

## Architecture Notes
(none)

## Dependencies
- **Internal**: (none)
- **External**: (none)

## Verification
- [ ] Visit a marketing page, see the footer
