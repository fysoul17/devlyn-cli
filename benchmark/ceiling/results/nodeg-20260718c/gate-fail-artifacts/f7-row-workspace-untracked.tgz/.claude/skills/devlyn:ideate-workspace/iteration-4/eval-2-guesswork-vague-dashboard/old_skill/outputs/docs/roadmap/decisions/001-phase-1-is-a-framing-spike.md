---
id: 001
title: "Phase 1 is a framing spike, not a feature"
date: 2026-04-22
status: accepted
---

# 001 Phase 1 is a framing spike, not a feature

## Context
The originating prompt — "I want to improve our dashboard. Plan the next phase." — contains no audience, no pain statement, no success criterion, no tech stack, no current-state description, and no timeframe. A multi-item feature roadmap built from that prompt would be speculation.

## Decision
Phase 1 contains exactly one item: a short discovery spike that produces a written brief. No feature work until the brief is approved by the stakeholder.

## Alternatives Considered

### Alternative 1 — Invent a conventional dashboard improvement plan (performance + IA redesign + theming)
- Pros: Looks productive; fills the roadmap; gives auto-resolve something to implement immediately.
- Cons: Every item would be speculation; likely solves the wrong problem; wastes implementation budget; creates stale roadmap rows that must later be deleted or reworked.
- Why rejected: Fails the NO GUESSWORK axis of the CHALLENGE rubric. The cost of building the wrong thing is larger than the cost of asking a few questions.

### Alternative 2 — Do nothing; refuse to produce a roadmap until the user clarifies
- Pros: Absolute honesty about what's unknown.
- Cons: User asked for a plan; returning "I need more info" with no artifact is unhelpful and offloads all the framing work back on the user.
- Why rejected: A framing spike is the minimum artifact that advances the work without inventing content. It also gives the user a concrete list of questions to answer, which is more useful than a raw refusal.

### Alternative 3 — Proceed with a full guess and mark everything [ASSUMED]
- Pros: Produces artifacts downstream phases could in principle use.
- Cons: Creates a tempting "already planned" roadmap that the team may quietly act on without ever answering the questions, which is the exact failure mode the NO GUESSWORK axis exists to prevent.
- Why rejected: A one-item framing phase forces the questions to be answered before anything else happens. Better forcing function than a fully-guessed plan.

## Consequences
- Phase 1 visibly ships no user-facing feature — the phase's "deliverable" is clarity. This is a conscious tradeoff against the OPTIMIZED axis of the rubric, accepted because the problem is not yet defined well enough to ship a feature honestly.
- The stakeholder must allocate time for an interview / questionnaire before Phase 2 can be planned.
- Several conventional candidates (performance, redesign, theming) are explicitly parked in the backlog rather than being picked up; this prevents them from drifting into an undefined Phase 2.
- This decision should be revisited (status: superseded) if the stakeholder delivers a detailed brief themselves, in which case Phase 1 can become a feature phase directly.
