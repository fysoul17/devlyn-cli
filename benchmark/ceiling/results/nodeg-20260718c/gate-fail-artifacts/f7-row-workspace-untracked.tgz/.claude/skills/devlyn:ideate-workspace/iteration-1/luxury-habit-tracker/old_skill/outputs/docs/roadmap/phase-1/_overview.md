# Phase 1: Core Loop

## Goal
Ship a working habit tracker that does exactly three things the user asked for:
1. Log that a habit was done today
2. See the current streak for each habit
3. See history of past completions

## Constraints that apply to every item in this phase
- Next.js (latest stable) with App Router
- TypeScript, strict mode
- Tailwind CSS + shadcn/ui components
- Data stored only in `localStorage` — no database, no API, no auth
- Deployed to Vercel
- Solo user; no multi-user model, no accounts, no sharing
- Server Components by default; `'use client'` only where interactivity / localStorage access is required (push client boundaries as deep as possible)

## Sequencing
1.1 Scaffold → 1.2 Store → 1.3 Log Today → 1.4 Streak → 1.5 History → 1.6 Manage Habits → 1.7 Deploy

1.3, 1.4, 1.5 all depend on 1.2 (the store) being in place. 1.6 is last among features because the app is usable with a single hardcoded habit before then — it just needs management once the loop proves out.

## Out of Scope for Phase 1
Anything not in the 7 items above. Ideas go to the Backlog, not into Phase 1 items. See VISION.md Anti-Goals.
