---
id: 003
title: "Ownership model: one owner per prospect, whole team can view"
date: 2026-04-22
status: accepted
---

# 003 Ownership model

## Context
The team has ~8 reps with individual books. We need to decide: who can see what, who can edit what, and how ownership is represented.

## Decision
- Each `prospects` row has exactly one `owner_id` (Clerk user id of the rep who owns the prospect).
- **Read access**: any signed-in team member can read any prospect (enables the team cold board in 2.1).
- **Write access**: only the owner can edit a prospect or log a touchpoint against it. Enforced server-side in every mutating Server Action — never relying on UI hiding alone.
- **No multi-owner, no team-wide ownership, no handoff workflow** in v1. If a rep leaves or a prospect needs reassignment, it happens via direct DB update (acceptable for 8 people) and is surfaced as a backlog item if it becomes frequent.

## Alternatives Considered

### Private prospects (only owner can read)
- Pros: stronger privacy between reps.
- Cons: kills the team cold board (2.1) which is the whole reason to move past the spreadsheet. The team already shared a spreadsheet — they're used to shared visibility.
- Why rejected: the "team visibility" job is part of the core value prop; losing it would reduce the app to a personal tracker.

### Multi-owner (multiple reps can own + edit)
- Pros: supports account teams, co-selling.
- Cons: adds a join table, permission complexity, and unclear tie-breaking on conflicting edits; the user said "sales team is ~8 people" with no mention of shared accounts.
- Why rejected: no stated need; can be added later without disrupting the one-owner model (a `prospect_collaborators` table is additive).

### Manager role with elevated write access
- Pros: lets a manager correct bad data without bothering the rep.
- Cons: introduces role management, an admin UI, and the question of who grants manager status.
- Why rejected: overengineering for 8 people. In v1 managers can ask reps to fix their own data or use direct DB access. Revisit if reps request it.

## Consequences
- The `owner_id` column is required and not null on every `prospects` insert.
- Every Server Action that mutates a prospect or a touchpoint must re-check `prospects.owner_id == auth user id`. This check is the security boundary — not the UI.
- The team cold board (2.1) can render every cold prospect without permission branching, which keeps the query simple.
- Future features (handoff, collaborators, manager role) are additive changes to this model, not rewrites.
