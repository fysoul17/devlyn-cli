---
id: 003
title: "Single-page layout with inline entry and list (no per-view routing in v1)"
date: 2026-04-22
status: accepted
---

# 003 Single-page layout with inline entry and list (no per-view routing in v1)

## Context
Traditional finance / expense apps separate "Add expense" from "View expenses" into different screens or routes. For a solo-founder personal tool with the stated North Star of "log in under 10 seconds", navigation between screens is friction. We need to decide whether v1 uses any client-side routing at all.

## Decision
v1 is a single page (`/`) with the entry form, the expense list, the totals panel, and the CSV export button all visible simultaneously. No modal, no separate route for adding, no separate route for viewing history. On mobile (375px), the form stacks above the list; totals collapse underneath.

## Alternatives Considered

### Separate `/add` and `/expenses` routes
- Pros: cleaner separation of concerns; easier to scale each view independently.
- Cons: every log requires a route change; breaks the "open and log" speed goal; adds back-button behavior to reason about.
- Why rejected: contradicts the North Star directly.

### Modal "Add expense" on top of the list
- Pros: keeps list visible; matches common UX pattern (Notion, Linear).
- Cons: adds a second click (open modal) before the freelancer can even type an amount; focus management on modal open/close is a classic accessibility footgun; purely decorative at this scope.
- Why rejected: extra click costs us the 10-second target.

### Tab-based layout (Add / History / Settings)
- Pros: scales to more views over time.
- Cons: premature for two features; settings screen doesn't exist yet.
- Why rejected: building for imagined future scale is axis-3 overengineering.

## Consequences
- The fastest possible path from "open app" to "expense saved" — no navigation at all.
- The page will get busy if Phase 2 adds filters, charts, and editing. Plan: when that happens, move list → totals → export into a sidebar / secondary section while keeping the entry form primary. That's a Phase 2 concern, not a v1 concern.
- No `next/navigation` or per-view routes in v1 — smaller surface area, fewer moving parts.
- Mobile layout needs to fit form + list + totals in one viewport without feeling cramped. Documented in 1.1 requirements as a testable constraint (375px viewport, no horizontal scroll).
