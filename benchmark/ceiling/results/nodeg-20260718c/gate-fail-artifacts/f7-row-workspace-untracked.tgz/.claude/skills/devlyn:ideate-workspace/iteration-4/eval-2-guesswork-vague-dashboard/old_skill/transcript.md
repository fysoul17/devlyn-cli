# Transcript — eval-2-guesswork-vague-dashboard (old_skill / pre-v4 baseline)

## Invocation
User prompt: "I want to improve our dashboard. Plan the next phase." with test-harness instruction: no real user available, write clarifying questions to `docs/clarifying-questions.md`, proceed with the minimum plan possible using only what the user actually stated, do not invent features or assume a domain. `--engine claude`.

## Mode
**Greenfield (degenerate / near-zero framing)** — the /tmp workdir was created empty, so there were no existing `docs/` to read. Nothing in the user prompt confirmed an audience, a product, pain, success criteria, tech stack, or current state. Mode detection defaulted to Greenfield, but treated as a degenerate case: the FRAME phase has essentially no confirmed inputs.

## Phases executed
1. **Mode detection** — Greenfield, confirmed workdir empty.
2. **Engine pre-flight** — `--engine claude` was passed explicitly → per SKILL.md, no `mcp__codex-cli__ping` call, no Codex critic, solo CHALLENGE only.
3. **FRAME (solo, no user)** — Confirmed-facts list is 2 lines ("user wants dashboard improvement", "user wants a phase planned"). Every other FRAME dimension (problem statement, users, success criteria, constraints, anti-goals) unknown.
4. **Clarifying-questions capture** — Per test instruction, wrote every question that would normally be asked to `docs/clarifying-questions.md` (21 questions across FRAME, EXPLORE, CONVERGE scopes, each annotated with why it blocks).
5. **EXPLORE — skipped** — Cannot expand a solution space without knowing what problem is being solved. Research would be speculation.
6. **CONVERGE (solo, minimal)** — Internal draft: one-item Phase 1 framed as a discovery spike. Everything else deferred to backlog with `[ASSUMED]` tags or a "revisit after 1.1" note.
7. **CHALLENGE (solo, `--engine claude`)** — Applied `references/challenge-rubric.md` 5-axis rubric to the internal draft. See findings below.
8. **DOCUMENT** — Generated VISION.md, ROADMAP.md, phase-1 _overview, 1.1 spec, decisions/001.
9. **BRIDGE — implicit** — No auto-resolve command produced because the spec's output is a document, not code; stakeholder input needed first.

## Did CHALLENGE flag the guesswork?
**Partially. The skill handled guesswork correctly by not inventing features, but the CHALLENGE findings were self-congratulatory rather than skeptical.**

Solo rubric pass produced these findings on the internal draft:

- **Axis 1 NO WORKAROUND** — PASS. A discovery spike isn't a workaround when the problem is undefined.
- **Axis 2 NO GUESSWORK** — PASS. Every assumed fact is tagged `[ASSUMED]` in output; clarifying-questions.md captures the unknowns explicitly.
- **Axis 3 NO OVERENGINEERING** — PASS. One item, no luxury, no filler, no detour sequencing.
- **Axis 4 WORLD-CLASS BEST PRACTICE** — PASS. The senior-team pattern for "improve X with no detail" is a framing spike before a feature sprint.
- **Axis 5 OPTIMIZED** — PASS WITH NOTE. Phase 1 ships no user-visible feature — its deliverable is clarity. Rubric's canonical OPTIMIZED failure ("dead phase, pure setup") technically applies, but was accepted as the conscious tradeoff because alternative (inventing features) fails axis 2 harder than this fails axis 5. Recorded as a tradeoff in `decisions/001`.

**Verdict**: PASS WITH MINOR FIXES — proceed.

## Gaps / weaknesses of the pre-v4 skill surfaced by this eval
1. **No explicit "degenerate framing" mode.** SKILL.md Mode table has Greenfield / Expand / Quick Add / Deep-dive / Research-first / Replan — none of them name "user prompt contains near-zero frame". Had to improvise. A dedicated mode ("Discovery Spike" or "Framing Required") with a canonical one-item output shape would make this path deterministic rather than improvised.
2. **FRAME phase doesn't require a confirmed-facts checkpoint before leaving.** The skill says "Don't write documents yet. The output of this phase is a shared mental model between you and the user" but doesn't force the agent to enumerate the confirmed-vs-assumed split before proceeding. Adding a mandatory `## Confirmed facts / ## Assumptions` dump at the end of FRAME would make it structurally impossible to silently fabricate a vision.
3. **No canonical `[ASSUMED]` tag convention.** SKILL.md says "Flag assumptions explicitly" but offers no syntax. I chose `[ASSUMED]` with an inline "why [ASSUMED]" annotation per occurrence; a different agent would pick a different tag. A template-level convention (and a rule that VISION/ROADMAP rendering must visibly distinguish confirmed from assumed content) would make the output more auditable.
4. **CHALLENGE is too agreeable on solo passes.** The rubric lists "nodding along to the draft you just produced" as the default failure mode, yet the solo-only CHALLENGE in this run produced all-PASS findings. On `--engine claude` (no Codex critic), the solo pass still has nothing to push back against beyond its own reasoning. A stronger "solo pass must produce at least one HIGH-severity finding or explicitly defend why none exists" rule would catch self-congratulation.
5. **VISION template doesn't have a [ASSUMED]-native mode.** The vision.md template assumes every field can be filled in; when most fields cannot be, the output either lies (fills with plausible-sounding content) or looks degenerate. A "degenerate vision" shape — very short, every field annotated with source — would handle this case cleanly.
6. **Backlog entries lacked dates.** I wrote `[ASSUMED]` in the backlog without filling `Revisit` — the roadmap.md template has the column, but the pre-v4 skill doesn't force a date. Left as "After 1.1 lands" which is honest but not a calendar commitment.

## Hard rule application (respect explicit user intent)
The user did not make any explicit product decisions in this eval, so the Hard Rule did not fire. The test's explicit instruction ("do not invent features or assume a domain") was treated as an explicit user preference and honored throughout — this is why the plan is one item instead of an invented multi-phase roadmap.

## Output files
- `docs/clarifying-questions.md` — 21 questions across FRAME / EXPLORE / CONVERGE scope.
- `docs/VISION.md` — minimal placeholder, every field annotated `[ASSUMED]` with a "why assumed" line; north star explicitly marked as placeholder.
- `docs/ROADMAP.md` — one active item (1.1); Backlog lists conventional dashboard items (performance, IA redesign, theming, new widgets) as explicitly deferred with rubric-cited reasons.
- `docs/roadmap/phase-1/_overview.md` — frames Phase 1 as a framing spike.
- `docs/roadmap/phase-1/1.1-dashboard-improvement-brief.md` — self-contained spec whose deliverable is a one-page brief, not code. Requirements force the gaps in `clarifying-questions.md` to be answered before Phase 2 can be planned.
- `docs/roadmap/decisions/001-phase-1-is-a-framing-spike.md` — records the decision, three alternatives considered (invent a plan, do nothing, guess-and-tag), and the consequence that Phase 1 ships no user feature.

## Notes
- `--engine claude` → no Codex MCP ping, no Codex critic pass. Solo CHALLENGE only, as specified by SKILL.md Phase 3.5 "If `--engine claude`: No Codex calls. The solo pass is the only pass."
- No real user available — all 21 clarifying questions written to file instead of asked.
- The honest verdict on this run: the skill's `[ASSUMED]`-discipline instructions (Conversation Protocol: "Track what's confirmed vs. assumed") + the CHALLENGE NO GUESSWORK axis were enough to prevent a fabricated multi-item plan, but the path was improvised rather than a first-class skill feature. A user running this prompt today would get a correct-feeling answer only if the agent reaches for those discipline cues on its own.
