# Prospect Pulse Roadmap

> **North Star**: Give an 8-person sales team instant visibility into which prospects are going cold, so no deal dies from neglect.

## Phase 1: Replace the Spreadsheet (Target: 3-4 weeks)
Ship a shared prospect list with visible staleness and fast touch logging, plus a one-shot import from the existing spreadsheet. At the end of Phase 1 the team can stop using the spreadsheet.

| # | Feature | Status | Priority | Complexity | Spec |
|---|---------|--------|----------|-----------|------|
| 1.1 | Shared prospect list with staleness + touch logging | Planned | High | High | [spec](roadmap/phase-1/1.1-shared-prospect-list.md) |
| 1.2 | Spreadsheet CSV import | Planned | High | Medium | [spec](roadmap/phase-1/1.2-csv-import.md) |

## Phase 2: Close the Cold Loop (Target: 2-3 weeks after Phase 1)
Once the team is on the product, turn staleness from a passive indicator into an active nudge, and make ownership and reassignment explicit.

| # | Feature | Status | Priority | Complexity | Spec |
|---|---------|--------|----------|-----------|------|
| 2.1 | Cold-prospect alerts (in-app + email digest) | Planned | High | Medium | [spec](roadmap/phase-2/2.1-cold-alerts.md) |
| 2.2 | Prospect ownership and reassignment | Planned | Medium | Medium | [spec](roadmap/phase-2/2.2-ownership-reassignment.md) |

## Backlog
| Feature | Reason Deferred | Revisit |
|---------|----------------|---------|
| Email/calendar integration for auto-logged touches | Reduces logging friction but is a large integration; prove the manual-log loop first. | After Phase 2 ships and staleness coverage metric is measured |
| Pipeline stage / deal value tracking | Expands scope toward full CRM; staleness is the primary job, stages are secondary. | After 4 weeks of real usage reveal whether stages are missed |
| Activity timeline per prospect | Nice-to-have history view; the touch-log + latest-touch columns cover 80% of the job. | When users explicitly ask for historical context beyond "last touch" |
| Mobile-optimized UI | Desktop is the primary workflow; mobile is a different product. | If usage data shows meaningful mobile traffic |

## Decisions
| # | Decision | Date | Record |
|---|----------|------|--------|
| 1 | Next.js App Router on Vercel, Neon Postgres, Clerk for auth | 2026-04-22 | [record](roadmap/decisions/001-stack.md) |
| 2 | Staleness is computed, not stored | 2026-04-22 | [record](roadmap/decisions/002-computed-staleness.md) |
| 3 | Clerk Organizations model the sales team workspace | 2026-04-22 | [record](roadmap/decisions/003-clerk-organizations.md) |
