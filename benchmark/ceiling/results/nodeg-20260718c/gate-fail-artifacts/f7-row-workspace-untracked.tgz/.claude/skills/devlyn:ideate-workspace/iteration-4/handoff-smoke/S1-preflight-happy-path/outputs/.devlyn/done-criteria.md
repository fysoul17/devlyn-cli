# Done Criteria

Source: `.devlyn/SPEC-CONTEXT.md` (spec T.1 — Add favicon to site)

## Requirements
- [ ] Create app/icon.png at 32x32px, transparent background
- [ ] Icon shows the brand logo in the brand color
- [ ] Next.js auto-serves it at /favicon.ico via file-based metadata

## Out of Scope
- Full PWA manifest (Phase 3)
- Multi-size icon generation (Phase 2)

## Verification Method
- [ ] /favicon.ico returns the icon in a browser
