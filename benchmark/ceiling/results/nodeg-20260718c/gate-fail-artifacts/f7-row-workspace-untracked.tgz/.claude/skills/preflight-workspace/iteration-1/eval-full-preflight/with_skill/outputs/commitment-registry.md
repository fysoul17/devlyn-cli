# Commitment Registry
Generated: 2026-04-09
Scope: All phases
Total commitments: 35

## Phase 1: Core Foundation

### 1.1 User Authentication (spec status: done)
- [FEATURE] User can sign up with email and password
- [BEHAVIOR] Email format validated on signup
- [BEHAVIOR] Password minimum 8 characters, validated on signup
- [FEATURE] User can log in with existing credentials
- [BEHAVIOR] Failed login returns 401 with specific error message
- [FEATURE] JWT-based session management
- [FEATURE] Logout invalidates the session
- [CONSTRAINT] Passwords hashed with bcrypt
- [CONSTRAINT] JWT tokens expire after 24 hours

### 1.2 Task CRUD (spec status: done)
- [FEATURE] User can create a task with title and description
- [FEATURE] User can view all their tasks in a list
- [FEATURE] User can update task title, description, and status
- [FEATURE] User can delete a task with confirmation dialog
- [BEHAVIOR] Task statuses: todo, in-progress, done
- [BEHAVIOR] Tasks display creation date and last modified date
- [CONSTRAINT] Only task owner can edit/delete

### 1.3 Task Assignment (spec status: in-progress)
- [FEATURE] Task owner can assign a task to another user by email
- [BEHAVIOR] Assigned user receives an email notification
- [BEHAVIOR] Assigned user sees the task in their task list
- [BEHAVIOR] Task detail shows assignee name and avatar
- [FEATURE] Unassign action available to task owner
- [CONSTRAINT] Only existing users can be assignees

### Phase 1 Vision-level commitments (from VISION.md)
- [FEATURE] Teams can create, assign, and track tasks
- [FEATURE] Secure authentication with team-based access control

## Phase 2: Collaboration

### 2.1 Real-time Updates (spec status: planned)
- [FEATURE] WebSocket connection established on page load
- [BEHAVIOR] Task list updates in real-time when any task changes
- [BEHAVIOR] Task detail view updates when the viewed task is modified
- [BEHAVIOR] Connection status indicator (connected/reconnecting/offline)
- [BEHAVIOR] Graceful reconnection with exponential backoff
- [CONSTRAINT] Use WebSocket, not polling

### 2.2 Team Management (spec status: planned)
- [FEATURE] User can create a team with a name
- [BEHAVIOR] Team creator becomes team admin
- [FEATURE] Admin can invite members by email
- [BEHAVIOR] Members can view all team tasks
- [FEATURE] Admin can remove members
- [FEATURE] Team settings page for admin
- [CONSTRAINT] One team per user for now

### Phase 2 Vision-level commitments (from VISION.md)
- [FEATURE] Real-time updates when tasks change
- [FEATURE] Clean, responsive UI that works on mobile

## Anti-Commitments (Out of Scope)
- [item 1.1] Does NOT include social login (OAuth) -- Phase 3
- [item 1.1] Does NOT include two-factor authentication -- Backlog
- [item 1.2] Does NOT include drag-and-drop reordering -- Phase 2
- [item 1.2] Does NOT include task categories/labels -- Backlog
- [item 1.3] Does NOT include multiple assignees per task -- Phase 2
- [item 1.3] Does NOT include assignment notifications via push -- Phase 2
- [item 2.1] Does NOT include presence indicators (who's online) -- Backlog
- [item 2.1] Does NOT include typing indicators -- Not planned
- [item 2.2] Does NOT include team roles beyond admin/member -- Phase 3
- [item 2.2] Does NOT include team billing -- Phase 3
