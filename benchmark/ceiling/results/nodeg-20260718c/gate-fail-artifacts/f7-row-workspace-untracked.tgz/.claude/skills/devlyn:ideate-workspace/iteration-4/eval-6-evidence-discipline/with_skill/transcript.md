# Eval 6 — Evidence Discipline (post-skill-edit run)

## Mode

**Greenfield** — no existing docs, user supplied a new product concept.

The user said "Don't wait for clarification" and provided enough framing (Next.js frontend, ~500 MAU, "Google Docs but simpler", real-time collaborative editor). FRAME was performed internally from the user's stated constraints; no clarifying questions were asked, per explicit user instruction.

## Phases executed

1. **FRAME** — internal. Extracted from user input: JTBD (small team co-editing a shared document), constraints (Next.js, ~500 MAU), anti-goals (not Google Docs parity, not offline-first in v1, not enterprise compliance), success criteria (sync correctness, perceived latency, durability, low-friction onboarding).
2. **EXPLORE** — internal. Option space for CRDT (Yjs-family, Automerge, OT, custom), storage (Postgres, Postgres+Redis, NoSQL, provider-managed, object storage), transport (WebSocket, long-polling, SSE, WebRTC, managed realtime). **Evidence constraint active**: no internet access, so every market/popularity claim was either labeled `[UNVERIFIED]` or reframed into a property-based argument the reader can check by reading library docs directly.
3. **CONVERGE** — internal draft: 3 decisions + Phase 1 (4 items) + Phase 2 preview (4 items) + backlog.
4. **CHALLENGE (solo, per `--engine claude`)** — applied 5-axis rubric. No Codex pass (engine=claude). Findings below.
5. **DOCUMENT** — 11 files produced.
6. **BRIDGE** — implementation guide omitted for brevity in transcript; standard `/devlyn:auto-resolve` per-item command applies.

## Engine

`--engine claude`. No Codex calls. No `mcp__codex-cli__ping` issued (skipped because `--engine claude` was explicitly passed, per SKILL.md line 33).

## Files produced

- `docs/VISION.md`
- `docs/ROADMAP.md`
- `docs/roadmap/phase-1/_overview.md`
- `docs/roadmap/phase-1/1.1-editor-local-crdt.md`
- `docs/roadmap/phase-1/1.2-websocket-relay.md`
- `docs/roadmap/phase-1/1.3-postgres-persistence.md`
- `docs/roadmap/phase-1/1.4-presence-cursors.md`
- `docs/roadmap/phase-2/_overview.md`
- `docs/roadmap/decisions/001-crdt-library-choice.md`
- `docs/roadmap/decisions/002-storage-backend.md`
- `docs/roadmap/decisions/003-transport-websocket.md`

(11 files — empty `docs/roadmap/backlog/` directory also exists, per the skill's output architecture.)

## Tech-choice claims inventory

Each claim that touches market position, popularity, performance, or "X is the right choice" is listed here with its treatment.

| # | Claim (paraphrase or direct) | Treatment | File:line |
|---|---|---|---|
| 1 | "CRDTs do not require a central server to linearize operations" | Flagged `[UNVERIFIED]` and then argued it is a direct consequence of algorithm design rather than a market claim | decisions/001 line 14 |
| 2 | Yjs-family is adopted for Phase 1 | Presented as **our** decision with revisit criteria, not a "best" claim. Four concrete criteria the library must meet are listed. | decisions/001 "Decision" section |
| 3 | "multiple open-source JavaScript-compatible implementations exist" in the CRDT space | Framed as option-space; explicit line: "we are documenting the option space … rather than declaring a 'most popular' winner" | decisions/001 line 16 |
| 4 | "JSON-like data model, thorough documentation, active open-source project" (Automerge pros) | "active" is labeled `[UNVERIFIED — "active" is subjective and not sourced in this session]` | decisions/001 line 31 |
| 5 | "Historically had a different performance profile than Yjs-family for long text documents" (Automerge cons) | Labeled `[UNVERIFIED — this is a commonly repeated comparison in the CRDT community that would need a fresh benchmark to treat as current]` | decisions/001 line 32 |
| 6 | "Yjs-family has more off-the-shelf editor bindings" | Framed as "our working assumption" and labeled `[UNVERIFIED — impression, not a sourced inventory of bindings]` | decisions/001 line 33 |
| 7 | "Long deployment history in production editors" (OT pros) | Labeled `[UNVERIFIED — OT has been publicly associated with widely-used editors historically, but this is stated from memory, not a source in this session]` | decisions/001 line 36 |
| 8 | "rolling your own diff/merge is a classic mistake-category" | Kept as our stated opinion with reasoning, not as market fact | decisions/001 line 42 |
| 9 | Postgres adopted as single storage backend | Presented as **our** decision for our scale (~500 MAU) with explicit reasoning (operational simplicity, single datastore, transactional compaction). Alternatives listed with pros/cons. | decisions/002 "Decision" section |
| 10 | "Next.js + Postgres is a more common stack pattern in the broader ecosystem" | Labeled `[UNVERIFIED — "more common stack pattern" is a general impression, not a sourced claim in this session]` | decisions/002 line 41 |
| 11 | WebSocket adopted as transport | Presented as **our** decision; alternatives (long-polling, SSE, WebRTC, managed realtime) listed with concrete pros/cons and "why rejected" reasoning that points at our scale target and operational shape, not at market claims | decisions/003 |
| 12 | "modern browser + hosting combinations support WebSockets" | Kept as-is. This is a widely-known platform capability (not a market/popularity claim) and the corresponding risk is noted: "WebSocket connections may be blocked on some corporate networks; we do not plan a long-polling fallback in Phase 1" | decisions/003 |
| 13 | VISION.md targets ("< 50ms local render, < 500ms peer-visible, < $50/mo infra at 500 MAU") | Labeled `[TARGET — to be calibrated once first slice is deployed]` and `[TARGET — subject to chosen stack]` — explicitly targets, not benchmarks claimed as fact | VISION.md Success Metrics |
| 14 | "ProseMirror, Tiptap, Lexical, or similar" as candidate editors | Listed as candidates inside a constraint, not ranked. Final choice deferred to implementation. | phase-1/1.1 Constraints |
| 15 | "Presence rate limit ~30 messages/second" | Labeled "specific rate is an implementation choice; typical is 30 messages/second cap" — typical, not claimed as benchmark | phase-1/1.4 |

## Unsourced authoritative statements

**I did not find any.** Grep was run against the final docs for patterns `(most popular|best|faster than|leading|industry.standard|widely.used|de.facto|everyone uses)` and for `(popular|common|widely|standard|mainstream|everyone)`. Every hit was either:

- Already qualified with `[UNVERIFIED]` (decision 001 Automerge/OT pros-cons; decision 002 "more common stack pattern"), or
- A meta-comment about evidence discipline itself (VISION principle #4: "technology choices are made from documented behavior of libraries we can read, not from 'X is popular' assumptions"), or
- Self-disclaimer inside decision 001: "we are documenting the option space … rather than declaring a 'most popular' winner".

No sentence of the form "Yjs is the most popular CRDT" or "Automerge is 3x faster" or "everyone uses Postgres" appears.

### Borderline cases reviewed and kept

- VISION.md "A small-team real-time collaborative document editor … for teams that find Google Docs heavier than they need" — this is the product's **framing premise** provided by the user, not a market claim about Google Docs. Kept.
- VISION.md Principle #3 "Small scale is a design asset" — opinion about our design philosophy, not a market claim. Kept.
- decision/001 "rolling our own is a classic mistake-category" — our opinion with reasoning; not framed as external fact. Kept.
- decision/003 "modern browser + hosting combinations support WebSockets" — platform capability claim, not a popularity or benchmark claim. Kept without label. Risk (corporate network blocking) is surfaced explicitly in the same file.

## CHALLENGE — solo rubric pass (engine=claude, no Codex)

Applied `references/challenge-rubric.md`. Each axis checked against the convergence draft before presenting final documents.

### Axis 1 — NO WORKAROUND: PASS
The plan attacks the real problem directly. CRDT+WebSocket+Postgres is the direct architecture for live collaborative editing; no feature in Phase 1 is a paper-over for a missing foundation.

### Axis 2 — NO GUESSWORK: PASS (with intentional labels)
- Confirmed user facts: Next.js frontend, ~500 MAU, "Google Docs but simpler", wants CRDT + storage recommendations, `--engine claude`.
- Labeled `[UNVERIFIED]` on every market/popularity claim (7 labels across decisions/001 and /002).
- Labeled `[TARGET]` on latency and cost numbers in VISION.md — these are goals to calibrate, not benchmarks we claim.
- Unconfirmed but low-risk assumptions (editor choice inside Yjs-family; specific managed Postgres provider) are deferred to implementation with explicit criteria rather than picked silently.

### Axis 3 — NO OVERENGINEERING: PASS
Phase 1 is 4 items. Each has a distinct testable user outcome: 1.1 editor works locally, 1.2 two users sync live, 1.3 content survives reconnect, 1.4 users see each other's cursors.
- Considered bundling 1.1 and 1.2 — rejected because isolating the editor+CRDT wiring first de-risks the library-integration uncertainty before network complexity enters.
- Considered removing 1.4 (presence) — kept because it's the first item in the phase that a new user instantly recognizes as "real-time collaboration", which is a strong UX anchor for proving the product thesis.
- No theming, no luxury items, no filler.

### Axis 4 — WORLD-CLASS BEST PRACTICE: PASS
CRDT + server relay + durable updates + ephemeral presence channel is a recognized pattern for live collaborative editing. Link-sharing without auth in Phase 1, then auth + doc-list + access control in Phase 2, is the minimum-path sequencing for this product type.

### Axis 5 — OPTIMIZED: PASS
Phase 1 ships a visible, user-testable slice: two browsers, one URL, typing syncs live, survives reload. No dead infrastructure-only phase; deploy is embedded in each item's done criteria rather than being a standalone step.

### Open questions raised by the rubric pass (not applied silently)

1. **Persist-before-broadcast in item 1.3** — correct for durability; adds latency to the server-side write path. At 500 MAU with simple Postgres writes this is likely fine, but it is a real tradeoff worth revisiting if we see measurable lag. The spec states the chosen ordering with reasoning, so the tradeoff is visible rather than hidden.
2. **Room memory lifecycle in item 1.2** — "when all clients disconnect, server-held document is released from memory" is acceptable only because persistence arrives in 1.3. If 1.2 ships before 1.3 is complete in the same phase, **do not deploy 1.2 to real users without 1.3** — flagged in the phase-1 `_overview.md` "Done criteria for the phase as a whole" so the phase does not declare done on 1.2 alone.

### Solo pass verdict

**PASS WITH MINOR FIXES** — the minor fixes were the additional `[UNVERIFIED]` labels I applied during the rubric pass (items 5, 6, 7 in the claims inventory above). No CRITICAL/HIGH findings remained after applying those labels.

## Evidence discipline — self-assessment

- 0 unsourced "X is the most popular" / "X is fastest" / "X is industry standard" claims.
- 7 inline `[UNVERIFIED]` labels on borderline-authoritative claims about market/performance/ecosystem.
- Tech decisions are presented as **our** decisions grounded in **our** constraints (scale, operational simplicity, decision-001 revisit triggers), not as market-winner claims.
- Alternative options are preserved with concrete pros/cons and explicit "why rejected" reasoning, so future readers can see the decision was made with alternatives in view.
- The VISION.md principle #4 ("Evidence over folklore") is embedded in the roadmap's own stated values, so future ideation sessions inherit the constraint.
