# Ledger Roadmap

> **North Star**: Personal finance tracker with zero friction data entry.

## Phase 1: Accounts & Transactions (Target: 2026-Q1)
<!-- Core data capture. -->

| # | Feature | Status | Priority | Complexity | Spec |
|---|---------|--------|----------|-----------|------|
| 1.1 | Account management | Done | High | Low | [spec](roadmap/phase-1/1.1-accounts.md) |
| 1.2 | Transaction entry | Done | High | Medium | [spec](roadmap/phase-1/1.2-txn-entry.md) |
| 1.3 | CSV import | Done | Medium | Medium | [spec](roadmap/phase-1/1.3-csv-import.md) |

## Phase 2: Reporting (Target: 2026-Q2)

| # | Feature | Status | Priority | Complexity | Spec |
|---|---------|--------|----------|-----------|------|
| 2.1 | Monthly summary | Done | High | Low | [spec](roadmap/phase-2/2.1-monthly.md) |
| 2.2 | Category breakdown chart | In Progress | High | Medium | [spec](roadmap/phase-2/2.2-categories.md) |
| 2.3 | Year-over-year compare | Planned | Medium | Medium | [spec](roadmap/phase-2/2.3-yoy.md) |

## Phase 3: Envelope Budgets (Target: 2026-Q3)
<!-- Replanned 2026-04-15: replaced per-category budgets with envelope model. -->

| # | Feature | Status | Priority | Complexity | Spec |
|---|---------|--------|----------|-----------|------|
| 3.1 | Envelope budget set | Planned | High | Medium | [spec](roadmap/phase-3/3.1-budget-set.md) |
| 3.2 | Envelope depletion alerts | Planned | Medium | Low | [spec](roadmap/phase-3/3.2-alerts.md) |
