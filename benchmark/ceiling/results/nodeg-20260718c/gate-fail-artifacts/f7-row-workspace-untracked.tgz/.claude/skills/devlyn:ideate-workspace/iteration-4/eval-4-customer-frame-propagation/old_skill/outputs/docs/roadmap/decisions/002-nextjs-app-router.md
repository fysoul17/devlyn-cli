---
id: 002
title: "Build on Next.js App Router with Server Components as the default"
date: 2026-04-22
status: accepted
---

# 002 Build on Next.js App Router with Server Components as the default

## Context
The user specified Next.js as the stack. Inside Next.js, there's still a choice between Pages Router (legacy) and App Router (current default), and a choice about how aggressively to use Server Components vs Client Components. The project CLAUDE.md also contains an explicit user preference: "always try to build the server component first where possible and implement client component as deep as possible."

## Decision
Use the Next.js App Router with Server Components as the default. Only opt components into Client rendering (`"use client"`) when they genuinely need client-only capabilities — in this project, that means components that touch `localStorage`, manage local UI state, or bind DOM events.

Concretely: `app/page.tsx` is a Server Component that renders the static shell (page title, layout chrome) and mounts a single Client Component island `<ExpenseApp />` that owns the interactive entry form, list, totals, and export button.

## Alternatives Considered

### Pages Router (`pages/`)
- Pros: simpler mental model, mature, well-documented.
- Cons: on the way out; new Next.js features land in App Router first; contradicts current framework direction.
- Why rejected: starting a new project on a legacy router is self-imposed tech debt.

### App Router but with everything as a Client Component
- Pros: simpler — no Server/Client boundary to think about.
- Cons: loses the default-Server performance benefit; violates the explicit CLAUDE.md preference.
- Why rejected: directly contradicts the user's stated preference.

### Vite + React (no Next.js)
- Pros: lighter toolchain, faster dev server.
- Cons: user specified Next.js.
- Why rejected: violates explicit user intent.

## Consequences
- Page shell is server-rendered — faster first paint, better Core Web Vitals out of the box.
- The Client boundary is one component (`<ExpenseApp />`) — easy to reason about.
- When Supabase lands (backlog), we can add Server Actions / Route Handlers for writes without restructuring the page.
- Deployment target is Vercel or any Node-compatible host — both work with App Router.
- Slight cost: developers new to App Router have to understand the Server/Client boundary. Documented inline in the `<ExpenseApp />` component so it's visible where it matters.
