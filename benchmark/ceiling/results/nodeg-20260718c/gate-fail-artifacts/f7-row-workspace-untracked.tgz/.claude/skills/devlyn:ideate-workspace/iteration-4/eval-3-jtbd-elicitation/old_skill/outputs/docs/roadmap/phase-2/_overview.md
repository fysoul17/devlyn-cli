# Phase 2: Close the Cold Loop

## Goal
Phase 1 made staleness visible. Phase 2 makes it actionable: the team gets nudged when prospects go cold, and they can hand off a prospect to someone else when the current owner can't follow up.

## Why this phase comes second
Alerts and reassignment only matter once the team is actually on the product. If Phase 1 hasn't shipped the spreadsheet replacement, alerts fire to an empty product and reassignment has nothing to reassign.

## What's in this phase
- 2.1 Cold-prospect alerts (in-app + email digest)
- 2.2 Prospect ownership and reassignment

## What's explicitly not here
- Auto-logged touches from email/calendar (backlog)
- Pipeline stages / deal value (backlog)
- Analytics dashboards — we watch the success metrics from the DB directly for now
