# Phase 1 — Dashboard Improvement (scope TBD)

## Goal
[ASSUMED] Produce a well-scoped set of dashboard improvements for the "next phase." Actual phase goal cannot be written until the user answers `docs/clarifying-questions.md`.

## Items
- 1.1 Dashboard discovery & problem framing — the ONLY item that can be honestly planned today. It is a spike whose output is a proper roadmap, not code.

## Notes
Per the skill's "When a Spec Isn't Ready" guidance, the correct response to a too-vague request is a research/spike item — not a fabricated implementation spec. That is what 1.1 is.
