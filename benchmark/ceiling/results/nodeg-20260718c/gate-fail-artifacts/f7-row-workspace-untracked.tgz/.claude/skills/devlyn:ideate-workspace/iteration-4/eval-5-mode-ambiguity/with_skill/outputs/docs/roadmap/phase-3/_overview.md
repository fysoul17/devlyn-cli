# Phase 3: Engagement

## Goal
Bring users back to the habit tracker without requiring them to open the app. Phase 1 and Phase 2 gave users the ability to log habits, see streaks, and view their history inside the app — Phase 3 extends that value outward through passive summaries and reminders.

## Why this phase now
With core logging (Phase 1) and in-app stats (Phase 2) shipped, the next meaningful unlock is retention: helping users notice their own progress when they aren't actively using the tracker.
