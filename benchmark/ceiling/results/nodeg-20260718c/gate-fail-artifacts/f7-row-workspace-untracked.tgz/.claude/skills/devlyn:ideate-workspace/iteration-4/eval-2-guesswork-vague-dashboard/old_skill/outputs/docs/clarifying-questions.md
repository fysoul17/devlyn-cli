# Clarifying Questions (would-be)

The user prompt ("I want to improve our dashboard. Plan the next phase.") contains almost no frame. Under normal conditions the skill would pause and ask 2-3 at a time. Since this is a test with no real user, all questions are captured here. The plan generated alongside is minimal and every assumption is labeled [ASSUMED].

## FRAME-level unknowns (blocking — plan cannot be trusted without these)

### Product & domain
1. What product is this dashboard part of? (SaaS admin panel? Analytics tool? Internal ops? Consumer app?)
2. Who are the dashboard's users — role, context, frequency of use?
3. What is the dashboard's core job today? (What does a user come to the dashboard to do?)

### Current state
4. What specifically is wrong with the current dashboard? ("Improve" is too broad — slow? ugly? missing data? hard to navigate? wrong information hierarchy?)
5. Is there a concrete user complaint, metric regression, or internal review that triggered this?
6. What does the current dashboard look like — can you share a screenshot, a URL, or the file path?

### Scope of "next phase"
7. Does "next phase" mean a phase in an existing roadmap (and if so, where does docs/ROADMAP.md live)? Or are we starting a roadmap from scratch?
8. What's the timeframe — one sprint, one quarter, one release?
9. Is there a ship date or external commitment this phase must hit?

## EXPLORE-level unknowns (shape the solution space)

### Users and outcomes
10. What outcome would make this phase a success? (e.g., "support tickets about dashboard drop 50%" or "new users understand the key number in under 30 seconds")
11. Is there a specific user persona or use case we should optimize for first?
12. Are there users we are explicitly NOT trying to serve on the dashboard?

### Technical constraints
13. Tech stack? (Next.js? plain React? server-rendered? native mobile? something else?)
14. Any fixed design system or UI framework we must use?
15. Data sources — what APIs/databases feed the dashboard today, and are any of them the bottleneck?
16. Performance budget? Accessibility requirements? Supported devices/browsers?

### Non-goals
17. Anything explicitly off-limits? (e.g., "don't touch the permissions model", "don't change the URL structure")
18. Any in-flight work we must not step on?

## CONVERGE-level unknowns (affect phasing and prioritization)

19. What's higher priority: fixing what's broken, or adding new capability?
20. Is a thin vertical slice acceptable (one improvement shipped end-to-end) or does the phase need broad coverage?
21. Who signs off on the roadmap — one person, a team, external stakeholder?

## Why these questions matter

Without answers to at least Q1-Q6, the plan is speculation. The rubric's NO GUESSWORK axis specifically flags plans built on invented requirements. The test is scored on how honestly the plan admits what it doesn't know rather than how confidently it invents a dashboard it's never seen.
