---
id: 002
title: "Next.js App Router + Tailwind + shadcn/ui on Vercel"
date: 2026-04-22
status: accepted
---

# 002 Next.js App Router + Tailwind + shadcn/ui on Vercel

## Context
The user explicitly chose the stack: Next.js App Router, Tailwind, shadcn/ui, deployed on Vercel. This decision record documents the reasoning so future items inherit the stack without re-debate.

## Decision
- **Framework**: Next.js (latest stable) with the App Router
- **Styling**: Tailwind CSS
- **Components**: shadcn/ui (copy-in components, not a package dependency)
- **Hosting**: Vercel (Hobby tier — free)
- **Runtime**: client-side only for the habit tracker (localStorage is browser-only). Routes are rendered as Server Components where it doesn't require client state, but the interactive parts (log button, streak display, history) are Client Components.

## Alternatives Considered

### Pages Router instead of App Router
- Pros: more mature, simpler mental model
- Cons: going backwards on the Next.js direction; App Router is the default for new projects today
- Why rejected: user explicitly chose App Router; no reason to fight that

### Vite + React (no Next.js)
- Pros: faster dev loop, smaller surface area for a purely client-side app
- Cons: user chose Next.js; Vercel deploy is one-command with Next.js; not worth deviating
- Why rejected: user intent is explicit

### Plain CSS / CSS modules instead of Tailwind
- Pros: less toolchain
- Cons: user chose Tailwind + shadcn/ui; shadcn/ui assumes Tailwind
- Why rejected: user intent is explicit

## Consequences
- Server Components are preferred where possible (per project convention: "build the server component first where possible, push client components as deep as possible"). For this app, most interactive surface is necessarily a client component because localStorage access is client-only.
- shadcn/ui components are copied into `components/ui/` (not installed as a package) — upgrades are manual, which is fine for a solo project.
- Vercel deploy is `git push` — no CI/CD configuration work.
- `'use client'` directive lives at the top of interactive leaf components, not at the page level.
