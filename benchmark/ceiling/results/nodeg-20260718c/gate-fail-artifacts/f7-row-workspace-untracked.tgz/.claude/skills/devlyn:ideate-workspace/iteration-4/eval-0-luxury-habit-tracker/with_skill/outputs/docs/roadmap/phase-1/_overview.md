# Phase 1: MVP

## Goal
Ship a deployed, usable habit tracker on Vercel that the author can open on phone or laptop, tap to log today's habits, see a streak per habit, and look back at history.

## Scope
- Next.js App Router, Tailwind, shadcn/ui components [defaulted]
- localStorage persistence, scoped to one browser profile (see decision 001)
- Two items: log+streak (1.1), history view (1.2)
- Deployed to Vercel with a URL the author can bookmark

## Out of Scope for Phase 1
- Accounts, multi-user, cross-device sync
- Reminders, notifications, service workers
- Theming beyond shadcn defaults
- Quantitative logging (minutes, reps)
- Backdating or editing past entries
- Export / import / backup mechanisms

## Definition of "Phase 1 Done"
All of the following are true:
- A Vercel URL is live and loads with no errors.
- Opening the URL in a fresh browser, the user can create a habit, mark it done for today, and see the streak go from 0 to 1 — in under 30 seconds total.
- Re-opening the URL the next day shows the prior day's entry preserved and the streak logic correctly evaluates "yesterday + today = 2" or "missed day = streak reset".
- A history view is reachable from the main page and shows the last 30+ days for each habit.
- Zero console errors on the deployed build.

After Phase 1 is done, the author commits to daily use for at least 2 weeks before any Phase 2 item is added.
