# GENERIC_PLACEHOLDER Dashboard — Roadmap [ASSUMED]

> **North Star**: `[ASSUMED]` Make the dashboard more useful. (Real North Star blocked on `docs/clarifying-questions.md`.)
>
> **Warning**: Every row in this roadmap is `[ASSUMED]` and `Blocked` on clarification. Do **not** pass any of these specs to `/devlyn:auto-resolve`. The skill was asked to plan from near-zero framing; the only honest plan is "get framing first."

## Phase 1: Unblock Planning (Target: before any implementation work) [ASSUMED]

This phase exists to convert the user's request into something plannable. It contains one real commitment (answer the clarifying questions) and two `[ASSUMED]` exploration items that cannot be started until that real commitment is done.

| # | Feature | Status | Priority | Complexity | Spec |
|---|---------|--------|----------|-----------|------|
| 1.1 | Answer clarifying questions (the only non-assumed item) | Blocked: needs-user-input | High | Low | [spec](roadmap/phase-1/1.1-answer-clarifying-questions.md) |
| 1.2 | `[ASSUMED]` Audit current dashboard (pending domain confirmation) | Blocked: needs-clarification | High | Medium | [spec](roadmap/phase-1/1.2-audit-current-dashboard.md) |
| 1.3 | `[ASSUMED]` Identify top user pain (pending audience confirmation) | Blocked: needs-clarification | High | Medium | [spec](roadmap/phase-1/1.3-identify-top-user-pain.md) |

## Backlog

| Feature | Reason Deferred | Revisit |
|---------|----------------|---------|
| Any specific UI / UX / data / performance / re-platform work | Cannot be scoped without framing. Proposing any of these now would be domain invention. | After Phase 1 is unblocked |

## Decisions

| # | Decision | Date | Record |
|---|----------|------|--------|
| 1 | Refuse to invent a domain from the word "dashboard" | 2026-04-22 | [record](roadmap/decisions/001-refuse-to-invent-domain.md) |
