# Phase 3: Envelope Budgets

## Goal
Give users a simple, at-a-glance way to plan and track spending using the envelope budgeting model instead of per-category limits.

## Why envelopes over per-category caps
- Simpler mental model: "how much is left in this envelope?" vs. "did I exceed my category limit?"
- Maps directly to how many users already think about cash flow.
- Fewer edge cases: no need to decide how multiple categories interact, how uncategorized spending is handled, or how limit-exceeded states cascade.
- Less UI real estate — one remaining-balance number per envelope.

## Scope
- 3.1 Envelope budget set — create/edit/delete envelopes, assign transactions, show remaining balance per period.
- 3.2 Envelope depletion alerts — inline visual warnings at 20% remaining, depleted, and negative states.

## Non-goals for Phase 3
- Per-category spending limits (replaced by envelopes).
- Carryover of unspent balances between periods.
- Envelope-to-envelope transfers.
- Out-of-app alert channels (push, email).
