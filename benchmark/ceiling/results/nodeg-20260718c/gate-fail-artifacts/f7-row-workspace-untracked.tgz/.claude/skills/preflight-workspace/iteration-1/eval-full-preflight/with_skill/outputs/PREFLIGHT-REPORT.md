# Preflight Report
Generated: 2026-04-09
Scope: All phases
Previous run: none

## Summary
| Category | Count |
|----------|-------|
| MISSING | 10 |
| INCOMPLETE | 5 |
| DIVERGENT | 0 |
| BROKEN | 0 |
| UNDOCUMENTED | 0 |
| STALE_DOC | 3 |
| **Total findings** | **18** |

## Commitment Coverage
- Total commitments: 35
- Verified (IMPLEMENTED): 12 (34%)
- Issues found: 15 code findings + 3 doc findings = 18 (covers 23 commitments with issues or not yet started)

Note: Phase 2 items (2.1, 2.2) account for 13 commitments with status "Planned" in the ROADMAP. These are legitimately not-yet-started work, listed under MISSING for completeness but at LOW severity since they are acknowledged future work.

## Findings

### CRITICAL

- **[MISSING]** `1.1` -- Logout endpoint
  - **Commitment**: "Logout invalidates the session"
  - **Evidence**: Searched `src/api/auth/` -- only `login.ts` and `signup.ts` exist. No `logout.ts` or logout handler anywhere in the codebase. Comment at `src/api/auth/login.ts:26` confirms: "GAP: No logout endpoint exists anywhere."
  - **Impact**: Users cannot log out. Sessions persist indefinitely (until JWT expires at 24h). Core auth workflow missing.

- **[INCOMPLETE]** `1.1` -- Email validation on signup
  - **Commitment**: "Email format validated on signup"
  - **Evidence**: `src/api/auth/signup.ts:6` destructures email from request body and passes it directly to `db.user.create` at line 13 with no validation. Comment at line 8 confirms: "GAP: No email format validation."
  - **Impact**: Invalid email addresses (e.g., "notanemail", empty string) are accepted and stored in the database, breaking any future email-dependent flows like password reset or assignment notifications.

- **[INCOMPLETE]** `1.1` -- Password length validation on signup
  - **Commitment**: "Password minimum 8 characters, validated on signup"
  - **Evidence**: `src/api/auth/signup.ts:6` destructures password and hashes it at line 11 with no length check. Comment at line 9 confirms: "GAP: No password length check."
  - **Impact**: Users can sign up with empty or single-character passwords, violating the security constraint.

### HIGH

- **[INCOMPLETE]** `1.2` -- Delete task confirmation dialog
  - **Commitment**: "User can delete a task with confirmation dialog"
  - **Evidence**: `src/api/tasks/index.ts:33-37` implements `deleteTask` which immediately deletes without any confirmation mechanism. `src/components/TaskList.tsx` renders task items but has no delete button at all (comment at line 31 confirms: "GAP: No delete button with confirmation dialog"). The API exists but the UI to trigger it (with confirmation) does not.
  - **Impact**: Users have no way to delete tasks through the UI. When delete is eventually exposed, accidental deletions are likely without confirmation.

- **[MISSING]** `1.2` -- Task dates display
  - **Commitment**: "Tasks display creation date and last modified date"
  - **Evidence**: `src/components/TaskList.tsx:27-29` renders only `task.title` and `task.status`. No date fields are rendered. Comment at line 29 confirms: "GAP: No creation/modified dates." The API at `src/api/tasks/index.ts` does not explicitly include or exclude date fields -- they may exist in the database but are never displayed.
  - **Impact**: Users cannot see when tasks were created or last updated, losing important context for task management.

- **[MISSING]** `1.3` -- Email notification on assignment
  - **Commitment**: "Assigned user receives an email notification"
  - **Evidence**: `src/api/tasks/assign.ts:22-23` has a TODO comment: "send email notification to assignee" and a GAP comment confirming "spec 1.3 requires email notification, not implemented." No email sending logic exists anywhere in the codebase.
  - **Impact**: Assignees are not notified when tasks are assigned to them. They would only discover assignments by manually checking their task list.

- **[MISSING]** `1.3` -- Unassign action
  - **Commitment**: "Unassign action available to task owner"
  - **Evidence**: `src/api/tasks/assign.ts` contains only the `assignTask` function. No `unassignTask` endpoint exists. Comment at line 28 confirms: "GAP: No unassign endpoint." Searched all files under `src/` -- no unassign logic anywhere.
  - **Impact**: Once a task is assigned, it cannot be unassigned. The task owner loses the ability to reclaim or reassign work.

- **[MISSING]** `1.3` -- Assignee display in task detail
  - **Commitment**: "Task detail shows assignee name and avatar"
  - **Evidence**: `src/components/TaskList.tsx:27-29` renders only title and status. No assignee information is displayed. Comment at line 30 confirms: "GAP: No assignee display."
  - **Impact**: Users cannot see who is assigned to a task from the UI.

- **[INCOMPLETE]** `1.3` -- Assigned tasks in assignee's list
  - **Commitment**: "Assigned user sees the task in their task list"
  - **Evidence**: `src/api/tasks/index.ts:17` queries `db.task.findMany({ where: { userId: user.id } })` -- this only returns tasks owned by the user. Tasks assigned to the user (where `assigneeId` matches) are not included in the query. The assignment is stored (via `assign.ts:19`) but never surfaced in the task list.
  - **Impact**: Assigned users never see their assigned tasks. The assignment feature is functionally broken from the assignee's perspective.

- **[INCOMPLETE]** `TaskList.tsx` -- Error handling on fetch
  - **Commitment**: Implied by project error handling philosophy and general UX expectations from VISION.md ("Clean, responsive UI")
  - **Evidence**: `src/components/TaskList.tsx:15-18` catches fetch errors with `console.error(err)` and sets loading to false. No error state is shown to the user -- the component renders an empty list. Comment at line 16 confirms: "GAP: Error silently swallowed - no error UI shown to user."
  - **Impact**: When the API is down or returns an error, users see an empty task list with no indication that something went wrong. Violates the project's explicit error handling philosophy ("No silent fallbacks").

### MEDIUM

- **[MISSING]** `1.2` -- Task status values enforcement
  - **Commitment**: "Task statuses: todo, in-progress, done"
  - **Evidence**: `src/api/tasks/index.ts:9` hardcodes `status: 'todo'` for new tasks (correct default), but `updateTask` at line 24 accepts any value for `status` from the request body without validation. No enum or validation constrains the allowed values.
  - **Impact**: Invalid statuses (e.g., "banana") could be written to the database, potentially breaking UI rendering or filtering logic.

### LOW (Phase 2 -- Acknowledged future work)

The following commitments from Phase 2 are `status: planned` in their specs and "Planned" in ROADMAP.md. They are included for completeness but represent acknowledged future work, not missed implementations.

- **[MISSING]** `2.1` -- WebSocket connection on page load
  - **Commitment**: "WebSocket connection established on page load"
  - **Evidence**: No WebSocket implementation found anywhere in `src/`. No socket library imports, no WS server setup.

- **[MISSING]** `2.1` -- Real-time task list updates
  - **Commitment**: "Task list updates in real-time when any task changes"
  - **Evidence**: `src/components/TaskList.tsx` fetches tasks once on mount via HTTP. No subscription or real-time update mechanism.

- **[MISSING]** `2.1` -- Connection status indicator
  - **Commitment**: "Connection status indicator (connected/reconnecting/offline)"
  - **Evidence**: No connection status UI component found in `src/components/`.

- **[MISSING]** `2.2` -- Team creation and management
  - **Commitment**: All 6 requirements (create team, admin role, invite, view team tasks, remove members, settings page)
  - **Evidence**: No team-related code found anywhere in `src/`. No team model, no team API routes, no team UI components.

## Documentation Findings

### ROADMAP.md Status Accuracy
- **[STALE_DOC]** Item 1.3 marked "In Progress" in ROADMAP.md -- the core assignment endpoint exists (`src/api/tasks/assign.ts`) but 3 of 5 requirements are missing (email notification, assignee display, unassign). Status is arguably accurate ("In Progress") but the spec `status: in-progress` aligns. **No change needed** -- this one is actually correct.
  - Correction: Downgrading this -- 1.3 status is legitimately "In Progress." Not a finding.

- **[STALE_DOC]** Item 1.1 marked "Done" in ROADMAP.md, but implementation is incomplete.
  - **Evidence**: Missing logout endpoint entirely. Missing email validation and password length validation on signup. 3 of 7 requirements are unmet.
  - **Should be**: "In Progress"

- **[STALE_DOC]** Item 1.2 marked "Done" in ROADMAP.md, but implementation has gaps.
  - **Evidence**: No delete button with confirmation dialog in UI. No dates displayed. Task status values not validated. 3 of 6 requirements have issues.
  - **Should be**: "In Progress"

### README Alignment
- **[STALE_DOC]** README.md claims "SSO" support at line 6: "User authentication (signup, login, SSO)".
  - **Evidence**: No SSO implementation exists anywhere in `src/`. The auth spec (1.1) explicitly puts "Social login (OAuth)" in Out of Scope. SSO is a misleading claim.
  - **Impact**: Users reading the README would expect SSO functionality that does not exist.

- **[STALE_DOC]** (informational) README.md claims "Real-time collaboration" and "Team management" at lines 8-9. These are Phase 2 planned features with no implementation yet. While aspirational README content is common, these are stated as current features, not future ones.

### VISION.md Currency
- VISION.md "What's Next" section lists Phase 1 and Phase 2 as future work. Phase 1 is partially implemented (items 1.1 and 1.2 marked "Done" though with gaps, 1.3 in progress). No update needed yet -- Phase 1 is not fully complete.

### Item Spec Status
- No spec status mismatches found. Spec `1.1` says `done` (matches ROADMAP but code has gaps -- covered above). Spec `1.2` says `done` (same). Spec `1.3` says `in-progress` (accurate). Specs `2.1` and `2.2` say `planned` (accurate).

## What's Verified

The following commitments passed verification -- implementations exist and match specs:

**1.1 User Authentication (partial)**
- Signup endpoint exists and creates users: `src/api/auth/signup.ts:5-18`
- Login endpoint exists with credential verification: `src/api/auth/login.ts:5-23`
- Failed login returns 401 with specific error message: `src/api/auth/login.ts:10-12` and `17-19`
- Passwords hashed with bcrypt: `src/api/auth/signup.ts:1` (import) and line 11 (`hash(password, 10)`)
- JWT-based session management with 24h expiry: `src/api/auth/signup.ts:17` and `src/api/auth/login.ts:22`

**1.2 Task CRUD (partial)**
- Create task with title and description: `src/api/tasks/index.ts:4-12`
- View all tasks in a list: `src/api/tasks/index.ts:15-18` (API) and `src/components/TaskList.tsx:4-36` (UI)
- Update task title, description, and status: `src/api/tasks/index.ts:21-30`
- Delete task (API only, no UI): `src/api/tasks/index.ts:33-37`
- Default status 'todo' on creation: `src/api/tasks/index.ts:9`
- Owner-only edit/delete constraint: `src/api/tasks/index.ts:25` and `35` (where clause includes `userId: user.id`)

**1.3 Task Assignment (partial)**
- Assign task by email: `src/api/tasks/assign.ts:4-26`
- Only existing users can be assignees (constraint): `src/api/tasks/assign.ts:8-15` (checks `findUnique`, returns 404 if not found)

## Accepted Divergences (from previous runs)
None

## Cross-Cutting Observations

1. **No test files exist** -- Searched entire `src/` directory. No `*.test.*`, `*.spec.*`, or `__tests__/` directories found. None of the specs have explicit TEST commitments, but the complete absence of tests is notable for a project claiming items are "Done."

2. **No error handling pattern** -- The API endpoints have no try/catch blocks. Database errors, JSON parse errors, and auth middleware failures would result in unhandled exceptions. Only the login endpoint handles the "user not found" case explicitly.

3. **Auth middleware assumed but not verified** -- `src/api/tasks/index.ts` and `src/api/tasks/assign.ts` import and use `authMiddleware` from `../middleware/auth`, but this file was not found in the project. It may exist outside the provided source tree or may be missing.
