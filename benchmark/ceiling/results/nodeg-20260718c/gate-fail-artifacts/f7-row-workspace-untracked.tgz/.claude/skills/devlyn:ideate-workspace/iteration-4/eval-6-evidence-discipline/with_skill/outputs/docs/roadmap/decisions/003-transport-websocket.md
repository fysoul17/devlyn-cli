---
id: 003
title: "Transport for real-time document sync"
date: 2026-04-22
status: accepted
---

# 003 Transport for real-time document sync

## Context

Clients editing the same document must exchange CRDT updates with the server in near-real-time. The transport layer determines: how updates are propagated, how presence (cursors, selection) is broadcast, and how reconnect / resync is handled.

## Decision

**Use a persistent WebSocket connection per client** between the browser and the Next.js-adjacent relay server. Each document corresponds to a "room"; the relay holds the in-memory CRDT for active rooms and broadcasts incoming updates to other clients in the room plus persists them to Postgres.

The relay is a Node process. In Phase 1 it is colocated with the Next.js deployment (either in the same Node server via a custom server, or as a sibling service sharing the same host). Specific hosting arrangement is an implementation decision in item 1.2.

## Alternatives Considered

### HTTP long-polling
- Pros: Works through restrictive proxies that block WebSockets.
- Cons: Higher latency, more overhead, more complex server-side logic for broadcast.
- Why rejected: modern browser + hosting combinations support WebSockets; long-polling is a fallback, not a primary transport. Revisit only if we observe concrete WebSocket failures in deployment.

### Server-Sent Events (SSE) + separate HTTP POST for writes
- Pros: Simpler server semantics for one-way streaming.
- Cons: Asymmetric transport (two channels per client) complicates reconnect logic and update ordering.
- Why rejected: CRDT sync is inherently bidirectional with frequent small messages; a single WebSocket matches the traffic shape.

### WebRTC (peer-to-peer, no relay)
- Pros: Lowest latency between co-editors; no relay server required.
- Cons: Signaling, NAT traversal, TURN servers, and peer count management add complexity; persistence still requires a server, so we would need both peer-to-peer for live and client-to-server for persistence; debugging is harder.
- Why rejected: at 500 MAU small-team scale, server-relayed WebSocket is simpler and sufficient. WebRTC is a future optimization, not a Phase 1 simplifier.

### A managed sync / realtime platform (e.g., Pusher, Ably, Supabase Realtime, provider-hosted CRDT sync)
- Pros: Offloads transport operations; managed reconnection, scaling, pub/sub.
- Cons: Vendor pricing scales with connections or messages; core data path depends on an external provider; switching later is painful.
- Why rejected: Phase 1 is explicitly a single-server deployment; a managed transport would be operational convenience without a matching scale need. Revisit if self-hosted relay becomes a burden (multi-instance, multi-region).

## Consequences

- Positive: a single transport, bidirectional, matching the CRDT update traffic shape.
- Positive: relay sees every update and can persist them to Postgres in order.
- Accepted cost: we own the reconnect logic, backpressure handling, and the "client joins late, needs the current state" handshake — these are implementation detail in the sync-engine item (1.2).
- Accepted cost: WebSocket connections may be blocked on some corporate networks; we do not plan a long-polling fallback in Phase 1.
