# Habit Tracker

## North Star
A minimal local-first habit tracker.
