---
id: 002
title: "Storage backend for document state and updates"
date: 2026-04-22
status: accepted
---

# 002 Storage backend for document state and updates

## Context

The product needs to persist collaborative documents so that: (a) a document survives all clients disconnecting, (b) a client joining a room loads the current state quickly, and (c) the user does not lose edits across a reload.

CRDT-based editing (decision 001) produces two kinds of persistable data:
1. **Document snapshot** — a serialized point-in-time state of the document.
2. **Updates** — small binary deltas emitted as users edit, which can be appended and later compacted into a new snapshot.

The user explicitly asked, during ideation, "what's the best storage backend?" — so the choice is load-bearing. The user also stated the scale target is ~500 monthly active users. That matters: storage decisions that would be wrong at 500,000 MAU can be right at 500 MAU.

## Decision

**Adopt Postgres (managed) as the single storage backend for Phase 1.** Both the document snapshot and the append-only update log live in Postgres, accessed from the Next.js server and from the WebSocket relay.

Schema sketch (finalized in item spec 1.3):
- `documents` — one row per document, stores the latest compacted snapshot (bytea) and metadata.
- `document_updates` — append-only log of binary CRDT updates keyed by document, with a periodic compaction job that folds updates into the snapshot.

Why one backend instead of two (e.g., Postgres + Redis for live fanout):
- At 500 MAU, the concurrent-document load is small; the WebSocket relay can hold the in-memory CRDT per active room and flush to Postgres without needing a separate live-fanout layer.
- One backend is operationally simpler (one set of credentials, one backup policy, one failure mode to reason about).

## Alternatives Considered

### Postgres + Redis (dedicated live-state layer)
- Pros: Redis handles ephemeral presence, pub/sub fanout across multiple server instances, and hot document state well.
- Cons: Two systems to operate, two credentials, two backup policies, two failure modes.
- Why rejected: at 500 MAU, a single server instance is a reasonable deployment; needing pub/sub fanout across multiple instances is a scale we have not hit. Defer to the backlog as a readiness gate ("when do we need multi-instance server?").

### A document/NoSQL store (e.g., MongoDB, DynamoDB)
- Pros: Flexible shape for storing opaque CRDT blobs; append operations are natural.
- Cons: New operational surface; Next.js + Postgres is a more common stack pattern in the broader ecosystem. [UNVERIFIED — "more common stack pattern" is a general impression, not a sourced claim in this session.]
- Why rejected: no specific capability is needed that Postgres cannot provide at our scale. Avoiding a new datastore is a cost avoidance, not a capability rejection.

### A CRDT-native specialized backend (e.g., provider-managed sync services)
- Pros: Turnkey sync + persistence; removes the need to run a WebSocket relay ourselves.
- Cons: Vendor lock-in on the core data model; pricing scales with collaborators or documents; debuggability depends on the provider.
- Why rejected: we chose "run our own WebSocket relay + Postgres" as a deliberate choice to keep the data ours and keep the cost envelope predictable at small scale. Revisit if operational load of the relay becomes a burden.

### Filesystem / object storage (S3-compatible) for snapshots only
- Pros: Cheap for large blobs.
- Cons: No transactional story with the update log; append operations on object storage are awkward.
- Why rejected: snapshots are small at our scale; we do not need object storage's blob-size advantages yet.

## Consequences

- Positive: one datastore to operate, back up, and reason about.
- Positive: snapshot + updates in the same database allows a transactional compaction step.
- Accepted cost: cross-instance pub/sub is not available — Phase 1 is single-server; multi-instance deployment requires revisiting this decision.
- Accepted cost: presence data (who is currently in a document) lives in memory on the relay, not in persistent storage. That is correct — presence is ephemeral — but it means presence is lost on server restart.
- Open item: the specific managed Postgres provider is an implementation decision in Phase 1 item 1.3, not settled here.
