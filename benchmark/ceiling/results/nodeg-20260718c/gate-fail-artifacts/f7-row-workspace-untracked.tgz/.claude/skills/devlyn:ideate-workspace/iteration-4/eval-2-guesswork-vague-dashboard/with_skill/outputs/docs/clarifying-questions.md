# Clarifying Questions — Dashboard Improvement

> Status: **BLOCKING.** The user's request was "I want to improve our dashboard. Plan the next phase." This contains no framing — no domain, no users, no current state, no problem, no constraints. The skill's FRAME phase (Job-to-be-Done) cannot be completed from the given input. These questions must be answered before any meaningful roadmap can be produced.
>
> In the test context no real user is available, so these questions are written to disk and the plan proceeds in `[ASSUMED]` mode with a **GENERIC_PLACEHOLDER** domain — every item in the roadmap is explicitly flagged so nothing is accidentally treated as a real commitment.

## 1. Problem framing (Job-to-be-Done)

1. **What is the dashboard for?** What does a user actually do on it today — view metrics, take actions, monitor something, make a decision? (A "dashboard" is a UI shape, not a purpose. The purpose drives every requirement.)
2. **Who uses it?** What role, what context, how often? (A dashboard for an on-call SRE, a C-level exec, and a merchant admin are three completely different products.)
3. **What job is the user trying to get done** when they open the dashboard? (e.g., "decide whether to page the team tonight", "explain last week's revenue dip to my boss", "find and cancel a stuck order".) One sentence in the form: *When [situation], [user] wants to [motivation], so they can [outcome].*
4. **What does "improve" mean to you right now?** Is there a specific pain — slow, wrong data, ugly, confusing, missing a capability — or is this exploratory? The word "improve" covers everything from a re-skin to a full rebuild, and the right roadmap looks totally different in each case.

## 2. Current state

5. **What does the dashboard look like today?** Link, screenshot, or a short description of the main views/panels/widgets. Without this, any plan is guessing at the starting point.
6. **What tech stack is it built on?** (frontend framework, data source, auth, deployment). This shapes what's realistic in "the next phase."
7. **What's worked well so far, and what hasn't?** (What should we not touch? What have users complained about?)

## 3. Scope and constraints

8. **What does "the next phase" mean in your head?** A 2-week sprint, a quarter, a rewrite? How many items roughly?
9. **Are there hard constraints?** Deadline, budget, headcount, must-use-tech-X, can't-change-schema-Y.
10. **Who is on the team?** (Solo, small team, large team — affects how items should be sized.)

## 4. Success

11. **How will you know the "improvement" worked?** A concrete outcome — "p95 time-to-answer drops from 8s to under 2s", "CSAT on dashboard rises", "stops paging us at 3am for false alarms" — not "it's better."
12. **What is explicitly out of scope?** What should the plan *not* propose, even if it would be a good idea in the abstract?

## 5. Inputs we'd normally read

13. **Are there existing docs** — PRD, tickets, user interviews, analytics on current usage, a previous roadmap — that we should read before planning? If yes, where?

---

## How this affects the plan

Until these are answered:

- No domain can be responsibly assumed. The plan will use `GENERIC_PLACEHOLDER` everywhere a real domain term would live.
- No specific feature can be proposed. The roadmap will contain one placeholder phase whose only real commitment is "answer these clarifying questions", plus `[ASSUMED]`-tagged exploration items that must be re-validated before implementation.
- Nothing in this output should be handed to `/devlyn:auto-resolve` as-is. The `status` frontmatter on every item is `blocked: needs-clarification`, not `planned`.
