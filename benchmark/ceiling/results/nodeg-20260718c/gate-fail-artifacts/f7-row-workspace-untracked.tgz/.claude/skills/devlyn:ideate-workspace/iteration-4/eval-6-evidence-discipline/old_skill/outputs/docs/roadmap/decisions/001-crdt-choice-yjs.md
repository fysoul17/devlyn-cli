---
id: 001
title: "Use Yjs as the CRDT"
date: 2026-04-22
status: accepted
---

# 001 Use Yjs as the CRDT

## Context
The product is built on real-time collaborative editing. Picking the CRDT shapes nearly every other stack decision (editor, sync server, persistence format). The main mainstream candidates are Yjs, Automerge, and Loro. The project has ~500 MAU in view, a Next.js frontend, and a "ship quickly, use proven primitives" principle.

## Decision
Use Yjs as the CRDT for document text state.

## Alternatives Considered

### Automerge
- Pros: Strong formal model, JSON-native document shape, active development.
- Cons: Heavier payloads historically; the rich-text integration story is less mature than Yjs's TipTap/ProseMirror/Monaco ecosystem.
- Why rejected: The editor binding ecosystem around Yjs (particularly with TipTap / ProseMirror) is more battle-tested for exactly our use case — real-time rich text in a browser.

### Loro
- Pros: Newer CRDT with promising performance characteristics and a modern API.
- Cons: Much smaller ecosystem; fewer production integrations; rich-text editor bindings less mature.
- Why rejected: The project's principle is "boring, proven primitives". Loro is interesting but shipping on it trades proven-for-novel in a way that doesn't pay off at our scale.

### Build our own CRDT
- Pros: Total control over the data model.
- Cons: Multi-person-year project; debugging CRDT consistency is brutally hard; no ecosystem.
- Why rejected: Explicitly ruled out in VISION.md anti-goals. Out of scope.

## Consequences
- Inherits the Yjs ecosystem: TipTap / ProseMirror / Monaco bindings, Hocuspocus sync server, awareness protocol for presence.
- Persistence format is Yjs binary updates (or snapshots). Decoding outside the Yjs runtime requires the Yjs library.
- If Yjs becomes a problem later, migrating to another CRDT is non-trivial because the on-disk format is Yjs-specific. This is an accepted cost.
- Team members unfamiliar with CRDTs have a learning curve around awareness, subdocs, and transaction semantics — acceptable given the ecosystem payoff.
