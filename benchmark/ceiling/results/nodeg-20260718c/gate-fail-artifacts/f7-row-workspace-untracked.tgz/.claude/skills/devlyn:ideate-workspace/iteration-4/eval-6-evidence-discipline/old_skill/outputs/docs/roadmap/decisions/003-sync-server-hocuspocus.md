---
id: 003
title: "Self-host Hocuspocus + Postgres for sync and persistence"
date: 2026-04-22
status: accepted
---

# 003 Self-host Hocuspocus + Postgres for sync and persistence

## Context
Yjs documents need a sync server that brokers updates between clients and persists state. Mainstream options in the Yjs ecosystem are raw `y-websocket`, Hocuspocus (a Yjs-native Node server), or a managed collaboration-as-a-service like Liveblocks. At ~500 MAU, cost is in double-digit USD/month either way — the decision rides on ops burden vs. control.

## Decision
Self-host Hocuspocus as the sync server, persisting Yjs document state to Postgres via Hocuspocus's database extension.

## Alternatives Considered

### Liveblocks (managed collab service)
- Pros: Zero ops; presence, storage, and transport all handled; first-class Yjs support.
- Cons: Per-MAU pricing; vendor lock-in on the collab layer; less control over the persistence format.
- Why rejected: At 500 MAU we don't need the managed option and we keep more flexibility self-hosting. Left in the backlog as a "low-regret switch if ops gets painful".

### Raw y-websocket (reference server)
- Pros: Smallest possible surface.
- Cons: Essentially a demo server — no batteries-included auth hook, no persistence plugin model, no extension ecosystem.
- Why rejected: Hocuspocus is explicitly the "production version" of y-websocket, with auth hooks, extension model, and a Postgres adapter we'd otherwise have to build.

### Redis-backed y-websocket fork
- Pros: Horizontal scale across sync-server instances via Redis pub/sub.
- Cons: Only needed past the scale of a single Node process; introduces a Redis dependency we don't otherwise need at 500 MAU.
- Why rejected: YAGNI at our scale. A single Hocuspocus process is sufficient for 500 MAU.

## Consequences
- Deploy target must be a persistent-connection host (not Vercel serverless) — see decision 004.
- Postgres becomes the system of record for document state (Yjs binary updates or snapshots).
- We own backup/restore of the Postgres store. Standard managed-Postgres backups cover this.
- We can add Hocuspocus extensions (auth, webhooks, logging) later without changing the client.
- If usage grows past one process, we move to a Redis-pubsub arrangement; the client protocol doesn't change.
