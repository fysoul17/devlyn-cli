# Phase 1: Core habit loop

## Goal
Ship a working habit tracker — deployed on Vercel — that lets the owner log a habit done today, see the current streak per habit, and browse history. This is the entire product as stated; Phase 1 exists to deliver the whole core loop, not just scaffolding.

## Why this phase
The user's definition of done for the MVP is literally "log that I did a habit today, see a streak, see my history". Splitting that into seven implementation-shaped items (scaffold, data store, log, streak, history, habit CRUD, deploy) would pad the plan without delivering a usable product at the phase boundary. Bundling scaffold + store + log + streak + habit CRUD + deploy into item 1.1 ships a usable slice; adding history as 1.2 completes the stated scope.

## Items
- **1.1 — Log a habit today and see streak**: bundles the app scaffold, localStorage data store, habit create/delete, "mark done today" action, and current-streak display. Deployed on Vercel as part of done criteria.
- **1.2 — History view**: a page/component that lists each habit's log entries over time (calendar or list). Depends on 1.1.

## Scope boundaries for this phase
- In scope: log today, streak, history, basic habit management (add/delete a habit — necessary for 1.1 to be usable), Vercel deploy.
- Out of scope: reminders, analytics, theming, cross-device sync, accounts, import/export.
- Implicit additions called out: habit CRUD and day-boundary logic are not things the user listed, but they are physically required for 1.1 to be usable — they are marked [implicit] in the 1.1 spec so the implementation agent knows they came from the agent, not the user.

## Done for the phase
Both 1.1 and 1.2 are deployed, I can add a habit, mark it done today, see the streak count increment, and see a full history of past done-days.
