# Phase 1: Core Tracking — Overview

## Goal
Ship the end-to-end expense tracking loop — log, see, export — on a single device, using localStorage only. After this phase, the solo freelancer can record an expense in seconds, see running totals by category, and pull a CSV ready to hand to a tax preparer.

## Scope
Two items, each user-visible on its own:

1. **1.1 Log expense and see running totals** — the core vertical slice. A form to log amount, category, date, and note; a list of recent expenses; a category-level total for the selected period (month / year). If the founder stopped here, this would still be a usable tool.
2. **1.2 Export year-to-date CSV** — a single button that produces a tax-preparer-ready CSV of every expense in the current year.

## Out of Phase Scope
- Cloud sync / Supabase — backlog; schema in 1.1 is designed to be Supabase-compatible, but no network calls ship in Phase 1
- Filters, search, charts, receipt photos, mileage — all in backlog
- Multi-device sync, auth, team features — explicit anti-goals, not coming

## Why This Order
- 1.1 delivers the primary user capability on its own. A freelancer can log and read totals with no other feature.
- 1.2 layers on top of 1.1's data without modifying it; it's a pure read + format step.
- Order is also risk-ordered: the schema decisions happen in 1.1 (where they're cheap to revisit), not in 1.2.

## Architecture Context
- Next.js 15+ App Router, Server Components by default; the entry form and list are Client Components because localStorage is browser-only.
- Data shape lives in a single `expenses` array in localStorage under a versioned key (e.g., `expenses:v1`). See Decision 001 for the migration-aware schema.
- Single-page layout (Decision 003) — no per-view routing in v1.

## Phase Exit Criteria
- The founder has logged at least 5 real expenses using the app.
- A CSV export opens cleanly in Google Sheets / Excel with one row per expense and readable headers.
- Reloading the browser preserves all data.
- No runtime errors in the console during normal use.
