---
id: 002
title: "Staleness is computed on read, not stored"
date: 2026-04-22
status: accepted
---

# 002 Staleness is computed on read, not stored

## Context
Staleness (Fresh / Warming / Stale / Cold) is the product's primary signal. The obvious implementation options are: compute it on every read from `max(touches.touched_at)`, or denormalize a `staleness` column on `prospects` and keep it updated via a scheduled job.

## Decision
Compute staleness on read. The `prospects` table has no `staleness` column and no `last_touched_at` column; both are derived from the `touches` table at query time.

## Alternatives Considered

### Denormalize `last_touched_at` and `staleness` on `prospects`
- Pros: Faster list queries at scale; single-column sort.
- Cons: Two-source-of-truth bug surface (stale column vs real touches table); requires a job to advance rows from Warming → Stale → Cold as time passes; the job becomes a critical path for the alert feature in 2.1.
- Why rejected: At 8 users × ~a few hundred prospects, there is no performance argument for denormalization. The two-source-of-truth cost is paid for no measurable gain.

### Computed column in Postgres
- Pros: Single source of truth; still queryable like a real column.
- Cons: Generated columns can't reference other tables, so we'd need a materialized view, which brings back refresh scheduling.
- Why rejected: Same cost as denormalization for the same non-benefit.

## Consequences
- List queries always join or subquery against `touches` to get `max(touched_at)`. At current scale this is trivial; if we ever hit a real performance wall, revisit with measurements.
- The cold-alerts job in 2.1 computes staleness from a single SQL, not from a denormalized column — which is actually easier to reason about.
- Test data for the four staleness states is created by inserting touches at specific timestamps, not by editing a staleness column directly.
