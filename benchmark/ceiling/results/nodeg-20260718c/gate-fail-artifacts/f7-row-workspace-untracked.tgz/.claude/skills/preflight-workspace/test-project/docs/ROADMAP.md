# TaskFlow Roadmap

## Phase 1: Core Foundation

| # | Feature | Status | Spec |
|---|---------|--------|------|
| 1.1 | User Authentication | Done | [spec](roadmap/phase-1/1.1-auth.md) |
| 1.2 | Task CRUD | Done | [spec](roadmap/phase-1/1.2-task-crud.md) |
| 1.3 | Task Assignment | In Progress | [spec](roadmap/phase-1/1.3-task-assignment.md) |

## Phase 2: Collaboration

| # | Feature | Status | Spec |
|---|---------|--------|------|
| 2.1 | Real-time Updates | Planned | [spec](roadmap/phase-2/2.1-realtime.md) |
| 2.2 | Team Management | Planned | [spec](roadmap/phase-2/2.2-teams.md) |
