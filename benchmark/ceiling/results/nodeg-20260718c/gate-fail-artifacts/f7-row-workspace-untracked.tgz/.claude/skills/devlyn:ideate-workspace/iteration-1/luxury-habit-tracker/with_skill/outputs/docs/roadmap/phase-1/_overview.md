# Phase 1: Core Loop

## Goal
Ship the entire habit tracker in two items: the interactive core (create habits, log today, see streak) and a read-only history view. After Phase 1, the app does everything the user asked for.

## Items
- **1.1 Habit tracker core** — the root page. Lists habits, lets the user add new ones, lets them tap to mark today done, shows each habit's current streak next to its name.
- **1.2 History view** — a separate route that renders the last N days for each habit as a grid so the user can see what they did and didn't do.

## Shared context (applies to both items)
- **Stack**: Next.js (App Router), Tailwind CSS, shadcn/ui, deployed on Vercel. Node runtime, default rendering config, no Edge-specific features needed.
- **Data**: localStorage only. No backend, no API routes for data, no database. Storage key `habit-tracker.v1`.
- **Data model** (TypeScript):
  ```ts
  type Habit = { id: string; name: string; createdAt: string /* YYYY-MM-DD */ };
  type Completion = { habitId: string; date: string /* YYYY-MM-DD, local */ };
  type Store = { habits: Habit[]; completions: Completion[] };
  ```
- **Date handling**: All dates are local `YYYY-MM-DD` strings derived from `new Date()` in the user's timezone. Never store ISO timestamps. See `decisions/001-local-date-keys.md`.
- **Rendering**: Both routes are client components (`'use client'` at the page top) because all data lives in `window.localStorage`. The `app/layout.tsx` stays a server component shell. See `decisions/002-client-rendered-pages.md`.
- **SSR guard**: Initial render reads nothing from storage (empty state). A `useEffect` on mount hydrates the in-memory state from localStorage. This avoids hydration mismatches.
