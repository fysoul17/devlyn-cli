# Freelancer Expense Tracker Vision

## North Star
A freelancer can capture any business expense in under 10 seconds and, at tax time, export a clean CSV of the year's spending grouped by category.

## Principles
1. **Capture speed beats completeness** — The add-expense flow is optimized for 10-second entry on any device. Tradeoff: we accept that some fields (e.g., receipts, tags) will stay lightweight or deferred rather than slow down the hot path.
2. **Own your data, locally first** — Data lives in the user's browser (localStorage) until they explicitly opt into cloud sync. Tradeoff: cross-device use is deferred; clearing browser data loses history unless exported.
3. **Tax-time usefulness is the proof** — Every feature is evaluated against "does this make tax season easier for a freelancer?" Tradeoff: we deprioritize general budgeting, charts-for-charts-sake, and team features.
4. **Solo use, no accounts** — No auth, no multi-user. Tradeoff: accepts single-device scope in exchange for zero friction to start and zero infrastructure to maintain.

## Target Users
### Primary
**Solo freelancers / solo founders** — Running a one-person business, frequently spending on software, client meals, travel, and tools. Pain: manually tallying deductible expenses at tax time from scattered receipts and bank statements. Need: a fast, low-ceremony place to log a business expense the moment it happens, and a clean export when the accountant asks.

### Not For
- **Teams or agencies** — They need shared accounts, roles, and approvals; out of scope.
- **Personal budgeting users** — This is about deductible business tracking, not "am I spending too much on coffee."
- **Full accounting users** — QuickBooks / Xero already serve this need at scale; we don't try to replace them.

## Anti-Goals
- **No authentication** — Why: solo use on the user's own device; auth adds friction and infrastructure the user explicitly does not want yet.
- **No team or collaboration features** — Why: user explicitly scoped this as solo.
- **No automatic bank sync in Phase 1** — Why: Plaid/bank integrations are heavy to implement, require server-side credentials, and add compliance surface; manual entry is fast enough for a solo freelancer.
- **No mobile app (native)** — Why: a responsive Next.js web app run on a phone covers the use case without the cost of shipping iOS/Android.

## Success Metrics
- **Time-to-log** an expense: under 10 seconds from opening the app to saved entry.
- **Tax-time export**: CSV of a full year's expenses (grouped by category, with totals) downloads in one click.
- **Return use**: the user logs expenses in at least 4 separate weeks within the first month of use (validates the capture flow feels frictionless enough to become a habit).

## Evolution Path
Phase 1 ships the local-only MVP (log, summarize, edit, export). Phase 2+ adds Supabase-backed sync for cross-device use, receipt attachments, recurring expenses, and filter/search — only after the local core is proven useful.
