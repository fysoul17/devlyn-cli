# Roadmap

> STATUS: PLACEHOLDER — waiting on answers in `clarifying-questions.md`.

## Active

### Phase 1 — Dashboard Improvement (scope TBD)

| # | Item | Priority | Status | Spec |
|---|------|----------|--------|------|
| 1.1 | Discovery & problem framing for dashboard improvements | high | planned | [spec](roadmap/phase-1/1.1-dashboard-discovery.md) |

That is the only item that can be honestly planned from the information provided. Additional items (perf, redesign, new widgets, a11y, etc.) will be added once 1.1 produces concrete findings.

## Completed
_none_

## Backlog
_none captured — no candidate ideas were shared by the user._
