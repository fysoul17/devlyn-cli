# Phase 3: Envelope Budgets

Phase 3 delivers a simple envelope-style budgeting system: the user creates named envelopes with an allocated amount per period (monthly), then assigns transactions to envelopes so each envelope's remaining balance decreases as spending occurs.

This replaces the earlier per-category-limit design. Envelopes are user-defined buckets that do not have to map 1:1 to transaction categories — the user decides what "Groceries" or "Fun Money" means for them.

## Goals
- Let the user plan a month by allocating money into named envelopes.
- Show remaining balance per envelope at any time.
- Notify the user when an envelope is close to depleted or overspent.

## Items
- 3.1 Envelope setup & allocation
- 3.2 Envelope depletion alerts
