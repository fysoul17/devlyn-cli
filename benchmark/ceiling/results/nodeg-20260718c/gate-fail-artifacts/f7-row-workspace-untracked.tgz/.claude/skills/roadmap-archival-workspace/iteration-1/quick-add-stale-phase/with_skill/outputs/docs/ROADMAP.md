# Habitly Roadmap

> **North Star**: Help people build lasting habits through daily gentle feedback.

## Phase 2: Daily Use (Target: 2026-Q2)
<!-- What users see every day — the core loop. -->

| # | Feature | Status | Priority | Complexity | Spec |
|---|---------|--------|----------|-----------|------|
| 2.1 | Daily check-in screen | In Progress | High | Medium | [spec](roadmap/phase-2/2.1-daily-checkin.md) |
| 2.2 | Streak visualization | Planned | High | Low | [spec](roadmap/phase-2/2.2-streak-viz.md) |
| 2.3 | Weekly recap email | Planned | Medium | Medium | [spec](roadmap/phase-2/2.3-weekly-recap-email.md) |

## Backlog
| Feature | Reason Deferred | Revisit |
|---------|----------------|---------|
| Social sharing | Out of scope for MVP | 2026-Q3 |

## Decisions
| # | Decision | Date | Record |
|---|----------|------|--------|
| 1 | Use SQLite for local data | 2026-01-10 | [record](roadmap/decisions/001-sqlite.md) |

## Completed
<details>
<summary>Phase 1: Foundation (completed 2026-04-15, 3 items)</summary>

| # | Feature | Completed |
|---|---------|-----------|
| 1.1 | User auth & signup | 2026-04-15 |
| 1.2 | Habit data model | 2026-04-15 |
| 1.3 | Onboarding flow | 2026-04-15 |
</details>
