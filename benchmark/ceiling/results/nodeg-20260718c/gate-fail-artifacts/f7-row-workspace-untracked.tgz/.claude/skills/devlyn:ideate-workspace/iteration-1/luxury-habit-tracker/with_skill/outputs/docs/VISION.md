# Habit Tracker Vision

## North Star
A personal, single-user habit tracker that makes logging "I did it today" a two-second action and shows an honest streak.

## Principles
1. **Friction-free daily log** — The single most common action (mark today done) is reachable in one tap from the root page. Tradeoff: we skip multi-step flows, rich logging, and per-entry notes.
2. **Local-first, no accounts** — All data lives in the user's browser. No backend, no auth, no sync. Tradeoff: data is tied to this browser; clearing storage erases history.
3. **Minimum viable, aggressively** — Only three capabilities: add a habit, log today, see history. Tradeoff: no reminders, categories, analytics, or social features, even when they would be easy.
4. **Honest streaks** — A streak reflects reality: consecutive calendar days including today (or ending yesterday with a grace window until end-of-day). Tradeoff: we do not fudge, freeze, or gamify streaks.

## Target Users
### Primary
**The owner (solo developer, personal use)** — Wants to track a handful of habits for themselves. Pain: existing habit apps are bloated, require accounts, and sync data to servers. Need: a tool they control that does only the three things that matter.

### Not For
- Teams or families sharing habits — Why: no multi-user model, ever.
- Users who need cross-device sync — Why: explicit local-first choice; sync is a non-goal.
- Users who want reminders, analytics, or gamification — Why: scope creep that distracts from the core loop.

## Anti-Goals
- **No user accounts or auth** — Why: the user is the only user; auth adds complexity with zero value.
- **No backend database** — Why: localStorage is sufficient for personal-scale data and removes an entire class of deployment concerns.
- **No notifications or reminders** — Why: out of the stated problem; adds OS permissions, service workers, background logic.
- **No habit categories, tags, colors, or icons in v1** — Why: polish without core-problem value; classic overengineering.
- **No analytics dashboards beyond a history view** — Why: history answers "did I do it?" — charts are a luxury item until the core loop is proven.

## Success Metrics
- The user opens the app and logs today's habits in under 5 seconds.
- Streak displayed next to each habit matches a manual count of consecutive days.
- History view lets the user see any past 30 days at a glance without scrolling controls.
- Zero backend services deployed; Vercel build is a static/edge-rendered Next.js app with no server data layer.
