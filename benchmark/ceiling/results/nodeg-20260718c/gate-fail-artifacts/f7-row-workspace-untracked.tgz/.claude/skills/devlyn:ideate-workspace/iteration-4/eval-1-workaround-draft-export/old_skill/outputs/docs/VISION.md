# Notes App

## North Star
A fast, reliable note-taking app.

## Target Users
**Knowledge workers** — need persistent notes across sessions. Pain: losing in-progress work. Need: trustworthy persistence.
