---
id: 001
title: "Use localStorage for v1 persistence"
date: 2026-04-22
status: accepted
---

# 001 Use localStorage for v1 persistence

## Context
The user wants a habit tracker for themselves with no accounts, no other users, and "local-first is fine" [defaulted — user confirmed localStorage is acceptable for v1]. We need a persistence layer that works on Vercel (Next.js App Router) without a backend database.

## Decision
Persist all habits and daily log entries in `window.localStorage` under a single namespaced key (e.g. `habit-tracker:v1`). Data shape:

```ts
type Store = {
  habits: { id: string; name: string; createdAt: string }[];
  entries: { habitId: string; date: string }[]; // date = YYYY-MM-DD local
};
```

All reads and writes happen in client components. Server components render the shell only; they do not read user data.

## Alternatives Considered

### Vercel Postgres / Neon + server actions
- Pros: real persistence, works across devices, production-grade
- Cons: requires account + cloud credentials, adds auth question, adds network round-trip to every log action
- Why rejected: user explicitly said no accounts, no other users, local-first is fine. Cloud DB is the right answer for cross-device sync, but cross-device sync is an explicit anti-goal for v1.

### IndexedDB
- Pros: larger storage quota, async API, better for large datasets
- Cons: significantly more code for a tiny dataset (habit tracker is tens of KB even after a year of daily logs)
- Why rejected: overkill. The entire v1 dataset fits comfortably in localStorage's 5MB quota with three orders of magnitude to spare.

### Cookies
- Pros: sent with requests (would help server-side rendering)
- Cons: wrong tool — cookies are for request context, not user data; 4KB limit
- Why rejected: wrong primitive for the job.

## Consequences
- Fast, zero-latency logging — no network call to mark a habit done.
- Data is tied to a single browser profile. Clearing site data or switching browsers loses history. This is explicitly accepted (see VISION.md anti-goals).
- All data access must be inside `"use client"` components or inside `useEffect` to avoid `window is not defined` on the server.
- Cross-device sync, if ever added, must go through a proper cloud-backed storage migration — **not** through export/import JSON files, which would be a roadmap workaround for the real need.
