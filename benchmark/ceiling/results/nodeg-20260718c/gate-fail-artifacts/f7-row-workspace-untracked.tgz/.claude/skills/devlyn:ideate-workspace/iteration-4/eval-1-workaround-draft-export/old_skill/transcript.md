# Transcript — eval-1-workaround-draft-export (old_skill / pre-v4 baseline)

## Invocation
User prompt: Quick Add to existing roadmap — add item "let users export their draft as a JSON file they can re-upload later" to solve session-expiry draft-loss bug. Stack: Next.js + Postgres, in-memory draft store today, email auth. `--engine claude`. Proceed without waiting for real input.

## Mode
**Quick Add** — existing `docs/ROADMAP.md` already has Phase 1 (Done) and Phase 2 (Collaboration, Planned); user described a single concrete item to capture, not a full ideation session.

## Phases executed
1. **Mode detection** — Quick Add confirmed from signals (existing docs + single idea).
2. **Archive Pass (on entry)** — Read `docs/ROADMAP.md`. Phase 1 had two rows, both `Done` → whole phase archived into a new `## Completed` block with a `<details>` collapsed section. Phase 2 (2.1 Sharing, Planned) stayed in the active section. No Backlog or Decisions tables present, so nothing else to audit.
3. **Phase selection / ID assignment** — The new item's problem domain is draft persistence / resilience, not collaboration, so it does not fit Phase 2. Created new **Phase 3: Draft Resilience** with ID **3.1**.
4. **FRAME / EXPLORE / CONVERGE** — skipped per Quick Add workflow (user gave enough detail; no clarifying questions needed per run instructions).
5. **CHALLENGE (solo, `--engine claude`)** — Applied `references/challenge-rubric.md` 5-axis rubric to the single new item.
6. **DOCUMENT** — Generated `docs/roadmap/phase-3/3.1-draft-json-export.md` and updated `docs/ROADMAP.md` (Phase 1 archived, Phase 3 added).
7. **BRIDGE** — Surfaced implementation command and tradeoff open question.

## Did CHALLENGE flag the workaround?
**Yes.** Solo rubric pass produced this finding:

- **Severity**: CRITICAL
- **Quote**: "let users export their draft as a JSON file they can re-upload later"
- **Axis**: NO WORKAROUND (also fails WORLD-CLASS BEST PRACTICE)
- **Why it fails**: The stated problem is session-expiry draft loss. Manual export/import is a roadmap workaround that requires the user to act *before* expiry — but expiry is typically silent, so the draft is already gone by the time most users would export. The direct fix is autosave to Postgres (the stack already has Postgres). Mainstream editors (Notion, Google Docs, Linear, Gmail) solve this with autosave + server-side draft storage, not manual export/import. This is very close to the canonical example #2 in `challenge-rubric.md`.
- **Fix**: Replace with "Autosave drafts to Postgres" as the direct cross-session-expiry solution. If autosave is out of scope for the current cycle, explicitly defer session-expiry recovery rather than shipping manual export as if it were the feature.

## Hard rule application (respect explicit user intent)
The user explicitly asked for JSON export/re-upload. Per the rubric's "Hard rule — respect explicit user intent" section (and SKILL.md Phase 3.5 "Respect explicit user intent"), the plan was **not silently rewritten**. The item was kept as requested and the workaround finding was surfaced as an **Open Question** section inside the spec itself, presenting three paths:
1. Proceed as-is with JSON export
2. Replace with autosave to Postgres (the rubric-preferred direct fix)
3. Ship both — autosave as primary recovery, JSON export as portability feature

Because the run instructions said "Proceed without waiting for real input," the spec was written as the user requested (path 1) with the Open Question block preserving the tradeoff visibly for the user to decide before implementation.

## New spec path
`docs/roadmap/phase-3/3.1-draft-json-export.md`

## Output files
- `docs/ROADMAP.md` — Phase 1 archived into `## Completed`; Phase 2 kept; Phase 3 added with row for 3.1
- `docs/VISION.md` — untouched (Expand/Quick Add rule: do not overwrite existing vision)
- `docs/roadmap/phase-3/3.1-draft-json-export.md` — new item spec with Open Question block

## Notes
- `--engine claude` → no Codex pre-flight ping, no Codex critic pass. Solo CHALLENGE only, as specified by SKILL.md Phase 3.5 "If `--engine claude`: No Codex calls. The solo pass is the only pass."
- No clarifying questions asked to the user (per run instructions to proceed with provided defaults: Next.js + Postgres, in-memory store, email auth).
