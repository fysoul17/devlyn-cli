# Phase 1: Ship the collab loop

## Goal
Two people on the same document URL can co-edit in real time, see each other's cursors, and trust that their edits are durable across reloads.

## Why this is Phase 1
The defining bet of the product is "simpler real-time collab". Any phase that does not ship that loop leaves the product undifferentiated. Phase 1 therefore bundles scaffolding, the editor, the CRDT, the sync server, auth, and persistence into the single feature that delivers the value — rather than splitting them into separate roadmap items that don't individually produce a user-visible outcome.

## Items
- **1.1 Collaborative document editing (MVP)** — auth + create/open a doc + real-time co-edit + durable persistence. The thick item.
- **1.2 Presence indicators** — live cursors, selection colors, and user name labels so collaboration feels real.

## Out of phase
Comments, suggestions, history/versioning, export, folders, permission roles, theming. See ROADMAP.md Backlog and VISION.md Anti-Goals for rationale.

## Assumed defaults (not user-confirmed)
- Next.js App Router frontend on Vercel.
- Yjs + TipTap + Hocuspocus + Postgres for the collab stack.
- Auth.js (email magic link) for auth.
- ~500 MAU scale — single region, small Postgres, small Node process.

These defaults were adopted from the user's "reasonable defaults" instruction. If any turn out to be wrong, revise the affected spec before implementation.
