# Phase 1: Replace the Spreadsheet

## Goal
By the end of Phase 1, the 8-person sales team stops using the shared spreadsheet and uses the app instead. That means: the app has their real prospects in it, shows staleness visibly, and lets them log a touch in a few seconds.

## Why this phase comes first
Any feature beyond "shared list + staleness + touch log + import" is luxury until the team has actually switched. Cold alerts, reassignment, and richer views assume the team is on the product; if they aren't, those features don't get used.

## What's in this phase
- 1.1 Shared prospect list with staleness + touch logging — the core loop, bundled so the first deploy is a usable product, not a scaffold.
- 1.2 Spreadsheet CSV import — the migration bridge from the existing sheet; without it the team won't switch.

## What's explicitly not here
- Cold-prospect alerts (Phase 2.1)
- Ownership transfer UX (Phase 2.2) — owner is set at creation/import, no reassignment UI yet
- Any analytics / reporting / dashboards
- Email or calendar integrations
