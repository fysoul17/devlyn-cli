import { compare } from 'bcrypt';
import { db } from '../db';
import { signJwt } from '../jwt';

export async function login(req: Request) {
  const { email, password } = await req.json();

  const user = await db.user.findUnique({ where: { email } });
  if (!user) {
    return new Response(JSON.stringify({ error: 'Invalid credentials' }), {
      status: 401,
    });
  }

  const valid = await compare(password, user.password);
  if (!valid) {
    return new Response(JSON.stringify({ error: 'Invalid credentials' }), {
      status: 401,
    });
  }

  const token = signJwt({ userId: user.id }, { expiresIn: '24h' });
  return Response.json({ token, user: { id: user.id, email: user.email } });
}

// GAP: No logout endpoint exists anywhere (spec 1.1 requires "Logout invalidates the session")
