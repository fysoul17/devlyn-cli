---
id: T.1
complexity: low
priority: low
depends-on: []
source-spec: docs/roadmap/phase-test/T.1-dummy-feature.md
---

## Customer Frame
When a user bookmarks the site, they want to recognize it in their tab bar, so they can find it quickly among other tabs.

## Objective
User sees a branded favicon in their browser tab when visiting the site.

## Requirements
- [ ] Create app/icon.png at 32x32px, transparent background
- [ ] Icon shows the brand logo in the brand color
- [ ] Next.js auto-serves it at /favicon.ico via file-based metadata

## Constraints
- No new dependencies — Why: keep the dep surface small

## Out of Scope
- Full PWA manifest (Phase 3)
- Multi-size icon generation (Phase 2)

## Architecture Notes
(none)

## Dependencies
- **Internal**: (none)
- **External**: design asset (brand logo)

## Verification
- [ ] /favicon.ico returns the icon in a browser
