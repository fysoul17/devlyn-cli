# Roadmap

Index of planned work. auto-resolve reads individual item specs, not this file.

## Phase 1 — Foundations

| # | Feature | Status |
|---|---|---|
| 1.1 | Auth & onboarding (email) | done |
| 1.2 | Create note | done |
| 1.3 | Edit note | done |
| 1.4 | Delete note | done |

## Phase 2 — Collaboration & resilience

| # | Feature | Status | Spec |
|---|---|---|---|
| 2.1 | Note sharing | in progress | `roadmap/phase-2/2.1-note-sharing.md` |
| 2.2 | Folders | in progress | `roadmap/phase-2/2.2-folders.md` |
| 2.3 | Draft persistence (autosave + recovery) | planned | `roadmap/phase-2/2.3-draft-persistence.md` |

> 2.3 note: this slot was originally requested as "export draft as JSON for re-upload". The CHALLENGE phase of `/devlyn:ideate` flagged that as a roadmap workaround (it routes around the missing draft-persistence capability instead of building it, and depends on the user clicking Export before the very session expiry it is meant to protect against). Replaced with direct autosave + recovery. See `with_skill/transcript.md` for the full rubric pass.
