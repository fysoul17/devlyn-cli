# Commitment Registry
Generated: 2026-04-09T11:00:00Z
Scope: Phase 1
Total commitments: 20

## Phase 1: Core Foundation

### 1.1 User Authentication (spec status: done)
- [FEATURE] User can sign up with email and password
- [BEHAVIOR] Email format validated on signup
- [BEHAVIOR] Password minimum 8 characters, validated on signup
- [FEATURE] User can log in with existing credentials
- [BEHAVIOR] Failed login returns 401 with specific error message
- [FEATURE] JWT-based session management
- [FEATURE] Logout invalidates the session
- [CONSTRAINT] Passwords hashed with bcrypt
- [CONSTRAINT] JWT tokens expire after 24 hours

### 1.2 Task CRUD (spec status: done)
- [FEATURE] User can create a task with title and description
- [FEATURE] User can view all their tasks in a list
- [FEATURE] User can update task title, description, and status
- [FEATURE] User can delete a task with confirmation dialog
- [BEHAVIOR] Task statuses: todo, in-progress, done
- [BEHAVIOR] Tasks display creation date and last modified date
- [CONSTRAINT] Only task owner can edit/delete

### 1.3 Task Assignment (spec status: in-progress)
- [FEATURE] Task owner can assign a task to another user by email
- [BEHAVIOR] Assigned user receives an email notification
- [BEHAVIOR] Assigned user sees the task in their task list
- [BEHAVIOR] Task detail shows assignee name and avatar
- [FEATURE] Unassign action available to task owner
- [CONSTRAINT] Only existing users can be assignees

## Anti-Commitments (Out of Scope)
- [item 1.1] Does NOT include social login (OAuth) -- Phase 3
- [item 1.1] Does NOT include two-factor authentication -- Backlog
- [item 1.2] Does NOT include drag-and-drop reordering -- Phase 2
- [item 1.2] Does NOT include task categories/labels -- Backlog
- [item 1.3] Does NOT include multiple assignees per task -- Phase 2
- [item 1.3] Does NOT include assignment notifications via push -- Phase 2
