---
id: "001"
title: "Local date strings as the unit of truth"
status: accepted
date: 2026-04-14
---

# 001 — Local date strings as the unit of truth

## Decision
All dates in the store are `YYYY-MM-DD` strings derived from the user's local timezone via `date.toLocaleDateString('en-CA')`. Completions and the `createdAt` field on habits are stored as these strings. ISO timestamps (`toISOString()`) are not used.

## Why
Streaks and calendars are a calendar-day concept, not an instant concept. Users log "today" — they mean "today in the timezone I'm currently sitting in". Storing ISO timestamps forces every read to re-derive the local date, and creates classic off-by-one bugs where a completion made at 11pm UTC-8 ends up on tomorrow's UTC date. Local YYYY-MM-DD strings collapse the ambiguity at write time.

## Alternatives considered
1. **ISO timestamps** — rejected: opens timezone bugs, requires derivation on every read, and provides no benefit since we only care about the calendar day anyway.
2. **Unix epoch day numbers** — rejected: compact but harder to inspect in DevTools and serialize into JSON cleanly.
3. **A full `Date` object serialized as JSON** — rejected: JSON serialization of `Date` is lossy (becomes an ISO string), which just reintroduces option 1's problems.

## Consequences
- Streak logic operates on string equality and small string arithmetic (not date math).
- If the user travels across timezones, "today" shifts with them — this is correct behavior for a personal tracker.
- Future sync across devices (backlog) would need a conflict strategy, but local-first is explicit for v1.
