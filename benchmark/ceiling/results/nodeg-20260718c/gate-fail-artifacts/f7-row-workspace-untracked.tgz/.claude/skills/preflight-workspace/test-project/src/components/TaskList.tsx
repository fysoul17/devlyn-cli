'use client';
import { useState, useEffect } from 'react';

export function TaskList() {
  const [tasks, setTasks] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('/api/tasks')
      .then((res) => res.json())
      .then((data) => {
        setTasks(data);
        setLoading(false);
      })
      .catch((err) => {
        // GAP: Error silently swallowed - no error UI shown to user
        console.error(err);
        setLoading(false);
      });
  }, []);

  if (loading) return <div>Loading...</div>;

  return (
    <ul>
      {tasks.map((task: any) => (
        <li key={task.id}>
          {task.title} - {task.status}
          {/* GAP: No creation/modified dates (spec 1.2 requires it) */}
          {/* GAP: No assignee display (spec 1.3 requires it) */}
          {/* GAP: No delete button with confirmation dialog (spec 1.2 requires it) */}
        </li>
      ))}
    </ul>
  );
}
