# Done Criteria — T.1 Add copyright footer

Source: `docs/roadmap/phase-test/T.1-footer-copyright.md` (via `.devlyn/SPEC-CONTEXT.md`)

## Requirements
- [ ] Footer component renders on marketing pages
- [ ] Text is `© 2026 Devlyn. All rights reserved.`
- [ ] Responsive on mobile

## Out of Scope
- Footer links (Phase 2)
- Newsletter signup (Phase 3)

## Verification Method
- [ ] Visit a marketing page, see the footer
