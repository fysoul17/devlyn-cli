# Phase 1: Minimum Collaborative Slice

## Goal

Ship one end-to-end vertical slice that proves the core product thesis: two users can open the same document link, type simultaneously, see each other's changes in under a second, and come back later to find their work saved. No auth, no rich formatting, no multi-document UI — just the collaboration loop.

## Why this phase exists

The entire product risk is whether the collaboration loop feels right and is correct. Everything else (auth, document lists, formatting, sharing UX) is routine product work once the core loop is proven. Front-loading the hard, uncertain part is a deliberate sequencing choice — if CRDT + WebSocket + Postgres persistence does not feel right at this scale, we want to know before investing in the surrounding product surface.

## What ships at the end of Phase 1

A user can visit `example.com/d/<document-id>`, type in a text area, share the URL with a second user, and see both users' edits converge in real time. On reload, the document is as it was last saved. If the connection drops, the UI tells the user; on reconnect, the document resyncs.

Not in Phase 1: authentication, named users, document creation UI, document list, rich formatting, permissions, any collaboration beyond cursor presence.

## Items

| # | Item | One-liner |
|---|------|-----------|
| 1.1 | Editor + local CRDT wiring | Next.js app renders an editor whose state is backed by a CRDT document in the browser. |
| 1.2 | WebSocket relay + server-held document | A server-side relay that holds the CRDT per room and broadcasts updates between connected clients. |
| 1.3 | Postgres persistence + reconnect | Updates are written to Postgres; a reconnecting client loads the latest state before accepting new input. |
| 1.4 | Live cursor / selection presence | Each connected client sees the other users' cursor position and current selection live. |

## Sequencing rationale

- **1.1 first** — the editor + CRDT work has the fewest dependencies, and validates the client-side library choice before we build a server around it.
- **1.2 before 1.3** — sync between clients is the primary product feature; persistence is what makes it durable. Getting two clients talking live is the faster feedback loop for the core loop, so we do it before the database schema work.
- **1.3 before 1.4** — presence (cursors) is nice but additive; durability is a correctness property the product cannot ship without. Front-loading 1.3 gets the uncertainty out of the way.
- **1.4 last** — presence is a layer on top of working sync; it's the polish item of Phase 1, and it's the first thing in the phase that a new user visibly recognizes as "real-time collaboration".

## Done criteria for the phase as a whole

- Two browsers on different machines can edit the same `d/<id>` URL and see each other's changes.
- On refresh, the document content is preserved.
- Automated concurrency test: two headless clients each perform 100 randomized edits on the same document; final state is byte-identical between both clients and what is persisted.
- On a dropped connection, the UI surfaces a "reconnecting" state; on reconnect, the document converges within 2 seconds.
- Each connected client can see at least one other client's cursor position in the document.
