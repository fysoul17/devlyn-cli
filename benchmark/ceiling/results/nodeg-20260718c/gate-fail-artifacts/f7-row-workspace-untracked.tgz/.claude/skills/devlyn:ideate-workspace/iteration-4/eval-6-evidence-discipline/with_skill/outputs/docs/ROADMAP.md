# Collaborative Document Editor Roadmap

> **North Star**: A small-team real-time collaborative document editor that lets 2–10 people edit the same document simultaneously without merge conflicts, for teams that find Google Docs heavier than they need.

## Phase 1: Minimum Collaborative Slice (Target: first shipping slice)

Ship one end-to-end vertical slice — two users on one URL, live-syncing plain text, durably persisted — before building any surrounding product surface.

| # | Feature | Status | Priority | Complexity | Spec |
|---|---------|--------|----------|-----------|------|
| 1.1 | Editor + local CRDT wiring | Planned | High | Medium | [spec](roadmap/phase-1/1.1-editor-local-crdt.md) |
| 1.2 | WebSocket relay + server-held document | Planned | High | High | [spec](roadmap/phase-1/1.2-websocket-relay.md) |
| 1.3 | Postgres persistence + reconnect | Planned | High | High | [spec](roadmap/phase-1/1.3-postgres-persistence.md) |
| 1.4 | Live cursor / selection presence | Planned | Medium | Medium | [spec](roadmap/phase-1/1.4-presence-cursors.md) |

## Phase 2: Identity, Documents, and Minimal Polish (Target: after Phase 1 ships and is exercised)

Turn the Phase 1 prototype into something a small team can actually use: named users, document list, per-document access, real identities in presence. Specs are finalized at the start of Phase 2 rather than upfront.

| # | Feature | Status | Priority | Complexity | Spec |
|---|---------|--------|----------|-----------|------|
| 2.1 | Authentication | Planned | High | Medium | (spec deferred — see phase-2/_overview.md) |
| 2.2 | Document list and creation | Planned | High | Medium | (spec deferred — see phase-2/_overview.md) |
| 2.3 | Per-document access control | Planned | High | Medium | (spec deferred — see phase-2/_overview.md) |
| 2.4 | Presence with real identities | Planned | Medium | Low | (spec deferred — see phase-2/_overview.md) |

## Backlog

| Feature | Reason Deferred | Revisit |
|---------|----------------|---------|
| Offline-first editing with local persistence | Complexity too large for first roadmap; not required at ~500 MAU network conditions. | After Phase 2 |
| Rich text formatting (headings, bold, italic, lists) | Not needed to prove the collaboration loop; adds editor-binding complexity. | After Phase 2 |
| Images / media embeds | Adds blob storage + upload pipeline; separate vertical. | After Phase 3 |
| Comments / suggestions / track changes | Separate product surface; explicitly not Google Docs parity. | After Phase 3 |
| Multi-instance relay + pub/sub fanout (Redis or similar) | Not needed at single-server scale target of 500 MAU. | When single instance is the bottleneck |
| Long-polling fallback for WebSocket-blocked networks | Add if real users report blocked connections. | After Phase 2 launch |
| WebRTC peer-to-peer optimization | Adds complexity for a latency gain unproven at our scale. | After Phase 3 |
| Document version history / browsable snapshots | Useful but not core to live collaboration. | After Phase 2 |
| Document deletion UX and retention policy | Small but touches access-control semantics. | Phase 3 |

## Decisions

| # | Decision | Date | Record |
|---|----------|------|--------|
| 1 | CRDT library family for shared-document state | 2026-04-22 | [record](roadmap/decisions/001-crdt-library-choice.md) |
| 2 | Storage backend for document state and updates | 2026-04-22 | [record](roadmap/decisions/002-storage-backend.md) |
| 3 | Transport for real-time document sync | 2026-04-22 | [record](roadmap/decisions/003-transport-websocket.md) |
