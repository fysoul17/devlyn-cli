---
id: 003
title: "Next.js App Router, client-rendered Phase 1"
date: 2026-04-22
status: accepted
---

# 003 Next.js App Router, client-rendered Phase 1

## Context
The user specified Next.js as the framework. We need to decide between App Router and Pages Router, and whether Phase 1 leans server-rendered or client-rendered, given that Phase 1 data lives in localStorage (browser-only).

## Decision
Use the **Next.js App Router**. Build pages as server components by default, and push client-rendering down to the leaves that actually touch localStorage (the form, the list, the summary view, the export button). Phase 2.1 will migrate the data access paths to server-side reads/writes backed by Supabase without restructuring the route tree.

## Alternatives Considered

### Pages Router
- Pros: slightly simpler mental model for pure-client-rendered apps.
- Cons: App Router is Next.js's default and the direction for all future features (cache components, partial prerendering, server actions). Starting on Pages Router creates guaranteed future migration work.
- Why rejected: no reason to start on the deprecated-direction router when the new one works fine for this app.

### Fully client-rendered SPA ("use client" at the root layout)
- Pros: simpler — every component is a client component; no boundary to think about.
- Cons: forfeits Next.js's server-component benefits forever; bloats bundle; goes against project guidance ("build server component first where possible, client as deep as possible").
- Why rejected: violates project convention (CLAUDE.md) for no Phase 1 gain.

### Fully server-rendered with no client interactivity
- Pros: maximally cacheable.
- Cons: impossible — localStorage is browser-only, and the core capture flow requires client-side state.
- Why rejected: incompatible with Phase 1's storage model.

## Consequences
- The route tree is server-component-first; `"use client"` is added only at the leaves that need it.
- Phase 2.1's migration to Supabase can move reads/writes to server components and server actions without restructuring routes — only swapping the `ExpenseStore` implementation and the client/server boundary of specific components.
- Matches the project-wide guidance in CLAUDE.md.
