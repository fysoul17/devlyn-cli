# Habit Tracker Vision

## North Star
A frictionless personal habit tracker where logging "I did it today" takes one tap and instantly shows the streak that keeps me going.

## Principles
1. **Minimum viable ritual** — The daily loop is log → see streak → close tab. Tradeoff: no deep analytics, goal-setting, or gamification beyond the streak itself.
2. **Local-first, zero-account** — Data lives in the user's browser (localStorage). Tradeoff: no cross-device sync, no cloud backup until explicitly asked for.
3. **Build exactly what was asked** — Ship the three things the user named (log, streak, history). Tradeoff: feature requests wait in the backlog rather than sneaking into Phase 1.
4. **Static-first delivery** — Lean on Next.js App Router's static capabilities and Vercel's edge. Tradeoff: server state is deferred until there's a real reason for it.

## Target Users
### Primary
**Solo owner of this app (the user)** — Wants to build a few personal habits without the overhead of other tools. Pain: existing habit apps demand accounts, upsells, and features they don't use. Need: a page they can bookmark, tap once a day, and trust.

### Not For
- Teams or families sharing habits — Why: no multi-user model is planned.
- Users who need cross-device sync on day one — Why: local-first is an explicit constraint.
- Power users wanting analytics, charts, or insights — Why: out of the stated scope.

## Anti-Goals
- **No accounts or auth** — Why: solo project, single user, localStorage is sufficient.
- **No server database in Phase 1** — Why: localStorage removes an entire class of infrastructure work.
- **No reminders, notifications, or emails** — Why: user did not ask for them; they add permissions, services, and scope.
- **No habit categories, tags, colors, or goal types beyond "did I do it today"** — Why: the core loop is binary completion.
- **No social, sharing, or export features in Phase 1** — Why: not in the requested scope.
- **No charts or graphs beyond a simple history view** — Why: streak + history is enough for the stated need.

## Success Metrics
- Time to log a habit on the current day: under 2 seconds from page load (one tap).
- The daily loop works offline after first visit (static assets + localStorage).
- Zero configuration required after `pnpm dev` / first deploy: the app is usable with no setup, no seed data, no account.
- User (me) actually uses it for 7+ consecutive days — measured by the streak the app itself shows.
