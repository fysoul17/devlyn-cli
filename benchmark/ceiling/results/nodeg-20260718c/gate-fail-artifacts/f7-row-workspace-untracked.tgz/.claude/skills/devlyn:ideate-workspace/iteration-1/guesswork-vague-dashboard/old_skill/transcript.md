# Transcript — Old Skill Run (guesswork-vague-dashboard)

## User prompt (verbatim)
> "I want to improve our dashboard. Plan the next phase."

## How the old skill was followed

### Step 0 — Load the skill
Read `skill-snapshot-old/SKILL.md` in full and `references/templates/item-spec.md`. Noted the `hard_boundary` (planning only, no code) and `conversation_rhythm` ("Ask, don't assume. Generating a spec with wrong assumptions is worse than asking one more question.").

### Mode detection
The prompt has no signals that pin a mode:
- No VISION.md / ROADMAP.md provided or discoverable in the output workspace → looks Greenfield-ish.
- "Improve our dashboard" + "next phase" suggests an Expand scenario (prior phases exist), but there is zero evidence of them.
- The conservative read: mode cannot be determined without asking the user. Per the skill, mode should be "announced and confirmed before proceeding."

### Phase 1 — FRAME
Cannot be completed. The skill's FRAME phase requires problem statement, constraints, success criteria, and anti-goals from the user. None were supplied. Per role-play rule, these were NOT invented; they were recorded as questions in `outputs/docs/clarifying-questions.md` (Batches 1–4, 13 questions total, grouped 2–4 at a time per the "2–3 questions at a time, max" rule — presented as batches the user can answer in order).

### Phase 2 — EXPLORE
Skipped. Exploration without a framed problem would produce fabricated market/technical research pointed at an imaginary product.

### Phase 3 — CONVERGE
Skipped. Nothing to converge.

### Phase 4 — DOCUMENT (minimal, honest version)
Followed the "When a Spec Isn't Ready" guidance from `item-spec.md`:
> "If you can't write specific requirements for an item, it needs … a spike — mark it as a research task whose output is a proper spec. Never generate a spec with vague requirements just to fill the roadmap."

Produced:
- `outputs/docs/clarifying-questions.md` — the real primary output of this run.
- `outputs/docs/VISION.md` — placeholder, every non-trivial line `[CONFIRMED]` or `[ASSUMED]`.
- `outputs/docs/ROADMAP.md` — single-row index.
- `outputs/docs/roadmap/phase-1/_overview.md` — notes why there is only one item.
- `outputs/docs/roadmap/phase-1/1.1-dashboard-discovery.md` — a discovery/spike spec whose deliverable is answered clarifying questions, not code.

No decisions/ file — there were no architecture decisions to record.
No backlog/ file — user surfaced no candidate ideas.

### Phase 5 — BRIDGE
Not output as a `/devlyn:auto-resolve` command, because running auto-resolve against 1.1 would not produce code (1.1 is a discovery item requiring the user). Instead, the ROADMAP and the spec both direct the next action: answer `clarifying-questions.md` and re-run `/devlyn:ideate`.

## Handling of missing context (summary)
- Did NOT invent a product, user persona, stack, or metrics.
- Did NOT fabricate pain points ("perf is slow", "needs dark mode", etc.) even though they would have been plausible.
- DID capture every gap as a clarifying question.
- DID produce the minimum honest plan: one discovery spike.
- DID tag every non-trivial statement `[CONFIRMED]` or `[ASSUMED]`.

## Files touched (all inside the sandboxed outputs dir — real `docs/` untouched)
- `outputs/docs/clarifying-questions.md`
- `outputs/docs/VISION.md`
- `outputs/docs/ROADMAP.md`
- `outputs/docs/roadmap/phase-1/_overview.md`
- `outputs/docs/roadmap/phase-1/1.1-dashboard-discovery.md`
- `transcript.md` (this file)
