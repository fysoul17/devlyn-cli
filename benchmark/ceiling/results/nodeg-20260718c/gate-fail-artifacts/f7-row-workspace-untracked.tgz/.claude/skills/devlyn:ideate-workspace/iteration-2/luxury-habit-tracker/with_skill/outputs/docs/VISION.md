# Habit Tracker Vision

## North Star
A personal, local-first habit tracker where I can log a habit today, see my streak, and browse my history — nothing more.

## Principles
1. **Solo and local-first** — All data lives in the browser (localStorage). Tradeoff: no cross-device sync, no backup; acceptable because this is a personal tool for one device.
2. **Direct path only** — Every feature must map to one of three capabilities the user asked for. Tradeoff: many "obvious" additions (reminders, stats, categories) are explicitly out of scope.
3. **Ship one vertical slice fast** — The first deployable version already does the job end to end. Tradeoff: no dedicated "foundation" phase; scaffolding, storage, and deploy are bundled into the feature that uses them.

## Target Users
### Primary
**Me (solo user)** — tracking personal habits on my own device. Pain: existing habit trackers require accounts, cloud sync, and bundle features I don't want. Need: a minimal tool that logs a habit today, shows a streak, and shows history.

### Not For
- Multi-user / team habit tracking — Why: no accounts, no auth, no server.
- Cross-device sync users — Why: local-first by deliberate choice.
- Users who want analytics / coaching / reminders — Why: explicit anti-goals (see below).

## Anti-Goals
- **User accounts / auth** — Why: solo personal app; introduces a category of complexity the user rejected.
- **Server-side storage / database** — Why: local-first was an explicit constraint; localStorage is sufficient.
- **Reminders / notifications** — Why: not in the stated scope.
- **Analytics, charts, goal setting, social features** — Why: not in the stated scope.
- **Theming, custom accent colors, onboarding flows** — Why: luxury items that do not serve the stated problem.

## Success Metrics
- The user can log today's habit in one tap/click from the main screen.
- The current streak is visible without navigating away from the log action.
- Full history of log entries is accessible from the main screen.
- End-to-end flow works on a single device after one Vercel deploy.
