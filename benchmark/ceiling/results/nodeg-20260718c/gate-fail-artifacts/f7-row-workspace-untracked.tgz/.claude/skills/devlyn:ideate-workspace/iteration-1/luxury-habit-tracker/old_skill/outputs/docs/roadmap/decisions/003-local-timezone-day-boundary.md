---
id: 003
title: "Day boundary uses the user's local timezone"
date: 2026-04-14
status: accepted
---

# 003 Day boundary uses the user's local timezone

## Context
"Did I do it today" is the core concept of the app, so "today" must have a precise, consistent definition. Because the app is single-user, local-first, and runs in a browser, the simplest honest definition of "today" is the user's local calendar date.

## Decision
All dates are stored and compared as `YYYY-MM-DD` strings derived from the browser's local timezone. A helper `todayLocal()` produces the canonical value; every consumer (logging, streak, history) calls it rather than reimplementing date math. No UTC conversion anywhere.

## Alternatives Considered

### Store everything in UTC
- Pros: classic "safe" choice for systems crossing timezones.
- Cons: for a single user on one device, UTC introduces bugs where tapping "Done" at 11:30 PM local gets recorded as tomorrow.
- Why rejected: makes the common case wrong to be safe against a case that doesn't exist in this app.

### Store full ISO timestamps and derive dates at read time
- Pros: preserves exact moment of logging.
- Cons: extra work at every read; no feature in Phase 1 needs sub-day precision.
- Why rejected: YAGNI.

## Consequences
- If the user travels across timezones, their "today" shifts with them — acceptable and probably desired.
- Streak calculation is trivial: set membership on date strings.
- If cloud sync is ever added, a migration will be needed to pick a canonical timezone or to store timezone alongside each completion. That's a Phase 2+ problem.
