# Agent Report — Replan Phase 3 (old skill baseline)

## Mode
Replan — user wants Phase 3 rethought from per-category budgets to envelope budgets.

## Files changed (all inside outputs/docs/)
- `ROADMAP.md` — Phase 3 section heading renamed "Budgets" → "Envelope Budgets"; 3.1/3.2 row titles updated; added replanned-on comment.
- `roadmap/phase-3/_overview.md` — expanded from stub to full phase overview with goal, rationale for envelope-over-category, scope, and non-goals.
- `roadmap/phase-3/3.1-budget-set.md` — rewritten. New title "Envelope budget set". Added Context, Requirements (create/edit/delete envelopes, assign transactions, remaining-balance math), Out of Scope (carryover, transfers, templates), Constraints, Dependencies (1.1, 1.2), Verification.
- `roadmap/phase-3/3.2-alerts.md` — rewritten. New title "Envelope depletion alerts". Thresholds at 20% remaining, depleted, and negative balance; in-app only.

## Key decisions (applied as the "most reasonable interpretation")
- Kept Phase 3 structure at 2 items (budget set + alerts) rather than expanding — matches user's "simpler" intent.
- Envelope = name + allocation + period; one envelope per transaction (optional); derived remaining balance, no stored state.
- No carryover, no transfers, no per-envelope custom thresholds — all explicitly Out of Scope to protect v1 scope against auto-resolve over-building.
- Overdrawing is permitted but visually flagged (pragmatic: blocking transactions at an overdraw threshold is a UX trap).
- Alerts are derived on read, not persisted — prevents stale alert state when 3.1 allocations change.

## Skill phases exercised
- Mode detection: Replan.
- FRAME: light — vision already implicit in existing ROADMAP north star.
- EXPLORE: skipped deep research per constraint (keep change scope small).
- CONVERGE: reframed Phase 3 around envelope model, sequenced 3.1 before 3.2 (unchanged dep).
- CHALLENGE (solo, --engine claude): flagged original 3.1 for vague single-requirement spec (no Out of Scope, no verification); revision addresses all 5 axes. No CRITICAL/HIGH findings remaining. No Codex pass (constraint: no mcp__codex*).
- DOCUMENT: rewrote the two item specs + overview, updated ROADMAP index.

## Not changed
- Phase 1 and Phase 2 specs — untouched per user's replan scope.
- No VISION.md exists in this tree; none created (not in scope).
- No decision record added — the envelope-vs-category choice is captured inline in `_overview.md` rationale section, which is sufficient for this replan; a formal ADR would be appropriate if the project gains a `decisions/` folder later.

## Remaining unknowns / open questions
- Period boundary semantics (calendar month vs. rolling 30 days) — assumed calendar month to match existing monthly reporting (2.1).
- Whether envelopes should be visible across the Phase 2 reporting views — not addressed here; would be a new item if wanted.
