# Clarifying Questions (Blocking — Plan Cannot Proceed Without These)

The user's request ("I want to improve our dashboard. Plan the next phase.") lacks the minimum context needed to produce a trustworthy plan. Per the skill's Conversation Protocol ("Ask, don't assume"), these questions MUST be answered before any meaningful FRAME / EXPLORE / CONVERGE work can happen.

Because the user is unavailable in this evaluation, questions are recorded here and only a minimal, heavily-flagged placeholder plan is produced in parallel.

## Batch 1 — Context (must answer first)

1. **What product is this dashboard part of?** (name, one-line purpose)
2. **Who uses it?** (internal ops team, end customers, admins, developers?)
3. **Is there an existing `docs/VISION.md` or `docs/ROADMAP.md`?** — determines mode (Greenfield / Expand / Quick Add).
4. **What tech stack?** (framework, data source, auth)

## Batch 2 — Problem definition

5. **What specifically is wrong with the dashboard today?** — performance, UX, missing data, visual design, mobile, accessibility, something else?
6. **What triggered "I want to improve it" now?** — user complaints, a metric, a launch, a redesign mandate?
7. **Who is complaining and what are they saying?** (if anyone)

## Batch 3 — Goals and constraints

8. **What does "improved" look like in measurable terms?** — e.g. TTI under 2s, task completion rate +20%, NPS target, new KPI surfaced?
9. **What is "the next phase" — a sprint, a quarter, a release?** How much time/effort is available?
10. **Hard constraints?** — stack lock-in, team size, existing data model, brand/design system, deadlines.
11. **Anti-goals** — what should this phase explicitly NOT touch?

## Batch 4 — Scope shape

12. **One focused improvement or a themed set?** (e.g. "just fix perf" vs "redesign + new widgets + export")
13. **Any specific ideas the user already has in mind?** — capture them verbatim before exploring alternatives.

---

Until these are answered, any generated Vision / Roadmap / item specs would be fabrications. The accompanying `VISION.md`, `ROADMAP.md`, and `roadmap/phase-1/1.1-*.md` are intentionally minimal and every non-trivial statement is tagged `[ASSUMED]`.
