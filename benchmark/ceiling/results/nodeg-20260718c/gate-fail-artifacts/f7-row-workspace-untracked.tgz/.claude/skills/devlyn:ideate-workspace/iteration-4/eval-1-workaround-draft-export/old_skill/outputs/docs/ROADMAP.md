# Notes App Roadmap

> **North Star**: A fast, reliable note-taking app.

## Phase 2: Collaboration
<!-- Let users work together on notes. -->

| # | Feature | Status | Priority | Complexity | Spec |
|---|---------|--------|----------|-----------|------|
| 2.1 | Sharing | Planned | — | — | — |

## Phase 3: Draft Resilience
<!-- Give users a way to preserve in-progress drafts across session loss. -->

| # | Feature | Status | Priority | Complexity | Spec |
|---|---------|--------|----------|-----------|------|
| 3.1 | Draft JSON Export and Re-Upload | Planned | High | Low | [spec](roadmap/phase-3/3.1-draft-json-export.md) |

## Completed
<details>
<summary>Phase 1: Foundation (completed 2026-04-22, 2 items)</summary>

| # | Feature | Completed |
|---|---------|-----------|
| 1.1 | Auth | 2026-04-22 |
| 1.2 | Editor | 2026-04-22 |
</details>
