---
id: "N.1"
title: "Clarify dashboard scope and improvement goals"
phase: N
status: blocked-on-user-input
priority: high
complexity: low
depends-on: []
---

# N.1 Clarify dashboard scope and improvement goals

## Context
[CONFIRMED] The user said "I want to improve our dashboard. Plan the next phase." and provided nothing else. [ASSUMED] A dashboard exists somewhere in a product owned by the user. Without FRAME answers, no implementable spec can be written.

## Objective
Answer the 17 questions in `clarifying-questions.md` so that a real Phase N plan can be written.

## Requirements
- [ ] [CONFIRMED] User identifies which dashboard (product, route, audience).
- [ ] [CONFIRMED] User states the felt problem in one sentence (slow / ugly / wrong data / missing feature / etc.).
- [ ] [CONFIRMED] User states the success metric or observable outcome for "improved."
- [ ] [CONFIRMED] User confirms whether `docs/VISION.md` and `docs/ROADMAP.md` already exist (mode: Greenfield vs Expand vs Replan).
- [ ] [CONFIRMED] User lists hard constraints (stack, timeline, team, compliance).

## Constraints
- Do not fabricate answers — Why: the skill's NO GUESSWORK axis explicitly forbids silent assumptions, and downstream `/devlyn:auto-resolve` will build the wrong thing if fed guessed requirements.

## Out of Scope
- Any actual dashboard code changes (this item is a planning gate, not an implementation item).
- Writing Phase-N.2+ specs (cannot be done until this item completes).

## Dependencies
- **Internal**: none
- **External**: the human user

## Verification
- [ ] `clarifying-questions.md` has user-provided answers to all 17 questions.
- [ ] `/devlyn:ideate` is re-run in the appropriate mode (Greenfield/Expand/Replan) with those answers in hand.

---

## [ASSUMED] vs [CONFIRMED] audit for this spec

- [CONFIRMED] User wants to "improve" "our dashboard" and plan the "next phase."
- [ASSUMED] Everything else — including that this is even the right item to generate. The honest alternative is: stop, don't generate a plan at all, ask the questions first.
