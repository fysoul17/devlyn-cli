# Habit Tracker Vision

## North Star
A personal habit tracker where I can log that I did a habit today, see my streak, and see my history — nothing more, nothing less.

## Principles
1. **Personal tool, not a product** — Built for one user (me). Tradeoff: no accounts, no sharing, no multi-user complexity — and no pretending this scales to strangers.
2. **Local-first by default** — Data lives on the device in localStorage. Tradeoff: no automatic cross-device sync; each device holds its own history until (and unless) sync is added later.
3. **Core loop over features** — The only work that matters is: log today, see streak, see history. Tradeoff: we say no to reminders, analytics, theming, and social features even when they seem easy.
4. **Boring stack, obvious choices** — Next.js App Router, Tailwind, shadcn/ui, Vercel. Tradeoff: we give up novelty for predictable build and deploy.
5. **Ship something usable at every phase boundary** — Phase 1 deploys a working app; it doesn't ship scaffolding and call it done. Tradeoff: we bundle "infrastructure" tasks inside the feature they enable rather than making them standalone items.

## Target Users
### Primary
**Me (the solo owner)** — Someone who wants a no-friction way to track a handful of personal habits from phone or laptop. Pain: existing habit apps are bloated with social features, ads, subscriptions, or gamification that get in the way. Need: open app, tap "done today", close app.

### Not For
- Teams / multi-user habit tracking — Why: scope is explicitly solo
- People who need reminders / push notifications — Why: deferred; not part of the core "log + streak + history" loop
- Anyone needing cross-device sync today — Why: localStorage-first is an accepted tradeoff; cross-device comes later (if ever)

## Anti-Goals
- **Accounts, auth, user management** — Why: solo project, one user, no need
- **Server-side persistence (for now)** — Why: localStorage keeps the stack trivial and the hosting free; cloud storage is deferred to backlog
- **Social / sharing features** — Why: this is a personal tool, not a product
- **Gamification (badges, XP, levels)** — Why: the streak number is already the gamification; anything more is decoration
- **Analytics / insight reports** — Why: a history view is enough to see patterns; auto-generated insights are filler until the core loop proves it needs them
- **Theming / light-dark toggles / custom accent colors (in Phase 1)** — Why: default shadcn styling is fine; polish is a luxury item until the core job works

## Success Metrics
- Time to log a habit after opening the app: under 3 seconds (one tap to mark done today)
- Streak calculation is correct across timezone changes and day boundaries (no off-by-one bugs)
- App is deployed on Vercel and reachable from phone and laptop (even if data does not sync across them)
- I actually use it daily for 30+ days — the ultimate test that it is not just a coding exercise
