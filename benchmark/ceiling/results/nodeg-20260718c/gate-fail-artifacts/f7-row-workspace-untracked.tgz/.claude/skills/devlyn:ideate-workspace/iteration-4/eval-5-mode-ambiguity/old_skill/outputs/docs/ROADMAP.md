# Habit Tracker Roadmap

> **North Star**: A minimal local-first habit tracker.

## Phase 3: Engagement (Target: TBD)
Push value back to the user between sessions without pulling them into the app. Weekly digests that summarize streak progress.

| # | Feature | Status | Priority | Complexity | Spec |
|---|---------|--------|----------|-----------|------|
| 3.1 | Weekly email streak summary | Planned | High | Medium | [spec](roadmap/phase-3/3.1-weekly-email-streak-summary.md) |

## Backlog
| Feature | Reason Deferred | Revisit |
|---------|----------------|---------|
| Push notifications | Requires device-specific setup; email-first keeps local-first story cleaner | After 3.1 ships |
| Daily reminders | Risk of notification fatigue before weekly cadence is validated | After 3.1 ships |

## Decisions
| # | Decision | Date | Record |
|---|----------|------|--------|
| 1 | Email as first out-of-app channel | 2026-04-22 | [record](roadmap/decisions/001-email-as-first-channel.md) |

## Completed
<details>
<summary>Phase 1: Core (completed 2026-04-22, 2 items)</summary>

| # | Feature | Completed |
|---|---------|-----------|
| 1.1 | Log habit | 2026-04-22 |
| 1.2 | Streak | 2026-04-22 |
</details>

<details>
<summary>Phase 2: Stats (completed 2026-04-22, 2 items)</summary>

| # | Feature | Completed |
|---|---------|-----------|
| 2.1 | History view | 2026-04-22 |
| 2.2 | Streak heatmap | 2026-04-22 |
</details>
