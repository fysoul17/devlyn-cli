---
id: 001
title: "Next.js App Router on Vercel, Neon Postgres, Clerk for auth"
date: 2026-04-22
status: accepted
---

# 001 Next.js App Router on Vercel, Neon Postgres, Clerk for auth

## Context
The user specified Next.js, Vercel, Neon Postgres, and Clerk as the stack. We need to pin down the specific flavor (Pages vs App Router) and the Postgres driver so every item spec can assume the same environment.

## Decision
- **Framework**: Next.js (latest) using the **App Router** (not Pages Router).
- **Hosting**: Vercel, using Server Components for reads and Server Actions (or Route Handlers) for writes.
- **Database**: Neon Postgres, accessed via `@neondatabase/serverless` (or Vercel's Postgres adapter, which wraps it) — not a classic `pg` pool.
- **Auth**: Clerk, with **Organizations** enabled (see decision 003).
- **ORM**: Drizzle or Prisma, implementer's choice at item 1.1 time — whichever is chosen is documented in the repo README and used consistently across all items.

## Alternatives Considered

### Pages Router instead of App Router
- Pros: Older, more docs and Stack Overflow answers; team may know it better.
- Cons: Vercel's current templates and marketing defaults are App Router; Server Components (the reason to be on Next.js 14+) only exist in App Router; Pages Router is in long-term maintenance mode.
- Why rejected: We'd be starting a new project on the pattern Vercel is moving away from.

### Supabase instead of Neon + Clerk
- Pros: One vendor for DB + auth; RLS is a clean way to enforce workspace scoping.
- Cons: User explicitly picked Neon + Clerk; Supabase auth is not Clerk.
- Why rejected: User intent is explicit.

### Classic `pg` pool against Neon
- Pros: Portable, familiar.
- Cons: Doesn't cooperate with Vercel's serverless runtime — connections leak or exhaust the pool; Neon specifically recommends their serverless driver for this reason.
- Why rejected: A well-known footgun we shouldn't step on.

## Consequences
- All item specs can assume App Router conventions (Server Components for reads, Server Actions for writes, `app/` directory).
- Migrations, seeds, and local dev assume Neon (not a local Postgres container) — contributors need a Neon dev branch. This is the accepted cost of matching the production stack locally.
- Clerk Organizations is the workspace primitive; there is no custom "workspace" table beyond the Clerk org id (see decision 003).
