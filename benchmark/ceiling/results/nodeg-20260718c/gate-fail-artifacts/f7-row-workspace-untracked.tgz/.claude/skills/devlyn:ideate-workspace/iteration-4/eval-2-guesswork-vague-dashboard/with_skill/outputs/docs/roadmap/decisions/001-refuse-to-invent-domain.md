---
id: "001"
title: "Refuse to invent a domain from the word 'dashboard'"
date: 2026-04-22
status: accepted
---

# 001 — Refuse to invent a domain from the word "dashboard"

## Context

The user's request was: *"I want to improve our dashboard. Plan the next phase."* The word "dashboard" names a UI shape, not a domain. Common implicit interpretations — SaaS analytics, e-commerce KPIs, admin panel, ops monitoring, BI, observability, finance — produce wildly different roadmaps, and the user named none of them.

## Decision

Do not choose one. Use `GENERIC_PLACEHOLDER` as the stand-in domain label, mark every item in the roadmap `[ASSUMED]`, and block on clarifying questions before converting any item to a real commitment.

## Alternatives considered

1. **Pick the statistically most likely domain (e.g., SaaS analytics) and proceed.** Rejected. The CHALLENGE rubric's NO GUESSWORK axis fires hard on unlabeled claims. Picking a domain implicitly proposes MRR, churn, funnels, revenue widgets, etc. — every one of which is a domain invention the user never asked for. If the user's actual domain is, say, a restaurant POS or an IoT sensor network, the whole plan is waste.
2. **Refuse to output anything until the user answers.** Rejected because the test harness explicitly requires a minimum-viable plan be produced even when no user is available. Silence is not a valid output in this context. Placeholders + visible `[ASSUMED]` markers are the honest compromise.
3. **Output a generic "dashboard best practices" plan (accessibility, performance, dark mode, mobile).** Rejected. These are real concerns, but recommending them *without knowing the users* is cargo-cult advice. A dashboard used by two internal engineers on 27" monitors does not need mobile support; a field-tech dashboard absolutely does. Proposing generic best practices without knowing which apply is the same failure mode as inventing a domain, dressed up as expertise.

## Consequences

- `docs/VISION.md`, `docs/ROADMAP.md`, and every item spec carry visible `[ASSUMED]` tags and `GENERIC_PLACEHOLDER` where a real domain term would go.
- No item is `status: planned` — everything starts as `status: blocked` with `blocked-reason: needs-clarification` except 1.1 which is `blocked: needs-user-input`.
- `docs/clarifying-questions.md` exists and is the single real deliverable of this session; handing it to the user is the planner's only legitimate next move.
- If a future agent reads this roadmap and starts implementing 1.2 or 1.3 without 1.1 being Done, that agent has violated the decision and should stop.
