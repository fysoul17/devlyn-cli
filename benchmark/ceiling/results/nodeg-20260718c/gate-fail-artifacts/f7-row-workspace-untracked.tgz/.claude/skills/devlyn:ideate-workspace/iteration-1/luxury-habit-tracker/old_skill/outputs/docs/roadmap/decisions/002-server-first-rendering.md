---
id: 002
title: "Server Components by default, Client Components pushed to leaves"
date: 2026-04-14
status: accepted
---

# 002 Server Components by default, Client Components pushed to leaves

## Context
The app is Next.js App Router. Project convention (and general best practice) is to build Server Components first and introduce `'use client'` only where needed. The interactivity here is real — logging, streak updates, history grid — but it is localized to specific components.

## Decision
Page shells (`app/page.tsx`, `app/habits/[id]/page.tsx`, layout) remain Server Components. Only the smallest leaves that actually need state, effects, or `localStorage` access become Client Components: `HabitList`, `HabitRow`, the add/rename/delete dialogs, and the history grid.

## Alternatives Considered

### Whole app as Client Components
- Pros: simpler mental model, no boundary discussions.
- Cons: larger JS payload, loses the "server-first" convention, ships unnecessary code to the browser.
- Why rejected: contradicts project convention and Next.js best practice; payload matters even for a small app.

### Server Actions for all mutations
- Pros: uniform pattern, works across network.
- Cons: localStorage is client-only — Server Actions can't touch it. Would require a server store, undoing decision 001.
- Why rejected: incompatible with the local-first choice.

## Consequences
- Smaller client JS bundle.
- Clear rules for where the client boundary lives, so later items don't drift.
- Anyone implementing an item must know which components are client vs. server before editing them.
