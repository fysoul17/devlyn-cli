# Habit Tracker Roadmap

> **North Star**: A personal habit tracker where I can log that I did a habit today, see my streak, and see my history — nothing more, nothing less.

## Phase 1: Core habit loop (Target: 1-2 weekends)
Ship the one thing this app exists to do — log a habit today and see a streak — deployed and usable from phone or laptop. History view lands in the same phase so the app is genuinely "done" at the phase boundary.

| # | Feature | Status | Priority | Complexity | Spec |
|---|---------|--------|----------|-----------|------|
| 1.1 | Log a habit today and see streak | Planned | High | Medium | [spec](roadmap/phase-1/1.1-log-and-streak.md) |
| 1.2 | History view | Planned | High | Low | [spec](roadmap/phase-1/1.2-history-view.md) |

## Backlog
| Feature | Reason Deferred | Revisit |
|---------|----------------|---------|
| Cross-device sync (cloud-backed storage) | localStorage-first is the explicit starting point; sync needs accounts/auth which are out of scope | After 30+ days of daily use proves the app is worth syncing |
| Reminders / push notifications | Not part of the core log + streak + history loop; adds notification-permission UX and background scheduling complexity | After core loop is stable and used daily |
| Analytics / insight reports (weekly summaries, best day of week, etc.) | History view already lets me see patterns; auto-insights are filler until core proves it needs them | Once there is 3+ months of real history data to analyze |
| Theming / light-dark / accent customization | Default shadcn/ui styling is fine; theming is a luxury item | Only if I actively dislike the default look after using it for weeks |
| Habit categories / tags / folders | Premature organization; I will not have enough habits for this to matter | When I have 10+ habits and actually want to group them |
| Import / export JSON backup | Useful if I ever need to move data, but not part of the core loop | Before or as part of the cross-device sync work |

## Decisions
| # | Decision | Date | Record |
|---|----------|------|--------|
| 1 | Use localStorage as the data store (defer cloud) | 2026-04-22 | [record](roadmap/decisions/001-localstorage-first.md) |
| 2 | Next.js App Router + Tailwind + shadcn/ui on Vercel | 2026-04-22 | [record](roadmap/decisions/002-stack.md) |
| 3 | Local device date as the streak day boundary | 2026-04-22 | [record](roadmap/decisions/003-day-boundary.md) |
