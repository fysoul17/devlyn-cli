# Collaborative Doc Editor Vision

## North Star
A real-time collaborative document editor that two people can co-edit live in a browser without setup friction — simpler surface area than Google Docs, shipped in weeks, not years.

## Principles
1. **Real-time collaboration is the product** — Every Phase 1 item must move the collab loop forward. Tradeoff: we defer single-user-only polish (theming, rich export, templates) until the collab loop is solid.
2. **Boring, proven primitives** — Use the known-good CRDT/editor stack rather than invent. Tradeoff: we accept dependency on Yjs/TipTap conventions instead of maximal control over the data model.
3. **Thin feature surface** — Fewer features than Google Docs, done well. Tradeoff: we explicitly say "no" to feature-parity with Docs (comments threads, suggesting mode, revision explorer) until we prove the base.
4. **Self-hostable at low MAU** — At ~500 MAU, a small Postgres + Node sync server is cheaper and more flexible than a managed collaboration-as-a-service. Tradeoff: we carry a small amount of ops work a managed service would eliminate.

## Target Users
### Primary
**Small team or pair (2–5 people) drafting documents together** — Today they copy-paste in Slack, email drafts back and forth, or wait for Google Docs to load. Pain: context-switching between chat and doc, waiting for collaborator cursors, heavyweight feature surface when all they need is co-editing. Need: a URL, two cursors, it just works.

### Not For
- Enterprise document management (permissions matrices, compliance, retention policies) — Why: out of scope for small-team MVP; well-served by incumbents.
- Solo writers who don't collaborate — Why: collab is the reason this exists; a solo user is better served by any plain editor.

## Anti-Goals
- **Feature parity with Google Docs** — Why: the whole bet is "simpler". Matching the feature surface defeats the positioning.
- **Rich real-time features beyond text + presence in Phase 1** — Why: comments, suggestions, revision history each add collab-consistency complexity; lock the core text+presence loop first.
- **Multi-region active-active** — Why: at ~500 MAU, a single-region deploy is sufficient and vastly simpler.
- **Custom CRDT implementation** — Why: building a CRDT from scratch is a multi-person-year project; Yjs is production-tested and covers the need.

## Success Metrics
- Two browsers on the same doc URL see each other's edits reflected within ~200ms on a healthy network.
- A fresh user can sign up, create a doc, share the link, and see a second editor join in under 2 minutes end-to-end.
- Server cost at 500 MAU stays in double-digit USD/month range (well within hobby/indie budgets).
- Editor TipTap scroll + keystroke latency is imperceptible on a mid-range laptop (no user-visible lag under normal typing).

## Assumptions (to confirm as work lands)
These defaults were picked because the user asked for "reasonable defaults". They are not user-confirmed and should be revisited if constraints change.
- Next.js (App Router) frontend on Vercel.
- ~500 MAU scale (Phase 1 infra sized for this, not 500k).
- Self-hosted sync server (vs managed service) is acceptable.
- Yjs ecosystem (TipTap + y-prosemirror + Hocuspocus) is acceptable over Automerge/Loro.
- Postgres as durable store for document snapshots.
