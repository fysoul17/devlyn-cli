# Done Criteria

Source: `.devlyn/SPEC-CONTEXT.md` (derived from `docs/roadmap/phase-test/T.1-oauth-integration.md`)

## Requirements
- [ ] Configure Google OAuth2 app and GitHub OAuth app
- [ ] /auth/callback route handles the OAuth redirect
- [ ] Session token issued on successful auth (JWT)
- [ ] Secure cookie storage for the session
- [ ] Token refresh on expiry

## Out of Scope
- MFA (Phase 2)
- Email/password fallback (Phase 3)

## Verification Method
- [ ] User clicks "Sign in with Google", is redirected, returns with session
- [ ] Session token decodes correctly
