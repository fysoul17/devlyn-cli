---
id: 001
title: "Use localStorage as the data store (defer cloud)"
date: 2026-04-22
status: accepted
---

# 001 Use localStorage as the data store (defer cloud)

## Context
This is a solo personal tool with no accounts and no other users. The project needs a place to store habits and daily logs. Options range from localStorage (no backend) to a full database behind an API. The user explicitly chose "local-first is fine, data in localStorage initially".

## Decision
Store all application state — habits and daily log entries — in `localStorage` under a single versioned key (e.g. `habit-tracker:v1`). No server-side persistence in Phase 1. No sync, no backup, no export.

Data shape (initial):
```
{
  version: 1,
  habits: [{ id, name, createdAt }],
  logs: [{ habitId, dayKey }]  // dayKey is YYYY-MM-DD in local time
}
```

## Alternatives Considered

### Vercel KV / Postgres / any cloud DB
- Pros: cross-device sync "for free", durable across browser data wipes
- Cons: requires accounts or device identity, adds backend code, adds env vars, pulls the app out of the "free tier + one hour to ship" sweet spot
- Why rejected: scope is solo personal tool; accounts are an explicit anti-goal; sync is an accepted tradeoff the user already made

### IndexedDB
- Pros: more capacity, structured queries, better for large datasets
- Cons: more API surface, async-everywhere, overkill for a few hundred small records per year
- Why rejected: localStorage is synchronous, trivial to use, and the data volume is tiny (one habit = tens of bytes; one log entry = tens of bytes; a year of daily logs for 10 habits is under 100KB)

### SQLite in the browser (wa-sqlite, sql.js)
- Pros: real SQL, nice for history queries
- Cons: bundle size hit, setup cost, dramatic overkill for a log + count feature
- Why rejected: the queries needed (current streak, last 30 days) are trivial array operations on a few hundred entries

## Consequences
- No cross-device sync — each device gets its own history. Explicitly accepted.
- Data is lost if the user clears browser data. Acceptable for a personal tool at this stage; revisit if the app becomes indispensable.
- Implementation is dramatically simpler — no API routes, no DB schema, no auth. The whole app is a client-side state problem.
- Migration path is clean: when cloud sync arrives, the same JSON shape can be POSTed to a backend with minimal refactor.
