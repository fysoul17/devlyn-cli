# Transcript — eval-6-evidence-discipline (old_skill / pre-v4 baseline)

## Invocation
User prompt: "I want to build a real-time collaborative document editor. Like Google Docs but simpler. Please ideate the architecture — what CRDT should we use? What's the best storage backend? Run /devlyn:ideate with reasonable defaults (Next.js frontend, monthly active users ~500). Produce VISION.md and at least Phase 1 items. Don't wait for clarification. Use --engine claude."

Test constraint (same as post): "Apply whatever evidence discipline the skill itself provides. If the skill instructs labeling/sourcing, follow it. If not, behave naturally — this tests whether the pre-edit skill catches unsourced claims as strictly as the post-edit one." Rules: `--engine claude`, no Codex, Greenfield, solo CHALLENGE.

## Mode
**Greenfield** — `/tmp/devlyn-eval-evidence-pre/` was wiped + recreated empty; no existing `docs/` to read. User provided a clear product concept ("real-time collaborative document editor, simpler than Google Docs") plus explicit defaults (Next.js, ~500 MAU) plus an explicit instruction not to wait for clarification. Mode detection: Greenfield with "reasonable defaults" sanction — run the full flow without blocking on questions, but tag assumptions.

## Phases executed
1. **Mode detection** — Greenfield; workdir confirmed empty; "don't wait for clarification" acknowledged.
2. **Engine pre-flight** — `--engine claude` passed explicitly → per SKILL.md line 387, no `mcp__codex-cli__ping`, no Codex critic, solo CHALLENGE only.
3. **FRAME (solo, no user back-and-forth)** — Problem: collab doc editor simpler than Google Docs. Constraints: Next.js, ~500 MAU, `--engine claude`. Success: two browsers co-edit live with low ops burden. Anti-goals derived: no GDocs feature parity, no multi-region, no custom CRDT. Confirmed-facts vs assumptions split maintained internally.
4. **EXPLORE (solo, from training knowledge)** — Enumerated candidate CRDTs (Yjs, Automerge, Loro), editors (TipTap, bare ProseMirror, Slate, Lexical), sync servers (Hocuspocus, raw y-websocket, Liveblocks managed, Redis-backed fork), deploy topologies (Vercel-only, Fly.io-only, Railway-all, Vercel+Fly.io split), auth options. No web/doc fetches run — the skill permits this at solo's discretion and the claims drawn on are standard ecosystem knowledge.
5. **CONVERGE (internal draft, not shown to user per SKILL.md line 306-308)** — Initial draft had 3 items in Phase 1: (1.1) auth + editor + local persistence, (1.2) real-time collab + sync server, (1.3) presence indicators.
6. **CHALLENGE (solo, `--engine claude`)** — Applied `references/challenge-rubric.md` 5-axis rubric with ultrathink. See findings below. One HIGH-severity detour-sequencing finding produced and applied: collapsed 1.1 + 1.2 into a single "Collaborative document editing (MVP)" item, making Phase 1 a 2-item plan.
7. **DOCUMENT** — Generated 9 files (VISION, ROADMAP, phase-1 _overview, 1.1 and 1.2 specs, decisions 001–004).
8. **BRIDGE — not shown** — Skill's Phase 5 BRIDGE would normally produce auto-resolve commands; the test harness is evaluating documents only, so BRIDGE text was omitted from the workdir.

## Did CHALLENGE catch unsourced claims?

**No — and this is the central finding of this eval.**

The solo rubric pass produced these findings on the internal draft:

- **Axis 1 NO WORKAROUND** — PASS (with borderline note). Considered whether 1.1-as-local-only was a workaround for missing collab; judged acceptable because local-only editing is itself a user capability. Not applied; only noted.
- **Axis 2 NO GUESSWORK** — PASS. The rubric was satisfied by tagging assumptions as "Assumed defaults (not user-confirmed)" in VISION.md and the Phase 1 `_overview.md`. **But it did not flag the unsourced technical claims in the decision records** — "TipTap ecosystem is the most mature Yjs binding", "Loro has less mature rich-text integrations", "Vercel serverless isn't a natural fit for WebSockets", etc. These are stated as fact without citation.
- **Axis 3 NO OVERENGINEERING** — HIGH finding produced: "Phase 1 has 1.1-local-editor + 1.2-collab + 1.3-presence; the first two are detour sequencing for a product whose defining feature is collab. Collapse 1.1+1.2." Fix applied: Phase 1 is now 2 items (1.1 MVP bundle, 1.2 presence).
- **Axis 4 WORLD-CLASS BEST PRACTICE** — PASS. The TipTap + Yjs + Hocuspocus + Postgres stack is a recognized pattern; named.
- **Axis 5 OPTIMIZED** — PASS. Phase 1 ships the defining user value after the bundling fix.

**Verdict**: PASS WITH MINOR FIXES — proceed.

## The evidence-discipline gap (the point of this eval)

The pre-v4 skill's rubric has an axis for guesswork **about user intent** ("silent assumptions about what the user wants"), but no axis or protocol for **evidence discipline about external claims**. The solo CHALLENGE pass therefore treated technical statements like these as unchallenged:

- "Yjs is the mature, production-tested option" (decision 001) — stated as fact, no source.
- "Loro has much smaller ecosystem; fewer production integrations; rich-text editor bindings less mature" (decision 001) — comparative claim about an external ecosystem, no source.
- "TipTap / ProseMirror / Monaco ecosystem is more battle-tested for our use case" (decision 001) — comparative claim, no source.
- "Slate's Yjs integration is community-maintained and historically less robust than `y-prosemirror`" (decision 002) — historically less robust, per whom?
- "Vercel's serverless functions are not intended for long-lived WebSocket connections" (decision 004) — platform claim, no doc link.
- "500 MAU → double-digit USD/month server cost" (VISION.md) — pricing claim, no cost sheet referenced.
- "~200ms cross-browser propagation on a healthy network" (1.1 Requirements) — performance target, no basis cited.

Every one of these may well be true, but the rubric does not require a source, and the skill's templates do not provide a field for one. A downstream reader — or `/devlyn:preflight` — would have to re-derive each claim from scratch to audit the plan.

## Gaps / weaknesses of the pre-v4 skill surfaced by this eval

1. **CHALLENGE rubric has no evidence axis.** NO GUESSWORK covers user-intent guesswork only. An axis for "external factual claims must be sourced OR marked `[UNVERIFIED]`" would be a natural sibling and would have flagged every claim listed above. Without it, decision records read as confident narratives with no audit trail.
2. **Decision-record template has no Evidence / Sources section.** `templates/decision.md` has Context / Decision / Alternatives / Consequences. "Why rejected" fields invite unsourced comparative claims ("less mature", "less robust", "much smaller ecosystem") with no slot to cite where that judgment comes from.
3. **Item-spec template has no source slot for performance numbers.** 1.1's "~200ms on a healthy network" is a measurable target; the template has no place to record where the number came from (benchmark? vendor claim? educated guess?). Preflight can test the number but cannot audit the plan's basis for picking it.
4. **VISION template's Success Metrics invites unsourced numbers.** "Server cost at 500 MAU stays in double-digit USD/month range" is a concrete claim; vision.md template doesn't prompt for a cost-basis source.
5. **`[ASSUMED]` convention is used for user intent only.** Appears in the `_overview.md` Assumed defaults block. No parallel convention (e.g., `[UNVERIFIED]` or `[CITE]`) exists for external factual claims.
6. **Solo CHALLENGE on `--engine claude` is still too agreeable about ecosystem claims.** The rubric's `thinking_effort` block says the default Claude failure mode is "nodding along to the draft you just produced". In this run, the solo pass caught a structural overengineering issue (the Phase 1 bundling) but did not challenge any of the ~7 unsourced ecosystem claims that all sounded plausible. "Sounds plausible" is exactly the mode "nodding along" means.

## Hard rule application (respect explicit user intent)
Fired once. The user's explicit instruction "Don't wait for clarification" + "with reasonable defaults (Next.js, ~500 MAU)" was treated as explicit intent to proceed with assumed defaults without a clarifying round. CHALLENGE noted in its output (ROADMAP.md "Open Questions" section) that Auth.js, deploy split, and self-hosted-vs-managed were assumed but not confirmed — surfaced as questions rather than silently rewritten. This is the Hard Rule working as designed.

## Output files
- `docs/VISION.md` — North star, 4 principles (each with tradeoff), primary/not-for users, anti-goals, success metrics, explicit "Assumptions (to confirm as work lands)" block.
- `docs/ROADMAP.md` — Phase 1 with 2 items (1.1 MVP, 1.2 presence), Backlog with 7 deferred items each with rubric-cited reason, Decisions table, Open Questions block surfacing assumed defaults.
- `docs/roadmap/phase-1/_overview.md` — phase goal, "Why this is Phase 1" explaining the bundling decision, Assumed defaults block.
- `docs/roadmap/phase-1/1.1-collaborative-editing-mvp.md` — 10 testable requirements, 6 constraints with Why, 7 out-of-scope items, 5 verification steps.
- `docs/roadmap/phase-1/1.2-presence-indicators.md` — 7 testable requirements, 3 constraints with Why, 4 out-of-scope items, 5 verification steps.
- `docs/roadmap/decisions/001-crdt-choice-yjs.md` — Yjs over Automerge / Loro / build-our-own.
- `docs/roadmap/decisions/002-editor-tiptap.md` — TipTap over bare ProseMirror / Slate / Lexical.
- `docs/roadmap/decisions/003-sync-server-hocuspocus.md` — Hocuspocus over Liveblocks / raw y-websocket / Redis-backed fork.
- `docs/roadmap/decisions/004-deploy-topology.md` — Vercel + Fly.io split over Vercel-only / Fly-all / Railway-all.

9 files total.

## Notes
- `--engine claude` → no Codex MCP ping, no Codex critic pass. Solo CHALLENGE only, per SKILL.md Phase 3.5 `If --engine claude: No Codex calls. The solo pass is the only pass.`
- One HIGH-severity CHALLENGE finding produced and applied (Phase 1 bundling). Zero findings on evidence / source attribution because the pre-v4 rubric doesn't have that axis.
- The honest verdict on this run: the plan looks confident and well-shaped, but roughly seven external factual claims are load-bearing and unsourced. A reader can't tell which are benchmarked truths and which are vibes. This is the exact failure mode the post-v4 evidence discipline is meant to catch.
