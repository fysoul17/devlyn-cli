# TaskFlow Vision

## What is TaskFlow?
A lightweight task management app for small teams. Simple, fast, focused.

## Success Criteria
- Teams can create, assign, and track tasks
- Real-time updates when tasks change
- Clean, responsive UI that works on mobile
- Secure authentication with team-based access control

## What's Next
- Phase 1: Core task management
- Phase 2: Team collaboration features
