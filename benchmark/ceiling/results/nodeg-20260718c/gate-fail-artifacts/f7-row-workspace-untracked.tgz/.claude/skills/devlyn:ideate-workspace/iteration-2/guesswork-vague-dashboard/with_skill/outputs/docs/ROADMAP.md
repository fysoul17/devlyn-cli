# Roadmap

> Status: STUB. Intentionally empty of concrete items. See `clarifying-questions.md`.

## Active

### Phase 1 — Clarify scope of "improve the dashboard" (blocking)

| # | Feature | Status | Spec |
|---|---------|--------|------|
| 1.1 | Answer framing questions for "improve the dashboard" | blocked-on-user | [spec](roadmap/phase-1/1.1-frame-dashboard-improvement.md) |

No further items can be planned honestly until 1.1 is complete. Adding speculative items here would be guesswork and would fail the NO GUESSWORK axis of the challenge rubric.

## Completed
(none)

## Backlog
(none — intentionally empty; backlog entries would also be guesses)
