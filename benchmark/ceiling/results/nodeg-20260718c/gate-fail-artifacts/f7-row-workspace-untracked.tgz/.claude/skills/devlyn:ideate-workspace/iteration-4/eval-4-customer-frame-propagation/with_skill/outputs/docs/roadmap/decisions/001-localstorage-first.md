---
id: 001
title: "localStorage for Phase 1, Supabase deferred"
date: 2026-04-22
status: accepted
---

# 001 localStorage for Phase 1, Supabase deferred

## Context
The product is a solo-freelancer expense tracker with no auth and no team. The user explicitly asked for localStorage initially with "can add Supabase later." We need to decide the Phase 1 storage boundary and the shape of the code so that swapping in Supabase later is not a rewrite.

## Decision
Phase 1 persists all expense data in the browser's `localStorage` under a versioned key (`devlyn.expenses.v1`). All persistence calls flow through a single `ExpenseStore` module with a small interface (`list`, `add`, `update`, `delete`). Phase 2.1 will reimplement the same interface against Supabase without changing feature code.

## Alternatives Considered

### IndexedDB from day one
- Pros: larger quotas, richer query capability, async API aligns better with a future network backend.
- Cons: heavier code surface for a ~four-column schema; async API adds complexity to every feature in Phase 1 for no user-visible benefit at solo-freelancer data volumes.
- Why rejected: the complexity buys us nothing Phase 1 needs, and the migration path to Supabase is no easier from IndexedDB than from localStorage because Supabase is remote anyway.

### Supabase from day one
- Pros: cross-device from the start; no future migration.
- Cons: introduces auth (user did not want), server setup, environment secrets, and network failure modes. Violates the user's explicit "localStorage initially" request and the "solo use, no accounts" anti-goal.
- Why rejected: directly contradicts user intent; pushes Phase 1 complexity up sharply for a use case (single device, solo) where localStorage is sufficient.

### SQLite-in-the-browser (via wasm)
- Pros: real SQL, structured query.
- Cons: large bundle cost, overkill for four fields, no real user-visible benefit over a JSON array for Phase 1 volumes.
- Why rejected: bundle size works directly against the 10-second capture North Star; over-engineering.

## Consequences
- Storage is trivial in Phase 1: read/write a JSON array.
- Clearing browser data loses history unless the user exports CSV first — item 1.4 (CSV export) is therefore a functional backup mechanism, not just a tax-time convenience.
- Cross-device use is deferred until Phase 2.1.
- The `ExpenseStore` interface is load-bearing: every feature must go through it, because that's what makes the Phase 2.1 swap cheap.
