# Notes App Roadmap

> **North Star**: A fast, reliable note-taking app.

## Phase 2: Collaboration
<!-- Sharing notes between users. -->

| # | Feature | Status | Priority | Complexity | Spec |
|---|---------|--------|----------|-----------|------|
| 2.1 | Sharing | Planned | — | — | — |

## Phase 3: Resilience (Target: next)
<!-- Close the session-expiry data-loss gap that knowledge workers hit when the browser logs them out mid-draft. -->

| # | Feature | Status | Priority | Complexity | Spec |
|---|---------|--------|----------|-----------|------|
| 3.1 | Draft JSON Export / Re-Upload | Planned | High | Low | [spec](roadmap/phase-3/3.1-draft-json-export.md) |

## Backlog
| Feature | Reason Deferred | Revisit |
|---------|----------------|---------|
| Autosave drafts to Postgres (restore on next login) | CHALLENGE rubric flagged 3.1 as a workaround for missing autosave. User explicitly chose manual export first; autosave is the known-good pattern and should be considered as a follow-on or replacement. | After 3.1 ships or if user confirms replacement |

## Decisions
| # | Decision | Date | Record |
|---|----------|------|--------|
| — | — | — | — |

## Completed
<details>
<summary>Phase 1: Foundation (completed 2026-04-22, 2 items)</summary>

| # | Feature | Completed |
|---|---------|-----------|
| 1.1 | Auth | 2026-04-22 |
| 1.2 | Editor | 2026-04-22 |
</details>
