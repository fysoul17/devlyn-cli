# Freelancer Expense Tracker Vision

## North Star
A solo freelancer can log a business expense in under 10 seconds and pull a tax-ready summary of the year in one click.

## Principles
1. **Friction is the enemy** — Every extra field, tap, or confirmation is a reason the freelancer won't log the expense. Tradeoff: we accept fewer configurable knobs, sensible defaults over customization.
2. **Local-first, cloud-optional** — Data lives in the browser so the app works offline and needs zero setup; cloud sync is an upgrade path, not a precondition. Tradeoff: cross-device use requires an explicit migration step later, not day-one parity.
3. **Tax-time ready, year-round** — Every design choice should make April 15 easier. Tradeoff: we prioritize categorization and export over real-time dashboards and charts.
4. **Solo, not social** — No auth, no sharing, no team. Tradeoff: we can't grow into a team product without a full rewrite, and that's fine.

## Target Users
### Primary
**Solo freelancer (founder's own use first)** — Juggles client work, travel, software subscriptions, and the occasional coffee receipt. Pain: scrambles at tax time to reconstruct deductions from scattered bank statements, email receipts, and memory. Need: a fast, personal ledger that classifies each expense the moment it happens and spits out a tax-ready CSV on demand.

### Not For
- **Teams / agencies** — Why: shared access, approvals, and roles are a different product class.
- **W-2 employees filing reimbursements** — Why: corporate expense flows need employer integrations this deliberately avoids.
- **Accountants managing many clients** — Why: multi-book, multi-client is explicitly out of scope.

## Anti-Goals
- **Authentication and accounts** — Why: personal-use tool, zero friction, data lives on-device.
- **Multi-user or team features** — Why: solo product; adding users changes the data model and the trust model.
- **Receipt OCR / photo capture** — Why: large scope, adds image storage, and the 10-second entry goal is met by a text amount plus category.
- **Bank / card auto-sync** — Why: requires Plaid-class integration, credentials, and background jobs — all heavy for v1.
- **Invoicing, time tracking, P&L reports** — Why: this is an expense tracker, not a bookkeeping suite.
- **Mobile-native apps** — Why: a responsive Next.js web app covers the phone-from-a-cafe use case without a separate codebase.

## Success Metrics
- **Time to log one expense**: under 10 seconds from app open to "saved" (measured by the founder using the app in the wild).
- **Tax export usability**: the founder can hand the year-end CSV to a tax preparer with zero cleanup.
- **Daily use**: the app is opened at least 3 days a week during an active work week.
- **Survival to Supabase**: when the founder outgrows localStorage, migrating to Supabase takes under one afternoon — no data loss, no schema rewrite.
