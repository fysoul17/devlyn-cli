---
id: 003
title: "Clerk Organizations model the sales team workspace"
date: 2026-04-22
status: accepted
---

# 003 Clerk Organizations model the sales team workspace

## Context
The product is a shared workspace for an 8-person team. We need a primitive that represents "the sales team" — a container every prospect and every touch belongs to, and a membership list of users who can see it. Clerk offers Organizations out of the box; we could also hand-roll a `workspaces` table with our own membership.

## Decision
Use Clerk Organizations as the workspace. Every row that belongs to a workspace stores the Clerk `organizationId` (string). The app has a thin `organizations` and `users` mirror for foreign-key joins, but the source of truth for membership and roles is Clerk.

## Alternatives Considered

### Hand-rolled `workspaces` table with our own membership
- Pros: Full control over membership lifecycle, roles, invitations; no coupling to a specific auth vendor.
- Cons: We'd rebuild invitation flows, role management, and org-switching UIs that Clerk already ships.
- Why rejected: We're 8 users on one team; we do not need workspace features Clerk doesn't already provide. The cost of rebuilding is real; the benefit is theoretical.

### One workspace = one row, no Clerk org linkage
- Pros: Simpler mental model if only one workspace ever exists.
- Cons: Breaks the second a second team wants to use the product; mixes product logic with deployment topology.
- Why rejected: Premature simplification.

## Consequences
- Every DB query in item 1.1 filters by `organizationId` from the Clerk session. This is the hard scoping rule; any query that forgets it leaks data across orgs.
- Invite / remove / role-change UI is Clerk's default UI — we don't build these ourselves unless a specific need appears.
- The `ownership_changes` table in 2.2 references our `users` mirror, which is kept in sync with Clerk via a webhook on user creation (item 1.1 implements that webhook).
- Admin-only operations (CSV import in 1.2) gate on Clerk's `org:admin` role check — we don't maintain our own roles table.
