---
id: 002
title: "Bundle scaffold / store / deploy into feature items, no standalone infrastructure items"
date: 2026-04-14
status: accepted
---

# 002 Bundle scaffold / store / deploy into feature items

## Context
The initial internal Phase 1 draft had six items: scaffold, data store, log-today, streak, history, deploy. The CHALLENGE rubric (axes 3 and 5) flagged this as detour sequencing and a dead phase — four of the six items are not user-visible on their own.

## Decision
Phase 1 has exactly two items, both user-visible: "1.1 Log a habit today and see streak" and "1.2 History view". Scaffolding, localStorage wiring, shadcn setup, and the initial Vercel deploy are part of item 1.1's done criteria. History reads from the same store in 1.2. There are no standalone infrastructure items.

## Alternatives Considered

### Traditional infrastructure-first decomposition (6 items)
- Pros: small, isolated PRs; each task has a narrow focus.
- Cons: four items ship nothing a user can see; the first user-visible win is deep into the phase; classic detour sequencing.
- Why rejected: for a one-sitting personal project, the overhead of splitting is larger than the "isolation" benefit, and it fails the OPTIMIZED and NO OVERENGINEERING axes of the challenge rubric.

### One monolithic item for the whole product
- Pros: fewest possible items.
- Cons: the history view is a genuinely separable read-only slice; keeping it separate lets 1.1 ship and be used while 1.2 is built.
- Why rejected: 1.2 is a natural seam that preserves shippability without adding a detour.

## Consequences
- Item 1.1 is slightly larger (it owns scaffolding and first deploy) but ships an end-to-end usable product on its own.
- Item 1.2 is trivially small and depends only on 1.1's data model.
- Any future "infrastructure" work (e.g., migrating to IndexedDB) is still a feature of the item that needs it, not a standalone task.
