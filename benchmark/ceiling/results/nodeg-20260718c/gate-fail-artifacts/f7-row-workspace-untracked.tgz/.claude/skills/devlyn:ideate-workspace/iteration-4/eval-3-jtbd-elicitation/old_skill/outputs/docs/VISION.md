# Prospect Pulse Vision

## North Star
Give an 8-person sales team instant visibility into which prospects are going cold, so no deal dies from neglect.

## Principles
1. **Staleness is the primary signal** — The whole product revolves around "how long since we last touched this prospect." Tradeoff: we accept being narrower than a full CRM so staleness stays load-bearing and obvious.
2. **Shared-workspace by default** — Every team member sees the same pipeline; nothing hides in a personal file. Tradeoff: we accept that every prospect is visible to the whole team rather than shipping per-user privacy controls.
3. **Replace the spreadsheet, don't extend it** — The product must feel like a clear upgrade over the shared sheet within the first session. Tradeoff: we accept building opinionated views rather than a flexible grid.
4. **Log a touch in under 10 seconds** — The staleness signal is only trustworthy if the team actually logs touches. Tradeoff: we accept a minimal touch record (type + short note) rather than rich activity timelines.

## Target Users
### Primary
**Sales team members on an 8-person team** — They currently share a spreadsheet that grows messy as rows multiply, columns drift, and "last contacted" becomes unreliable. Pain: they lose deals because prospects quietly go stale and nobody notices until it's too late. Need: a single shared view that surfaces cold prospects automatically and lets them log a touch in a few seconds.

### Not For
- Enterprise sales orgs (100+ seats) — Why: their workflows justify Salesforce/HubSpot; we'd compete on features we deliberately exclude.
- Solo founders doing outbound — Why: a shared-workspace product is overkill for one person; a spreadsheet is still fine at that scale.
- Marketing or customer-success teams — Why: their workflow is campaign- and account-shaped, not prospect-staleness-shaped.

## Anti-Goals
- **Full CRM feature parity** — Why: scope balloons, staleness stops being the point, and we end up in a fight we can't win.
- **AI lead scoring or predictive next-best-action** — Why: the team's problem is visibility, not prediction. Adding ML is luxury until the core staleness loop is proven.
- **Outbound email automation or sequences** — Why: that's an adjacent product; building it here splits focus from the staleness loop.
- **Per-user private pipelines** — Why: contradicts the shared-workspace principle; hiding prospects is exactly the problem the spreadsheet already has.
- **Mobile-first UX** — Why: reps manage their pipeline at a desk; optimizing for mobile distracts from the desktop workflow that actually gets used.

## Success Metrics
- **Spreadsheet deprecation**: within 4 weeks of launch, the shared spreadsheet is no longer the team's source of truth (measured by asking the team).
- **Staleness coverage**: at least 80% of active prospects have a touch logged in the last 14 days (measured from the DB).
- **Time to log a touch**: median under 10 seconds from clicking the prospect to confirmation (measured by instrumenting the touch form).
- **Cold-prospect rescue rate**: of prospects flagged cold, at least 30% get a touch within 7 days of the flag (measured from the DB).
