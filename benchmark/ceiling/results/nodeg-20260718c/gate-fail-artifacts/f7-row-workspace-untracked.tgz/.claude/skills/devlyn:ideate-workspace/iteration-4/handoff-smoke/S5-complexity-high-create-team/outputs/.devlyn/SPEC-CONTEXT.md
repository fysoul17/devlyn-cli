---
id: T.1
complexity: high
priority: high
depends-on: []
source-spec: docs/roadmap/phase-test/T.1-oauth-integration.md
---

## Customer Frame
When a returning user wants to sign in, they want to use their existing Google or GitHub account, so they can avoid creating a new password.

## Objective
Users can sign in with Google or GitHub OAuth2 and the system issues a session token.

## Requirements
- [ ] Configure Google OAuth2 app and GitHub OAuth app
- [ ] /auth/callback route handles the OAuth redirect
- [ ] Session token issued on successful auth (JWT)
- [ ] Secure cookie storage for the session
- [ ] Token refresh on expiry

## Constraints
- Use nextauth.js v5 — Why: Team already knows it; avoids reinventing auth primitives
- HTTPS only in production — Why: OAuth redirect URIs must be secure

## Out of Scope
- MFA (Phase 2)
- Email/password fallback (Phase 3)

## Architecture Notes
(none)

## Dependencies
- **Internal**: (none — this IS the auth foundation)
- **External**: Google Cloud console OAuth app, GitHub OAuth app

## Verification
- [ ] User clicks "Sign in with Google", is redirected, returns with session
- [ ] Session token decodes correctly
