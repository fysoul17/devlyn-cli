# Habit Tracker Roadmap

> **North Star**: A personal, single-user habit tracker that makes logging "I did it today" a two-second action and shows an honest streak.

## Phase 1: Core Loop (Target: no deadline — ship when ready)
Delivers the entire stated product: add habits, log today, see streak, browse history. After Phase 1, the app fully solves the problem; there is no Phase 2 in the roadmap today.

| # | Feature | Status | Priority | Complexity | Spec |
|---|---------|--------|----------|-----------|------|
| 1.1 | Habit tracker core (add, log today, streak) | Planned | High | Medium | [spec](roadmap/phase-1/1.1-habit-tracker-core.md) |
| 1.2 | History view | Planned | High | Low | [spec](roadmap/phase-1/1.2-history-view.md) |

## Backlog
| Feature | Reason Deferred | Revisit |
|---------|----------------|---------|
| Reminders / notifications | Out of stated problem; adds permissions and service workers | Only if the user asks |
| Cross-device sync | Requires backend; explicit anti-goal | Only if local-first breaks down |
| Export / import data | Not requested; localStorage is the single source of truth | If the user asks for portability |
| Categories / tags / colors | Polish without core-loop value | After core loop has been used daily for a month |

## Decisions
| # | Decision | Date | Record |
|---|----------|------|--------|
| 1 | Local dates, not timestamps, as the unit of truth | 2026-04-14 | [record](roadmap/decisions/001-local-date-keys.md) |
| 2 | Client-rendered app with `'use client'` at the page boundary | 2026-04-14 | [record](roadmap/decisions/002-client-rendered-pages.md) |
