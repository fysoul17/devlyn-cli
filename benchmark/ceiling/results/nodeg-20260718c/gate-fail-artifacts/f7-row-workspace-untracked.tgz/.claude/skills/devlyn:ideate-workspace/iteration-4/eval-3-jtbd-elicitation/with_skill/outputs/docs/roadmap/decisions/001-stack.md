---
id: 001
title: "Stack: Next.js App Router on Vercel, Neon Postgres, Clerk"
date: 2026-04-22
status: accepted
---

# 001 Stack: Next.js App Router on Vercel, Neon Postgres, Clerk

## Context
Greenfield web app for an ~8-person sales team. Need auth, a relational data store, and a web frontend on a platform that is cheap to run at this scale. The user specified Next.js on Vercel, Postgres on Neon, and Clerk as defaults.

## Decision
- **Framework**: Next.js App Router (not Pages Router). All data pages render as Server Components; client components are reserved for interactive islands (log-touch form, edit dialog).
- **Hosting**: Vercel (single project, preview deploys on PRs, production on main branch).
- **Database**: Neon Postgres. Connection via the serverless driver (`@neondatabase/serverless`) to avoid connection pool exhaustion on Vercel Functions.
- **Auth**: Clerk. Clerk user ids (TEXT) are stored directly as `prospects.owner_id`; no separate users table in v1.

## Alternatives Considered

### Supabase (DB + auth bundled)
- Pros: single vendor, built-in RLS for ownership enforcement.
- Cons: user explicitly specified Clerk + Neon separately.
- Why rejected: user's stated preference is ground truth.

### Pages Router instead of App Router
- Pros: more mature ecosystem, simpler mental model.
- Cons: no Server Components → every data fetch ships through `getServerSideProps` or client fetches, more client JS, more round trips.
- Why rejected: project convention (CLAUDE.md) prefers building server components first; App Router is the stated Next.js default in 2026.

### Prisma ORM vs raw SQL via Neon serverless driver
- Deferred decision, not blocking for Phase 1. Leaning toward raw SQL + a tiny query helper for v1 simplicity, but Prisma is acceptable if the team prefers it. Revisit if schema grows beyond ~5 tables.

## Consequences
- Deploys are push-to-main simple; preview URLs per PR.
- No user table to maintain — saves a join and a sync job, but means every query that displays a user name has to resolve via Clerk (batched backend call).
- Neon's serverless driver is the right fit; the classic `pg` driver with a long-lived pool will exhaust connections under Vercel Functions and must not be used.
- If the team later wants DB row-level security based on Clerk identity, we'll need to pass the user id into the DB connection context (deferred).
