# Habit Tracker Roadmap

> **North Star**: A frictionless personal habit tracker where logging "I did it today" takes one tap and instantly shows the streak that keeps me going.

## Phase 1: Core Loop (Target: no deadline — ship when ready)
Deliver the exact three things the user asked for: log a habit for today, see the current streak, see history. Everything else is deferred.

| # | Feature | Status | Priority | Complexity | Spec |
|---|---------|--------|----------|-----------|------|
| 1.1 | Project Scaffold (Next.js + Tailwind + shadcn/ui) | Planned | High | Low | [spec](roadmap/phase-1/1.1-project-scaffold.md) |
| 1.2 | Habit Data Model & localStorage Store | Planned | High | Low | [spec](roadmap/phase-1/1.2-habit-store.md) |
| 1.3 | Log Today Button | Planned | High | Low | [spec](roadmap/phase-1/1.3-log-today.md) |
| 1.4 | Current Streak Display | Planned | High | Low | [spec](roadmap/phase-1/1.4-streak-display.md) |
| 1.5 | History View | Planned | High | Medium | [spec](roadmap/phase-1/1.5-history-view.md) |
| 1.6 | Add / Rename / Delete Habits | Planned | Medium | Low | [spec](roadmap/phase-1/1.6-manage-habits.md) |
| 1.7 | Deploy to Vercel | Planned | Medium | Low | [spec](roadmap/phase-1/1.7-deploy-vercel.md) |

## Backlog
| Feature | Reason Deferred | Revisit |
|---------|----------------|---------|
| Cloud sync across devices | Local-first is the explicit Phase 1 constraint | When user asks for multi-device |
| Export / import JSON backup | Not requested; localStorage is fragile but single-device | After 1 month of real use |
| Reminders / notifications | Not requested; adds permissions and infra | Only if user reports missed days |
| Analytics, charts, heatmap | Out of stated scope; history list is enough | Only if user asks |
| Habit categories / tags | Out of stated scope | Only if user asks |

## Decisions
| # | Decision | Date | Record |
|---|----------|------|--------|
| 1 | Local-first storage via localStorage | 2026-04-14 | [record](roadmap/decisions/001-localstorage-first.md) |
| 2 | Client components only where needed; server-first rendering | 2026-04-14 | [record](roadmap/decisions/002-server-first-rendering.md) |
| 3 | Day boundary uses user's local timezone | 2026-04-14 | [record](roadmap/decisions/003-local-timezone-day-boundary.md) |
