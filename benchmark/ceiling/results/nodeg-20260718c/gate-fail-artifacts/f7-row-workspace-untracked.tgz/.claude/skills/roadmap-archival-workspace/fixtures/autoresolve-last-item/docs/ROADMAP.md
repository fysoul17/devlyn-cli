# Coffeelog Roadmap

> **North Star**: Track your home coffee brews and dial in better cups.

## Phase 1: MVP Logging (Target: 2026-Q1)
<!-- Capture each brew — dose, grind, time, rating. -->

| # | Feature | Status | Priority | Complexity | Spec |
|---|---------|--------|----------|-----------|------|
| 1.1 | Brew log form | Done | High | Low | [spec](roadmap/phase-1/1.1-brew-form.md) |
| 1.2 | Brew history list | Done | High | Low | [spec](roadmap/phase-1/1.2-history.md) |
| 1.3 | Rating & notes | In Progress | High | Medium | [spec](roadmap/phase-1/1.3-rating.md) |

## Phase 2: Dial-in (Target: 2026-Q2)

| # | Feature | Status | Priority | Complexity | Spec |
|---|---------|--------|----------|-----------|------|
| 2.1 | Recipe recommendations | Planned | High | High | [spec](roadmap/phase-2/2.1-recipes.md) |
