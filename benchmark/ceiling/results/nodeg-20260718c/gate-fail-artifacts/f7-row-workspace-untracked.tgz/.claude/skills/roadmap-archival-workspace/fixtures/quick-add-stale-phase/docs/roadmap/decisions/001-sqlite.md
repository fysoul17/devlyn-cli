# Decision 001: SQLite for local data
Status: accepted
Date: 2026-01-10
