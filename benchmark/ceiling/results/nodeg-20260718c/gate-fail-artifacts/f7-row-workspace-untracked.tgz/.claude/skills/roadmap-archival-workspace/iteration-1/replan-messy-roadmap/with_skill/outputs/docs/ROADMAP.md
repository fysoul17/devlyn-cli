# Ledger Roadmap

> **North Star**: Personal finance tracker with zero friction data entry.

## Phase 2: Reporting (Target: 2026-Q2)

| # | Feature | Status | Priority | Complexity | Spec |
|---|---------|--------|----------|-----------|------|
| 2.1 | Monthly summary | Done | High | Low | [spec](roadmap/phase-2/2.1-monthly.md) |
| 2.2 | Category breakdown chart | In Progress | High | Medium | [spec](roadmap/phase-2/2.2-categories.md) |
| 2.3 | Year-over-year compare | Planned | Medium | Medium | [spec](roadmap/phase-2/2.3-yoy.md) |

## Phase 3: Envelope Budgets (Target: 2026-Q3)
<!-- Replanned 2026-04-15: switched from per-category limits to envelope budgets for a simpler mental model. -->

| # | Feature | Status | Priority | Complexity | Spec |
|---|---------|--------|----------|-----------|------|
| 3.1 | Envelope setup & allocation | Planned | High | Medium | [spec](roadmap/phase-3/3.1-envelope-setup.md) |
| 3.2 | Envelope depletion alerts | Planned | Medium | Low | [spec](roadmap/phase-3/3.2-envelope-alerts.md) |

## Completed
<details>
<summary>Phase 1: Accounts & Transactions (completed 2026-04-15, 3 items)</summary>

| # | Feature | Completed |
|---|---------|-----------|
| 1.1 | Account management | 2026-04-15 |
| 1.2 | Transaction entry | 2026-04-15 |
| 1.3 | CSV import | 2026-04-15 |
</details>
