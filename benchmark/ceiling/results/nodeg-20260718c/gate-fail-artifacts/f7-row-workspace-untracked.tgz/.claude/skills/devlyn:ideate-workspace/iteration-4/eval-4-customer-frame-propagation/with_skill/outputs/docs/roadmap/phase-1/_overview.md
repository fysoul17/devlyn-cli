# Phase 1: Local-Only MVP

## Goal
Ship the complete single-device expense-tracking loop for a solo freelancer: log an expense, review the month, correct mistakes, and export a CSV at tax time. All data lives in browser localStorage. No auth. No server.

## Why this phase comes first
The user explicitly asked for personal solo use with localStorage initially. Shipping a usable local-only version validates the capture flow (the 10-second North Star) before investing in sync infrastructure. If the local version is not used in practice, cloud sync would not rescue it.

## Success criteria for the phase
- A freelancer can open the app and log an expense in under 10 seconds.
- The running monthly total and per-category breakdown are always one tap away.
- Mistakes can be corrected without deleting and re-adding.
- A CSV of all expenses (optionally filtered by year) downloads with one click.

## What Phase 1 does NOT include
- No user accounts, sign-in, or cloud storage — deferred to Phase 2.1.
- No receipt image upload — deferred to Phase 2.3.
- No filter/search beyond the default month view — deferred to Phase 2.2.
- No recurring expenses — deferred to Phase 2.4.

## Technical ground rules (Phase 1)
- Next.js App Router. Client-rendered pages where needed for localStorage access. See decision 003.
- All persistence via a single `ExpenseStore` module that wraps localStorage. This isolates the storage layer so Phase 2.1 can swap in Supabase without changing feature code.
- No external API calls, no environment secrets required to run the app locally.
