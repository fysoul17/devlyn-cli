# Freelancer Expense Tracker Roadmap

> **North Star**: A freelancer can capture any business expense in under 10 seconds and, at tax time, export a clean CSV of the year's spending grouped by category.

## Phase 1: Local-Only MVP (Target: initial release)
Deliver the full single-device expense-tracking loop — log, review, correct, export — with data in localStorage. Every item ships user-visible value.

| # | Feature | Status | Priority | Complexity | Spec |
|---|---------|--------|----------|-----------|------|
| 1.1 | Log, list, and delete expenses | Planned | High | Medium | [spec](roadmap/phase-1/1.1-log-list-delete-expenses.md) |
| 1.2 | Monthly summary with category breakdown | Planned | High | Low | [spec](roadmap/phase-1/1.2-monthly-summary.md) |
| 1.3 | Edit an expense entry | Planned | Medium | Low | [spec](roadmap/phase-1/1.3-edit-expense.md) |
| 1.4 | Export expenses to CSV | Planned | High | Low | [spec](roadmap/phase-1/1.4-csv-export.md) |

## Phase 2: Sync & Quality-of-Life (Target: after Phase 1 validated in real use)
Move data off a single device and add the details that come up after real use.

| # | Feature | Status | Priority | Complexity | Spec |
|---|---------|--------|----------|-----------|------|
| 2.1 | Supabase-backed sync (opt-in) | Planned | High | High | (spec TBD) |
| 2.2 | Filter & search expenses | Planned | Medium | Medium | (spec TBD) |
| 2.3 | Receipt image attachment | Planned | Medium | Medium | (spec TBD) |
| 2.4 | Recurring expenses | Planned | Low | Medium | (spec TBD) |

## Backlog
| Feature | Reason Deferred | Revisit |
|---------|----------------|---------|
| Bank account sync (Plaid) | Heavy compliance + server setup; manual entry covers solo scale | After Phase 2.1 cloud sync is live |
| Multi-currency support | User is a solo founder, single-currency assumed until stated otherwise | If user travels for work regularly |
| Charts / visualizations beyond category breakdown | Not required for tax-time outcome; risk of luxury-item scope creep | If summary view proves insufficient in real use |
| Mileage tracking | Common freelancer need but distinct workflow; don't pollute expense form | Phase 3 candidate |
| Tag support | Categories already cover grouping; tags are second-layer polish | After category UX proven |

## Decisions
| # | Decision | Date | Record |
|---|----------|------|--------|
| 1 | localStorage for Phase 1, Supabase deferred | 2026-04-22 | [record](roadmap/decisions/001-localstorage-first.md) |
| 2 | Default expense categories shipped, user-editable later | 2026-04-22 | [record](roadmap/decisions/002-default-categories.md) |
| 3 | Next.js App Router, client-rendered for Phase 1 | 2026-04-22 | [record](roadmap/decisions/003-nextjs-app-router-client.md) |
