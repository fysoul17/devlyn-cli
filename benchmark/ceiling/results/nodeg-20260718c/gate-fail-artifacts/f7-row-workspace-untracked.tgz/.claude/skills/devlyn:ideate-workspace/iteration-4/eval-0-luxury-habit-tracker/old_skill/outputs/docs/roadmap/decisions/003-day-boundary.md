---
id: 003
title: "Local device date as the streak day boundary"
date: 2026-04-22
status: accepted
---

# 003 Local device date as the streak day boundary

## Context
A "streak" requires a definition of "today" — when does one day end and the next begin? This has real UX consequences: if I log at 11:59pm local time and the app uses UTC, my streak might jump ahead a day or stall unexpectedly. If I travel across timezones, the boundary also shifts. The user did not explicitly state a preference, so this is an agent-raised decision that needs a defensible default.

## Decision
Use the **local device date** (the calendar date as the device reports it at the moment of the log tap) to compute the `dayKey`. Format: `YYYY-MM-DD`. A habit is "done today" if there is at least one log entry whose `dayKey` equals today's local `dayKey`. Streak = consecutive `dayKey` values counting backward from today.

Helper:
```ts
function dayKey(d: Date = new Date()): string {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
}
```

## Alternatives Considered

### UTC day boundary
- Pros: timezone-independent, consistent across devices
- Cons: for users east of UTC, "today" ends before midnight local; for users west, "today" ends after midnight local. Feels wrong.
- Why rejected: habit tracking is about *personal* daily rhythm, not a global clock. Local day matches user mental model.

### User-configurable "day starts at" (e.g., 4am local)
- Pros: nice-to-have for night owls — logging something at 2am counts as "yesterday"
- Cons: adds a settings UI, adds a config state, complicates streak math, and the user did not ask for it
- Why rejected: premature feature. If I personally notice the 2am problem after using the app, add it then. For now: midnight local.

### Store full ISO timestamp, compute dayKey lazily on read
- Pros: lossless, more flexible for future analytics
- Cons: every streak computation pays a Date-parsing cost; more surface area for timezone math bugs
- Why rejected: not worth it for the current feature set. If analytics arrive later, store both.

## Consequences
- Traveling across timezones can cause a "missed" day or a duplicate day edge case (e.g., logging in Seoul then re-opening the app in SF on the same flight). Accepted for a personal tool; documented so the future me knows the tradeoff.
- `dayKey` is stored as a plain string in each log entry — trivial to compare, trivial to index on.
- If cloud sync arrives later and devices disagree on "today", the merge strategy will need explicit design. Out of scope for now.
