# Freelancer Expense Tracker Roadmap

> **North Star**: A solo freelancer can log a business expense in under 10 seconds and pull a tax-ready summary of the year in one click.

## Phase 1: Core Tracking (Target: MVP, 1-2 weeks)
Ship the end-to-end expense tracking loop — log, see, export — on a single device with localStorage. Every item in this phase delivers user-visible value on its own; a freelancer could stop after item 1.1 and still have a usable tool.

| # | Feature | Status | Priority | Complexity | Spec |
|---|---------|--------|----------|-----------|------|
| 1.1 | Log expense and see running totals | Planned | High | Medium | [spec](roadmap/phase-1/1.1-log-and-totals.md) |
| 1.2 | Export year-to-date CSV | Planned | High | Low | [spec](roadmap/phase-1/1.2-csv-export.md) |

## Backlog
| Feature | Reason Deferred | Revisit |
|---------|----------------|---------|
| Supabase cloud sync | Requires usage data to justify schema; localStorage migration path is designed in from day one | After 1 month of daily use or when multi-device becomes a real pain |
| Filters and search (by date range, category) | Not needed until there are enough expenses for the list to feel long | After ~100 expenses logged |
| Monthly / category charts | Nice-to-have visualization; CSV + spreadsheet covers analysis for v1 | After CSV export is in regular use |
| Receipt photo attach | Non-trivial storage + a11y scope; text entry meets the 10-second goal | Only if the founder actively misses it |
| Mileage tracker | Separate data shape; only relevant if the founder drives for work | On demand |
| PWA / offline install | Next.js + localStorage already works offline after first load; installable shell is polish | After Phase 1 is used for 2+ weeks |

## Decisions
| # | Decision | Date | Record |
|---|----------|------|--------|
| 1 | Use localStorage for v1 persistence with a migration-aware schema | 2026-04-22 | [record](roadmap/decisions/001-localstorage-first.md) |
| 2 | Build on Next.js App Router with Server Components as the default | 2026-04-22 | [record](roadmap/decisions/002-nextjs-app-router.md) |
| 3 | Single-page layout with inline entry and list (no routing per-view in v1) | 2026-04-22 | [record](roadmap/decisions/003-single-page-layout.md) |
