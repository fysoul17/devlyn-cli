#!/usr/bin/env python3
"""Programmatic grader for roadmap-archival evals.

Usage: python grader.py <run_dir>

Expects <run_dir>/outputs/docs/ROADMAP.md and related spec files.
Determines which eval by reading the sibling eval_metadata.json.
Writes <run_dir>/grading.json.
"""
import json
import re
import sys
from pathlib import Path


def parse_frontmatter(text):
    m = re.match(r"^---\n(.*?)\n---", text, re.DOTALL)
    if not m:
        return {}
    fm = {}
    for line in m.group(1).splitlines():
        if ":" in line:
            k, _, v = line.partition(":")
            fm[k.strip()] = v.strip().strip('"')
    return fm


def split_active_and_completed(roadmap_text):
    """Return (active_text, completed_text). Completed is empty if no Completed section."""
    m = re.search(r"^## Completed\b", roadmap_text, re.MULTILINE)
    if not m:
        return roadmap_text, ""
    return roadmap_text[: m.start()], roadmap_text[m.start() :]


def row_status(roadmap_text, item_id):
    """Return the Status column value for the row whose # column is item_id, or None."""
    # row format: | 2.2 | ... | Status | ... |
    pattern = rf"^\|\s*{re.escape(item_id)}\s*\|[^|]*\|\s*([^|]+?)\s*\|"
    m = re.search(pattern, roadmap_text, re.MULTILINE)
    if not m:
        return None
    return m.group(1).strip()


def grade(run_dir: Path):
    meta = json.loads((run_dir / "eval_metadata.json").read_text())
    eval_name = meta["eval_name"]
    docs = run_dir / "outputs" / "docs"
    roadmap_path = docs / "ROADMAP.md"

    results = []

    def add(aid, passed, evidence):
        results.append({"id": aid, "text": _text_for(meta, aid), "passed": bool(passed), "evidence": evidence})

    if not roadmap_path.exists():
        # Every assertion fails
        for a in meta["assertions"]:
            results.append({"id": a["id"], "text": a["text"], "passed": False, "evidence": f"ROADMAP.md not found at {roadmap_path}"})
        _write(run_dir, results)
        return

    roadmap_text = roadmap_path.read_text()
    active, completed = split_active_and_completed(roadmap_text)

    # Per-eval checks
    if eval_name == "quick-add-stale-phase":
        add("completed-block-exists", bool(completed), f"completed section length={len(completed)}")
        add("phase1-in-completed", "Phase 1" in completed, f"'Phase 1' in completed: {'Phase 1' in completed}")
        add("phase1-removed-from-active", "## Phase 1" not in active, "active section heading search")
        recap_re = re.compile(r"recap|weekly", re.IGNORECASE)
        add("new-item-added", bool(recap_re.search(active)), "regex recap|weekly in active section")
        # Look for any new spec file created matching recap/weekly
        new_spec = False
        for f in (docs / "roadmap").rglob("*.md"):
            if recap_re.search(f.name):
                new_spec = True
                break
        add("new-spec-file-exists", new_spec, f"scan docs/roadmap for recap|weekly filename: {new_spec}")
        orig_exist = all((docs / "roadmap" / "phase-1" / n).exists() for n in ("1.1-user-auth.md", "1.2-habit-model.md", "1.3-onboarding.md"))
        add("original-phase1-specs-preserved", orig_exist, f"phase-1 specs preserved: {orig_exist}")
        line_count = len(roadmap_text.splitlines())
        add("roadmap-under-150-lines", line_count < 150, f"line_count={line_count}")

    elif eval_name == "autoresolve-mid-phase":
        spec22 = docs / "roadmap" / "phase-2" / "2.2-shortcuts.md"
        fm = parse_frontmatter(spec22.read_text()) if spec22.exists() else {}
        add("spec-22-status-done", fm.get("status") == "done", f"status={fm.get('status')!r}")
        add("spec-22-completed-field", "completed" in fm, f"completed field present: {'completed' in fm}")
        add("roadmap-row-22-done", (row_status(roadmap_text, "2.2") or "").lower() == "done", f"row 2.2 status={row_status(roadmap_text, '2.2')!r}")
        add("no-premature-archive", not completed, f"completed section empty: {not completed}")
        others_ok = True
        detail = []
        for id_, slug, expected in [("2.1", "2.1-editor.md", "done"), ("2.3", "2.3-md-export.md", "planned"), ("2.4", "2.4-search.md", "planned")]:
            p = docs / "roadmap" / "phase-2" / slug
            if not p.exists():
                others_ok = False
                detail.append(f"{slug} missing")
                continue
            got = parse_frontmatter(p.read_text()).get("status")
            if got != expected:
                others_ok = False
                detail.append(f"{slug}: {got!r} (expected {expected!r})")
        add("other-specs-untouched", others_ok, "; ".join(detail) if detail else "all 3 specs unchanged")
        add("roadmap-phase2-intact", "## Phase 2" in active, f"Phase 2 heading in active: {'## Phase 2' in active}")

    elif eval_name == "autoresolve-last-item":
        spec13 = docs / "roadmap" / "phase-1" / "1.3-rating.md"
        fm = parse_frontmatter(spec13.read_text()) if spec13.exists() else {}
        add("spec-13-status-done", fm.get("status") == "done", f"status={fm.get('status')!r}")
        add("completed-block-exists", bool(completed), f"completed length={len(completed)}")
        add("phase1-in-completed", "Phase 1" in completed, f"'Phase 1' in completed: {'Phase 1' in completed}")
        add("phase1-removed-from-active", "## Phase 1" not in active, "active section heading search")
        add("phase2-intact", "## Phase 2" in active and "Recipe recommendations" in active, "Phase 2 heading + row intact")
        files_exist = all((docs / "roadmap" / "phase-1" / n).exists() for n in ("1.1-brew-form.md", "1.2-history.md", "1.3-rating.md"))
        add("spec-files-preserved", files_exist, f"all 3 phase-1 specs exist: {files_exist}")

    elif eval_name == "replan-messy-roadmap":
        add("completed-block-exists", bool(completed), f"completed length={len(completed)}")
        add("phase1-in-completed", "Phase 1" in completed, f"'Phase 1' in completed: {'Phase 1' in completed}")
        add("phase1-removed-from-active", "## Phase 1" not in active, "active heading search")
        p2_ok = all(row_status(active, r) for r in ["2.1", "2.2", "2.3"])
        p2_detail = {r: row_status(active, r) for r in ["2.1", "2.2", "2.3"]}
        add("phase2-preserved", p2_ok and p2_detail["2.1"].lower() == "done" and "progress" in p2_detail["2.2"].lower() and p2_detail["2.3"].lower() == "planned", f"phase2 rows={p2_detail}")
        files_exist = all((docs / "roadmap" / "phase-1" / n).exists() for n in ("1.1-accounts.md", "1.2-txn-entry.md", "1.3-csv-import.md"))
        add("phase1-specs-preserved", files_exist, f"all 3 phase-1 specs exist: {files_exist}")
    else:
        for a in meta["assertions"]:
            results.append({"id": a["id"], "text": a["text"], "passed": False, "evidence": f"unknown eval_name: {eval_name}"})

    _write(run_dir, results)


def _text_for(meta, aid):
    for a in meta["assertions"]:
        if a["id"] == aid:
            return a["text"]
    return aid


def _write(run_dir, results):
    passed = sum(1 for r in results if r["passed"])
    out = {"passed_count": passed, "total": len(results), "expectations": results}
    (run_dir / "grading.json").write_text(json.dumps(out, indent=2))
    print(f"{run_dir.name}: {passed}/{len(results)} passed")


if __name__ == "__main__":
    grade(Path(sys.argv[1]))
