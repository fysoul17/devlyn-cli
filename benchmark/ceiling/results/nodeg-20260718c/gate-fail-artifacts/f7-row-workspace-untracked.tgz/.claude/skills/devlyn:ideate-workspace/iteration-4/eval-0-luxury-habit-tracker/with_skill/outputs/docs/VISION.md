# Habit Tracker Vision

## North Star
A solo user logs "did it today" in one tap, sees their streak, and can look back at their history — nothing else gets in the way.

## Principles
1. **One-tap logging** — Marking a habit as done today should take a single tap from the home screen. Tradeoff: we accept that bulk-editing or backdating is a secondary flow, not the primary one.
2. **Local-first by default** — Data lives in the browser (localStorage). No network call required to log a habit. Tradeoff: data is tied to a single browser profile; cross-device sync is not available (anti-goal for v1).
3. **Show momentum, not analytics** — The core reward loop is the streak number and the recent-history glance. Tradeoff: we do not build charts, insights, or trend analysis.
4. **Ship a usable slice early** — Phase 1 delivers a deployed, working tracker. No "infrastructure-only" phases. Tradeoff: the UI is deliberately minimal in v1; polish comes after it is used.
5. **No accounts, no friction** — Opening the URL is the onboarding. Tradeoff: we cannot personalize across devices, and losing the browser profile means losing data.

## Target Users
### Primary
**Solo self-tracker (the author)** — Wants to build 2-5 daily habits and keep the momentum visible. Pain: existing habit apps require accounts, sync, subscriptions, or too much setup just to mark "did it today". Need: a deployed URL they can bookmark on phone and laptop, tap once per habit, see streak, done.

### Not For
- Teams or multi-user households — Why: no accounts, no sharing; each browser profile is its own silo. [defaulted]
- Cross-device users who need same-data on phone and laptop — Why: localStorage is scoped to one browser profile; sync is explicitly deferred. [defaulted]
- Advanced trackers who want mood, notes, quantitative logging, charts, insights — Why: out of scope for v1; the app is a binary "did it / didn't" tracker.

## Anti-Goals
- **No user accounts, no auth, no backend database** — Why: the user explicitly stated no accounts, no other users. localStorage only in v1. [defaulted]
- **No cross-device sync** — Why: a direct consequence of local-first default. Surfacing this as an explicit anti-goal so we don't accidentally ship export/import as a sync workaround.
- **No notifications or reminders** — Why: not requested; adds scope (service workers, push permissions) for a solo tool the user will open manually.
- **No social / sharing / leaderboards** — Why: solo project, no other users.
- **No theming, animations, or customization beyond shadcn defaults** — Why: luxury items that do not move the core job forward; revisit only after the core flow is in daily use.
- **No quantitative tracking (e.g. "30 minutes of reading")** — Why: v1 is binary did-it-today only; quantitative logging is a future item if the binary version isn't enough.

## Success Metrics
- **Time-to-first-log**: Under 30 seconds from opening the deployed URL for the first time (define one habit, mark it done).
- **Daily interaction cost**: Under 10 seconds to log all habits for the day from a bookmarked URL.
- **Deployed and in daily use** for at least 14 consecutive days by the author before any Phase 2 work is considered.
- **Zero crashes / data loss** for a localStorage profile holding 90 days of entries across 5 habits.
