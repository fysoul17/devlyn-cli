# Dashboard Improvement Vision

> This VISION.md was generated from near-zero framing. Every item below tagged [ASSUMED] is a guess, not a confirmed fact. See `docs/clarifying-questions.md` for the questions that need answers before this vision can be trusted.

## North Star
[ASSUMED] Make the dashboard a place where the primary user understands the current state of the system at a glance and takes the next action without friction.

> Why [ASSUMED]: the user said "improve our dashboard" with no statement of audience, pain, or desired outcome. This north star is a placeholder shaped as a generic dashboard outcome; the actual north star must come from answers to Q1-Q6 and Q10-Q11 in `clarifying-questions.md`.

## Principles
1. [ASSUMED] **Clarity over completeness** — show the one number the user came to see before showing everything else. Tradeoff: some data gets hidden behind a drill-in; we accept this in exchange for first-glance comprehension.
2. [ASSUMED] **Fix before decorate** — if the dashboard has concrete bugs or correctness issues, those are resolved before any visual polish. Tradeoff: slower visible redesign; we accept this in exchange for trust in the numbers.

> Why [ASSUMED]: the user never stated principles or tradeoffs. Both are conventional dashboard-design principles inserted as starting points; neither is grounded in this project's specific context.

## Target Users
### Primary
[ASSUMED] **Unknown** — we do not know who uses this dashboard. See Q1-Q2 in clarifying-questions.md.

### Not For
[ASSUMED] **Unknown** — cannot be listed without knowing the primary audience.

## Anti-Goals
- [ASSUMED] **No full redesign in the "next phase"** — Why: without confirmed framing, a redesign risks solving the wrong problem. Small, testable improvements first.
- [ASSUMED] **No new data sources** — Why: adding data is cheaper than understanding what's already wrong with the data the dashboard already shows.

> Why [ASSUMED]: these are defensive defaults based on the rubric (NO OVERENGINEERING, NO GUESSWORK), not on user-stated intent. The user may in fact want a full redesign.

## Success Metrics
[ASSUMED] **None defined yet** — cannot be specified without knowing what "improve" means to the user. See Q4, Q5, Q10 in clarifying-questions.md. A real success metric for this phase will be one of: reduced time-to-first-insight, reduced support tickets about the dashboard, increased task completion, or a specific NPS/CSAT delta. The user must pick.

## Status
**This vision is a placeholder.** It exists so auto-resolve has something to read, not because it has been validated. The only meaningful action right now is to answer the questions in `clarifying-questions.md` and regenerate this file. Do not treat any [ASSUMED] item as a commitment.
