# Clarifying Questions (unanswered)

The user said exactly: "I want to improve our dashboard. Plan the next phase."

Per role-play rule, these questions were NOT answered by the user. They are recorded here and the plan below stays minimal until they are resolved.

## FRAME-phase questions

1. **What dashboard?** Internal ops dashboard, customer-facing analytics, admin panel, observability, financial, something else?
2. **What product / project does this dashboard belong to?** Name, domain, user base.
3. **Who are the users of the dashboard?** Internal team, end customers, both?
4. **What specific problems are users hitting today?** Any complaints, support tickets, metrics trending wrong?
5. **What does "improve" mean to you right now?** Faster, clearer, more data, new features, redesign, fix bugs?
6. **What tech stack is the dashboard built on?** (Next.js, React, Vue, server-rendered, framework version?)
7. **Is there an existing VISION.md / ROADMAP.md?** If yes, what phase are we currently on and what is in it?
8. **What does "the next phase" mean?** Is there a phase N-1 already shipped? What was in it?
9. **Constraints**: timeline, team size, budget, things that can't change.
10. **Success criteria**: how will you know the next phase worked? (Outcome metric, not output.)
11. **Anti-goals**: anything you explicitly do NOT want in this phase.
12. **Mode detection**: is this Greenfield (no docs), Expand (add to existing roadmap), or Replan (reprioritize existing)?

## EXPLORE-phase questions (blocked until FRAME answered)

13. Any reference dashboards you admire or want to pattern-match to?
14. Is there telemetry on current dashboard usage (most-viewed panels, drop-offs, load times)?
15. Are there any known technical debt items blocking improvement?

## CONVERGE-phase questions (blocked until EXPLORE answered)

16. Value vs feasibility preference — ship one big thing or several small things this phase?
17. Risk tolerance for larger refactors vs incremental polish?

---

**Status**: NONE of these questions have been answered. The plan in `ROADMAP.md` / `roadmap/phase-1/` is therefore intentionally empty of concrete items. It contains exactly one [CONFIRMED] line and a placeholder phase that exists only to be filled in after a real FRAME conversation.
