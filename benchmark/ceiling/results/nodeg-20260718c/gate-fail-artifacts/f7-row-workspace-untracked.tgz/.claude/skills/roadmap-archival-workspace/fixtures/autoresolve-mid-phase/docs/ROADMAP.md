# Notely Roadmap

> **North Star**: A fast, keyboard-first note-taking app.

## Phase 2: Core Editor (Target: 2026-Q2)
<!-- The editing loop — the most used surface. -->

| # | Feature | Status | Priority | Complexity | Spec |
|---|---------|--------|----------|-----------|------|
| 2.1 | Rich text editor | Done | High | High | [spec](roadmap/phase-2/2.1-editor.md) |
| 2.2 | Keyboard shortcuts | In Progress | High | Medium | [spec](roadmap/phase-2/2.2-shortcuts.md) |
| 2.3 | Markdown export | Planned | Medium | Low | [spec](roadmap/phase-2/2.3-md-export.md) |
| 2.4 | Search across notes | Planned | High | Medium | [spec](roadmap/phase-2/2.4-search.md) |
