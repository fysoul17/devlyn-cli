# Habit Tracker Roadmap

> **North Star**: A personal, local-first habit tracker where I can log a habit today, see my streak, and browse my history — nothing more.

## Phase 1: MVP — ship the whole thing (Target: 1 short sitting)
Phase 1 is the entire product. Two user-visible items, each shippable on its own. Scaffolding, localStorage wiring, and Vercel deploy are bundled into the item that needs them — they are not standalone items.

| #   | Feature                       | Status  | Priority | Complexity | Spec |
|-----|-------------------------------|---------|----------|-----------|------|
| 1.1 | Log a habit today and see streak | Planned | High     | Low       | [spec](roadmap/phase-1/1.1-log-and-streak.md) |
| 1.2 | History view                  | Planned | High     | Low       | [spec](roadmap/phase-1/1.2-history-view.md) |

## Backlog
| Feature | Reason Deferred | Revisit |
|---------|----------------|---------|
| Multiple habits management (rename, reorder, archive) | User asked for "a habit" singular; only minimal add/name is in Phase 1. | If/when the user says they want to track more than one habit with real management. |
| Edit or delete a past log entry | Not asked for; would need confirmation UX. | On first real use if user mis-logs a day. |
| Cross-device sync / backup export | Explicitly local-first; contradicts stated constraint. | Only if device-loss becomes a felt pain. |

## Decisions
| # | Decision | Date | Record |
|---|----------|------|--------|
| 1 | Local-first with localStorage (no backend) | 2026-04-14 | [record](roadmap/decisions/001-local-first-localstorage.md) |
| 2 | Bundle scaffold/store/deploy into feature items | 2026-04-14 | [record](roadmap/decisions/002-no-infrastructure-items.md) |
