# Assertion Draft — iteration-1

Graders will score with_skill and old_skill runs independently on the same assertions. Each assertion is binary (passed/failed) plus a one-line evidence citation. Grading target: transcript.md + outputs/docs/**.

## Eval 1 — luxury-habit-tracker

Tests whether the CHALLENGE phase strips luxury items from Phase 1.

| # | Assertion | How to verify |
|---|-----------|---------------|
| L1 | transcript records a CHALLENGE/pressure-test phase running at least once | grep transcript.md for "CHALLENGE" or "pressure test" phase marker |
| L2 | Phase 1 contains items for all three user-stated capabilities (log habit, streak, history) | read ROADMAP.md / phase-1/_overview.md; each capability has a spec |
| L3 | Phase 1 contains NO luxury items (theming, animations, settings UI, charts, onboarding tour, export, account system) | enumerate phase-1 items; fail if any match the luxury list |
| L4 | If CHALLENGE fired, transcript explicitly shows at least one item rejected/moved on a luxury/overengineering axis | transcript.md mentions moving an item to backlog because of rubric |
| L5 | Total Phase 1 item count ≤ 4 | count item spec files in phase-1/ |

## Eval 2 — workaround-draft-export

Tests whether CHALLENGE flags the user's own proposal as a roadmap workaround and proposes direct persistence.

| # | Assertion | How to verify |
|---|-----------|---------------|
| W1 | transcript records CHALLENGE phase running on the new item | grep transcript.md for CHALLENGE / rubric mention |
| W2 | The final plan contains a "direct draft persistence / autosave" item (not just JSON export) | grep output specs for autosave, persistence, DB-backed draft, not only "export JSON" |
| W3 | The JSON-export item is either (a) not the primary solution, (b) explicitly marked as fallback, or (c) rejected in favor of autosave | read new item spec + transcript |
| W4 | transcript explicitly uses the word "workaround" OR references NO WORKAROUND axis when discussing the user's original JSON-export idea | grep transcript.md |
| W5 | Item specs cite the root cause (drafts live only in React state) rather than paper over it | read final item spec Context section |

## Eval 3 — guesswork-vague-dashboard

Tests whether the skill refuses to invent context and CHALLENGE flags guesswork.

| # | Assertion | How to verify |
|---|-----------|---------------|
| G1 | clarifying-questions.md exists in outputs/docs/ | file exists |
| G2 | clarifying-questions.md contains ≥ 3 targeted questions (not generic "tell me more") | read file, count specific questions about domain/users/metrics |
| G3 | If any item specs were generated, every requirement is tagged [CONFIRMED] or [ASSUMED] | read each spec, verify all reqs labeled |
| G4 | Ratio of [ASSUMED] to total tags is > 0.8 (almost everything is an assumption) | count tags in all specs |
| G5 | transcript records CHALLENGE flagging the plan on the NO GUESSWORK axis | grep transcript.md for NO GUESSWORK / guesswork-heavy / unconfirmed assumption |
| G6 | The skill did NOT invent a domain (e.g., "e-commerce dashboard", "analytics dashboard") that the user never mentioned | grep output for domain-specific invented terms |

## Expected contrast new vs old

The new skill should pass L1/L3/L4/L5, W1/W3/W4, G1/G5/G6 — assertions that specifically test CHALLENGE behavior and the new rubric. The old skill is expected to fail L3 (luxury creep), W3/W4 (rubber-stamps the user's workaround), G4/G5 (proceeds with guesswork without flagging).

L2, W2, and G1–G3 should be comparable between old and new — they test behaviors the old skill already had.
