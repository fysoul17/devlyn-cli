# TaskFlow

A lightweight task management app for small teams.

## Features
- User authentication (signup, login, SSO)
- Task management (create, edit, delete)
- Real-time collaboration
- Team management

## Getting Started
npm install && npm run dev
