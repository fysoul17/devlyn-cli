# Phase 1 — MVP

## Goal
Ship the entire stated product: log a habit today, see streak, see history. Deployed to Vercel. Local-first.

## Context
Solo, greenfield Next.js (App Router) + Tailwind + shadcn/ui. All state in `localStorage`. No backend, no auth, no accounts. The user explicitly asked for exactly three capabilities — log today, streak, history — and explicitly rejected additions.

## Items
- **1.1 Log a habit today and see streak** — bundles initial scaffold, localStorage data layer, minimal "add a habit" precondition, the log-today action, and the streak display. Ships as a single deployable vertical slice to Vercel.
- **1.2 History view** — adds the history list/calendar on top of the data already written by 1.1.

## Sequencing rationale
1.1 comes first because it delivers the whole user journey minus history in one shippable increment. 1.2 is a pure read-view on top of the same data store and can ship independently right after.

## What Phase 1 does NOT include
- Multiple habits management (beyond naming one)
- Editing / deleting past log entries
- Reminders, notifications, analytics, charts
- Theming, onboarding, settings screens
- Any backend, account, or sync layer
