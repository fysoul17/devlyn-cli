# Cold Prospect Tracker Vision

## North Star
Every salesperson on the team can see, in under 30 seconds, which of their prospects are going cold — and do something about it before the opportunity is lost.

## Principles
1. **Cold-risk is the primary object** — The app is organized around "who is going cold?", not around a full CRM pipeline. Tradeoff: we accept not being a replacement for Salesforce or HubSpot; we serve one specific job well.
2. **One glance to value** — A salesperson should see their personal cold list the moment they log in, with no setup, filters, or configuration required. Tradeoff: we accept fewer power-user customization hooks in early phases.
3. **Capture beats completeness** — Logging a touchpoint must be faster than updating the spreadsheet (<10 seconds). If capture is slow, reps won't do it and the data rots. Tradeoff: we accept minimal per-touchpoint structure (date, channel, note) over rich activity modeling.
4. **Shared signal, private work** — The whole team can see which accounts are at risk, but each rep owns their own prospects. Tradeoff: no multi-owner handoff workflow in v1.
5. **Honest defaults, easy overrides** — Cold threshold defaults to 14 days of no contact, but reps can override per prospect. Tradeoff: we accept the default will be wrong for some prospects; we trust reps to adjust.

## Target Users
### Primary
**Individual salesperson on an ~8-person team** — Manages a personal list of 20–100 active prospects. Pain: prospects slip through the cracks because the shared spreadsheet is messy, out of date, and doesn't surface who hasn't been contacted in a while. Need: a daily view of "who's going cold" scoped to their own book, fast to update after a call or email.

### Secondary
**Sales manager** — Wants team-wide visibility into at-risk accounts without micromanaging. Need: an aggregate view showing which prospects across the team are cold, so they can coach or reassign before deals die.

### Not For
- **Enterprise sales teams (50+ reps)** — Why: they need pipeline stages, forecasting, territory management, and integrations we explicitly don't build.
- **Outbound prospecting teams doing pure cold outreach** — Why: the "going cold" signal assumes a prior warm contact; pure cold outreach tools need different primitives (sequences, cadences, reply rates).
- **Solo operators** — Why: the shared-visibility features add complexity that a team of one doesn't need.

## Anti-Goals
- **Full CRM features** (pipeline stages, forecasting, opportunity amounts, quota tracking) — Why: scope creep; these turn a focused tool into a mediocre CRM.
- **Email/calendar automation** (sending emails, booking meetings, sequences) — Why: adds OAuth, deliverability, and compliance complexity that distracts from the core job.
- **Mobile-first or native apps** — Why: v1 is a web app the team uses at their desk; mobile can come later if reps ask for it.
- **Custom reports and dashboards** — Why: the job is "nudge cold prospects today", not "analyze historical win rates".
- **Data import wizards for arbitrary CRMs** — Why: CSV import is enough; supporting every CRM's export format is a rabbit hole.

## Success Metrics
- **Adoption**: 7 of 8 reps log at least one touchpoint per week within 2 weeks of launch.
- **Spreadsheet replacement**: Team stops updating the shared spreadsheet within 30 days.
- **Time-to-first-cold-list**: A new rep sees their cold list within 60 seconds of first login (after Clerk sign-up).
- **Capture speed**: Median time to log a touchpoint is under 10 seconds from cold-list view.
- **Signal usefulness**: Reps report (qualitatively) that the cold list surfaces prospects they would have otherwise forgotten.
