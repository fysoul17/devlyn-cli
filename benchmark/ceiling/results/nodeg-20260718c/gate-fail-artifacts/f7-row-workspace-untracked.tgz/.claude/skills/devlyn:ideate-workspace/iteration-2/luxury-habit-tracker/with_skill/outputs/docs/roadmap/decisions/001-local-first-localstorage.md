---
id: 001
title: "Local-first with localStorage, no backend"
date: 2026-04-14
status: accepted
---

# 001 Local-first with localStorage, no backend

## Context
The user wants a personal habit tracker for themselves only, on Next.js deployed to Vercel. They explicitly stated: solo, no other users, no accounts, local-first, localStorage.

## Decision
All application state (habit name, log entries) is stored in `localStorage` under a single versioned key (e.g., `habit-tracker:v1`). No database, no API routes that persist data, no auth. Vercel hosts the static/SSR frontend only.

## Alternatives Considered

### Vercel KV / Postgres / any hosted DB
- Pros: durable across devices and browser resets; enables future multi-device sync.
- Cons: requires auth to scope data per user; introduces a backend the user did not ask for; breaks "local-first" intent.
- Why rejected: user explicitly asked for local-first and no accounts.

### IndexedDB instead of localStorage
- Pros: structured storage, larger quota, better for complex queries.
- Cons: async API, heavier boilerplate; overkill for a single object with a small array.
- Why rejected: the data shape (`{ name, logs: string[] }`) easily fits in localStorage; complexity cost is not justified.

## Consequences
- Device-bound: clearing browser data or changing devices loses all history. Accepted as part of the local-first intent.
- No server costs, no auth surface, no schema migrations.
- Future cross-device sync would be a deliberate architectural change (new decision record), not an incremental feature.
