# Phase 1: Foundation

Bootstrap the app with auth, data model, and onboarding so users can reach the daily-use loop.
