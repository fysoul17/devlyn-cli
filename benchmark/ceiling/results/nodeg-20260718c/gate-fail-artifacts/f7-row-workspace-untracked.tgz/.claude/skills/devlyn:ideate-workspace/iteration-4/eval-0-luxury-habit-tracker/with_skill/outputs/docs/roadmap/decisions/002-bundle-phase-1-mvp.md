---
id: 002
title: "Bundle scaffold + store + log + streak into one shippable item"
date: 2026-04-22
status: accepted
---

# 002 Bundle scaffold + store + log + streak into one shippable item

## Context
During CONVERGE an initial draft had seven items in Phase 1: 1.1 scaffold, 1.2 localStorage store, 1.3 manage habits, 1.4 log today, 1.5 streak display, 1.6 history view, 1.7 deploy. The CHALLENGE rubric (axis: NO OVERENGINEERING — detour sequencing) flagged this as padding the plan with implementation steps that are not features a real user would notice as separate milestones.

## Decision
Collapse Phase 1 to two items whose done-criteria include the full vertical slice (scaffold, store, UI, deploy):

- **1.1 Log habits and see streak** — manage habits, log today, see streak, deployed to Vercel. This is the minimum that gives the user a working tool.
- **1.2 History view** — separate because it is a distinct UI surface (a calendar / list of past days) that could legitimately be skipped for a week or two while 1.1 is in use.

Scaffold and deploy are **done criteria** of 1.1, not standalone items. If 1.1 ships and the URL doesn't work, 1.1 isn't done.

## Alternatives Considered

### Keep the 7-item plan
- Pros: each item is small and easy to reason about
- Cons: Phase 1 delivers no user-visible value until item 6 or 7; intermediate items like "1.2 localStorage store" are not things a user would notice as done. Plan feels productive while shipping nothing.
- Why rejected: rubric axis 5 (OPTIMIZED) — no dead phases — and axis 3 (no detour sequencing). Same final scope, worse sequencing.

### Collapse to one item (1.1 only, with history bundled)
- Pros: simplest possible plan
- Cons: history is a genuinely separate UI surface; bundling it risks the core log+streak flow being delayed while the calendar view is designed
- Why rejected: the marginal cost of two items instead of one is low, and it lets 1.1 ship without waiting on the calendar decision.

## Consequences
- Phase 1 has exactly two items. The plan looks short on paper. That is a feature, not a bug — the roadmap reflects actual scope.
- Item 1.1's done-criteria are long (scaffold, store, manage, log, streak, deploy all in one). The item spec must be explicit about this so auto-resolve doesn't treat it as a single narrow task.
- If the 1.1 implementation stalls, the fix is to split it — but only after we have evidence of actual blockers, not preemptively.
