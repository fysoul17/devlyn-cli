# Post-CHALLENGE Plan — Phase 2 Quick Add

Vision: simple note-taking web app where users don't lose their work. (unchanged)
Phases: Phase 2 gains 1 new item (2.5) plus 1 recommended follow-up (2.6).

## Phase 2 addition

**2.5 — Export / import draft as JSON file** (user-requested)
- Editor shows an "Export draft" button that downloads the current in-memory draft as a `.json` file with a versioned schema.
- Editor shows an "Import draft" control that accepts the same file and rehydrates the editor.
- Acceptance rules (added during CHALLENGE):
  - Schema version field required; unknown/invalid schemas show a visible error, not a silent wipe.
  - If the editor already has non-empty content when import is triggered, confirm-before-replace.
  - Import failure is non-destructive — current editor state is preserved.
- Out of scope: autosave, server-side draft persistence, cross-device sync.

**2.6 — Draft autosave (localStorage-first, optional server sync)** (recommended follow-up, pending user confirmation — see open questions)
- On each meaningful change, persist the draft to `localStorage` keyed by note id.
- On editor mount, hydrate from `localStorage` if a draft exists and the server version is older/missing.
- Out of scope for this item: cross-device sync, conflict UI.

Key decisions: none new.
Deferred: cross-device sync (belongs to a later phase once autosave is live).

## CHALLENGE results

Solo pass: 3 findings, 0 applied (all blocked by Hard Rule — user explicitly requested JSON export).
Codex pass: 3 new findings + 2 confirmations + 1 reframe, 2 applied.

Changes applied during CHALLENGE:
- 2.5: added explicit import acceptance rules (schema validation, confirm-before-replace, non-destructive failure) — triggered by `[codex]` NO GUESSWORK finding on unspecified import behavior.
- Phase 2: added recommended 2.6 autosave item as a committed follow-up path to the direct fix — triggered by `[codex]` OPTIMIZED finding that the plan lacked a path to the root-cause solution.

Open questions for you (rubric flagged things you explicitly asked for — you make the call):

1. **Workaround vs direct fix.** Both the solo pass and Codex flagged 2.5 as CRITICAL NO WORKAROUND: the real problem is "drafts die on session expiry," and file export/reupload asks you (the user) to do the saving the app should be doing. You explicitly asked for JSON export. Options:
   - (a) Ship 2.5 as requested, and also commit to 2.6 autosave in Phase 2 (recommended — preserves your intent, gets the direct fix on the board).
   - (b) Ship 2.5 only. Accept that recovery requires the user to remember to export.
   - (c) Replace 2.5 with 2.6 autosave. Drop file export entirely. (Not recommended without your okay — contradicts your stated ask.)

2. **Root-cause assumption.** We assumed session expiry is the dominant cause of lost drafts. Codex flagged this as NO GUESSWORK — tab crashes, network drops, and accidental navigation may matter just as much. Option: before locking Phase 2 scope, do a 15-minute support-tag audit (or ask your frustrated users directly) to confirm the trigger distribution. This changes nothing structural — autosave fixes all four triggers — but it validates prioritization.

Please confirm: do you want (1a), (1b), or (1c), and do you want to do the quick audit in (2) first?
