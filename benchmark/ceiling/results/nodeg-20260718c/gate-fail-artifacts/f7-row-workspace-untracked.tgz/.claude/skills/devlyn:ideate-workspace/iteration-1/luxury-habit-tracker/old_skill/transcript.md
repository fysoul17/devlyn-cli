# Ideate Transcript — Habit Tracker (old skill snapshot)

## Mode Detection
**Greenfield.** No existing docs, new project, full flow: FRAME → EXPLORE → CONVERGE → DOCUMENT → BRIDGE. Confirmations granted via defaults per eval constraints.

## Phase 1: FRAME
User-stated facts:
- Personal habit tracker web app, solo use.
- Three required capabilities: log "did it today", see a streak, see history.
- Stack: Next.js App Router, Tailwind + shadcn/ui, deployed on Vercel.
- Storage: localStorage (local-first).
- No accounts, no other users, no deadline, greenfield.
- Explicit instruction: do not add features the user did not ask for.

Derived problem statement: remove friction from tracking personal habits by making the daily loop a single tap, with just enough feedback (streak, history) to keep the user motivated.

Constraints locked: Next.js App Router, Tailwind + shadcn/ui, localStorage, Vercel, single user, no scope creep.

Anti-goals: accounts, backend DB, reminders/notifications, analytics/charts, categories/tags, sharing, export (all deferred to backlog).

## Phase 2: EXPLORE
Lightweight since scope is intentionally narrow and the user explicitly rejected extra features. Considered-and-rejected ideas captured in Backlog (cloud sync, export, reminders, analytics, categories). No external research needed for a personal localStorage app on a well-known stack.

Multi-perspective pass:
- **User**: the three asked-for features cover the full daily loop. Nothing else is required to reach value.
- **Technical**: localStorage + pure streak function = trivial. Main risk area is the day-boundary / timezone definition, which becomes decision 003.
- **Strategic**: shipping tight Phase 1 leaves a clean surface for later cloud sync if the user ever wants it.

## Phase 3: CONVERGE
Clustered work into a single phase (Core Loop) with 7 sequenced items:
1. Scaffold → 2. Store → 3. Log button → 4. Streak → 5. History → 6. Manage habits → 7. Deploy.

Prioritization: everything in Phase 1 is high or medium priority because Phase 1 equals the stated minimum product. No item was cut — but many candidate features went to Backlog instead of Phase 1.

Three architecture decisions surfaced:
1. Local-first localStorage (not DB).
2. Server Components by default, client boundaries at leaves.
3. Day boundary in user's local timezone.

Each decision affects multiple items, so each got a decision record.

Confirmation: granted per eval instructions (no mid-pipeline prompts).

## Phase 4: DOCUMENT
Generated, in order:
1. `docs/VISION.md`
2. `docs/roadmap/decisions/001-localstorage-first.md`
3. `docs/roadmap/decisions/002-server-first-rendering.md`
4. `docs/roadmap/decisions/003-local-timezone-day-boundary.md`
5. `docs/roadmap/phase-1/_overview.md`
6. `docs/roadmap/phase-1/1.1-project-scaffold.md`
7. `docs/roadmap/phase-1/1.2-habit-store.md`
8. `docs/roadmap/phase-1/1.3-log-today.md`
9. `docs/roadmap/phase-1/1.4-streak-display.md`
10. `docs/roadmap/phase-1/1.5-history-view.md`
11. `docs/roadmap/phase-1/1.6-manage-habits.md`
12. `docs/roadmap/phase-1/1.7-deploy-vercel.md`
13. `docs/ROADMAP.md`

Quality checklist:
- [x] Every roadmap item has a linked spec file.
- [x] Every spec has testable requirements.
- [x] Every spec has an Out of Scope section.
- [x] Every spec's Context section ≤ 3 sentences.
- [x] ROADMAP.md is an index only.
- [x] Specs are self-contained (do not require reading VISION.md).
- [x] Dependencies documented in specs.
- [x] Decisions include reasoning and alternatives.

## Phase 5: BRIDGE
Suggested implementation order (respects dependencies):
1. 1.1 Project Scaffold — no deps
2. 1.2 Habit Store — needs 1.1
3. 1.3 Log Today — needs 1.2
4. 1.4 Streak Display — needs 1.2, 1.3
5. 1.5 History View — needs 1.2, 1.3
6. 1.6 Manage Habits — needs 1.2, 1.3
7. 1.7 Deploy to Vercel — needs 1.1–1.6

Example invocation:
```
/devlyn:auto-resolve "Implement per spec at docs/roadmap/phase-1/1.1-project-scaffold.md — read the spec file for requirements, constraints, and scope boundaries"
```

## Key Decisions Made
- Phase 1 contains exactly 7 items, no more. All rejected ideas live in Backlog.
- localStorage is the only persistence (decision 001).
- Server Components by default (decision 002).
- Local-timezone day boundary (decision 003).
- No deadline attached to Phase 1 per user; targets left as "ship when ready".
