# Coffeelog Roadmap

> **North Star**: Track your home coffee brews and dial in better cups.

## Phase 2: Dial-in (Target: 2026-Q2)

| # | Feature | Status | Priority | Complexity | Spec |
|---|---------|--------|----------|-----------|------|
| 2.1 | Recipe recommendations | Planned | High | High | [spec](roadmap/phase-2/2.1-recipes.md) |

## Completed
<details>
<summary>Phase 1: MVP Logging (completed 2026-04-15, 3 items)</summary>

| # | Feature | Completed |
|---|---------|-----------|
| 1.1 | Brew log form | 2026-04-15 |
| 1.2 | Brew history list | 2026-04-15 |
| 1.3 | Rating & notes | 2026-04-15 |
</details>
