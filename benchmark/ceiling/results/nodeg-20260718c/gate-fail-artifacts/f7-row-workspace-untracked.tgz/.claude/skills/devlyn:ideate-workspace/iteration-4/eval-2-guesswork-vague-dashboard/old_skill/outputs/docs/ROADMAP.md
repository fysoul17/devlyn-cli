# Dashboard Improvement Roadmap

> **North Star**: [ASSUMED] Make the dashboard a place where the primary user understands state at a glance and takes the next action without friction. See `docs/VISION.md` and `docs/clarifying-questions.md` for why this is [ASSUMED].

> **Why this roadmap has only one item**: the user prompt ("improve our dashboard, plan the next phase") contains no frame — no audience, no pain, no success criterion, no tech stack, no current-state description. Under the NO GUESSWORK axis of the CHALLENGE rubric, inventing a multi-item feature roadmap from that prompt would be plan-level guesswork. The honest next phase is a short framing spike that turns the vague prompt into a real brief. Once `clarifying-questions.md` is answered, this roadmap should be regenerated.

## Phase 1: Frame the Problem (Target: 1 week after clarifying-questions.md is answered)

Turn "improve our dashboard" into a concrete brief that downstream phases can plan against. Ships a written brief and a prioritized list of candidate improvements, not a code change.

| # | Feature | Status | Priority | Complexity | Spec |
|---|---------|--------|----------|-----------|------|
| 1.1 | Dashboard Improvement Brief (discovery spike) | Planned | High | Low | [spec](roadmap/phase-1/1.1-dashboard-improvement-brief.md) |

## Backlog

| Feature | Reason Deferred | Revisit |
|---------|----------------|---------|
| [ASSUMED] Performance improvements | Cannot be prioritized without knowing current latency, target, or user complaints. | After 1.1 lands |
| [ASSUMED] Information architecture redesign | Cannot be designed without knowing primary user task and current pain. | After 1.1 lands |
| [ASSUMED] Visual / theming polish | NO OVERENGINEERING — polish before the core job is understood is a luxury item. | After 1.1 lands |
| [ASSUMED] New data / widgets | NO GUESSWORK — adding data without knowing what's missing is speculation. | After 1.1 lands |

## Decisions

| # | Decision | Date | Record |
|---|----------|------|--------|
| 1 | Phase 1 is a framing spike, not a feature | 2026-04-22 | [record](roadmap/decisions/001-phase-1-is-a-framing-spike.md) |
