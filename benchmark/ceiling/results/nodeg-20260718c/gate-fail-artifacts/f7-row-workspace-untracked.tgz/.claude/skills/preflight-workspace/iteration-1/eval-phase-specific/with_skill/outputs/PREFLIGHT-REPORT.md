# Preflight Report
Generated: 2026-04-09T11:00:00Z
Scope: Phase 1
Previous run: 2026-04-08T10:00:00Z (scope: all)

## Summary
| Category | Count |
|----------|-------|
| MISSING | 2 |
| INCOMPLETE | 7 |
| DIVERGENT | 0 |
| BROKEN | 0 |
| UNDOCUMENTED | 0 |
| STALE_DOC | 3 |
| **Total findings** | **12** |

## Delta (vs previous run)
- Resolved: 0
- Persists: 4 (logout MISSING, email validation, password validation, assignment email notification)
- New: 8 (delete dialog, date display, assigned task visibility, assignee display, unassign endpoint, ROADMAP 1.1 status, ROADMAP 1.2 status, README SSO claim)

Note: Previous run had 6 findings (scope: all). Two of those (README real-time claim, README SSO claim) were STALE_DOC. The README real-time claim references Phase 2 functionality and is excluded from Phase 1 findings. The README SSO claim persists but is recategorized below since SSO is explicitly out of scope for Phase 1 yet still claimed in README.

## Commitment Coverage
- Total commitments: 20 (Phase 1 only)
- Verified (IMPLEMENTED): 11 (55%)
- Issues found: 9 (45%)

## Findings

### CRITICAL
- **[MISSING]** `1.1` -- Logout endpoint
  - **Commitment**: "Logout invalidates the session"
  - **Evidence**: Searched `src/api/auth/` -- only `signup.ts` and `login.ts` exist. No logout handler found. `src/api/auth/login.ts:26` has GAP comment confirming absence.
  - **Impact**: Users cannot securely end sessions. Tokens remain valid until expiry.
  - **Delta**: PERSISTS (from previous run)

### HIGH
- **[INCOMPLETE]** `1.1` -- Email validation on signup
  - **Commitment**: "Email format validated on signup"
  - **Evidence**: `src/api/auth/signup.ts:8` has GAP comment "No email format validation." Email parameter accepted at line 6 without any format check before being stored at line 13.
  - **Impact**: Invalid emails enter the database, potentially breaking any email-dependent features (e.g., 1.3 assignment notifications).
  - **Delta**: PERSISTS

- **[INCOMPLETE]** `1.1` -- Password validation on signup
  - **Commitment**: "Password minimum 8 characters, validated on signup"
  - **Evidence**: `src/api/auth/signup.ts:9` has GAP comment "No password length check." Password accepted at line 6 without length validation before hashing at line 11.
  - **Impact**: Users can set weak passwords (even empty), undermining authentication security.
  - **Delta**: PERSISTS

- **[INCOMPLETE]** `1.2` -- Delete task with confirmation dialog
  - **Commitment**: "User can delete a task with confirmation dialog"
  - **Evidence**: Backend delete exists at `src/api/tasks/index.ts:33-36`. However, `src/components/TaskList.tsx:31` has GAP comment noting no delete button or confirmation dialog in the UI. The only UI is a list of `<li>` elements showing title and status.
  - **Impact**: Users have no way to delete tasks through the UI. The feature is backend-only.
  - **Delta**: NEW

- **[INCOMPLETE]** `1.2` -- Task dates display
  - **Commitment**: "Tasks display creation date and last modified date"
  - **Evidence**: `src/components/TaskList.tsx:27-28` renders only `task.title` and `task.status`. Line 29 has GAP comment confirming dates are not displayed. No `createdAt`/`updatedAt` fields referenced anywhere in the component.
  - **Impact**: Users cannot see when tasks were created or last modified.
  - **Delta**: NEW

- **[INCOMPLETE]** `1.3` -- Email notification on assignment
  - **Commitment**: "Assigned user receives an email notification"
  - **Evidence**: `src/api/tasks/assign.ts:22` has `// TODO: send email notification to assignee` followed by GAP comment at line 23. No email sending logic, no email service import.
  - **Impact**: Assignees are not notified when tasks are assigned to them.
  - **Delta**: PERSISTS

- **[MISSING]** `1.3` -- Unassign action
  - **Commitment**: "Unassign action available to task owner"
  - **Evidence**: `src/api/tasks/assign.ts:28` has GAP comment confirming absence. Searched `src/api/tasks/` -- only `index.ts` (CRUD) and `assign.ts` (assign only) exist. No unassign endpoint or UI action.
  - **Impact**: Once a task is assigned, the owner cannot remove the assignment.
  - **Delta**: NEW

- **[INCOMPLETE]** `1.3` -- Assigned tasks visible to assignee
  - **Commitment**: "Assigned user sees the task in their task list"
  - **Evidence**: `src/api/tasks/index.ts:16-17` `getTasks` queries `where: { userId: user.id }` -- this only returns tasks owned by the user, not tasks where the user is the assignee. The `assigneeId` field is never queried.
  - **Impact**: Assigned users cannot see tasks assigned to them. The assignment feature is effectively one-directional.
  - **Delta**: NEW

- **[INCOMPLETE]** `1.3` -- Assignee display in task detail
  - **Commitment**: "Task detail shows assignee name and avatar"
  - **Evidence**: `src/components/TaskList.tsx:30` has GAP comment "No assignee display." Component renders only title and status per line 28. No assignee data fetched or rendered.
  - **Impact**: Users cannot see who a task is assigned to from the UI.
  - **Delta**: NEW

## Documentation Findings

### ROADMAP.md Status Accuracy
- **[STALE_DOC]** Item 1.1 marked "Done" -- should be "In Progress"
  - **Evidence**: `docs/ROADMAP.md` line 8 shows status "Done." However, logout endpoint is MISSING (CRITICAL) and both email/password validations are INCOMPLETE (HIGH). Three of seven requirements are unfulfilled.
  - **Delta**: NEW

- **[STALE_DOC]** Item 1.2 marked "Done" -- should be "In Progress"
  - **Evidence**: `docs/ROADMAP.md` line 9 shows status "Done." However, delete with confirmation dialog is INCOMPLETE and date display is INCOMPLETE. Two of six requirements are unfulfilled.
  - **Delta**: NEW

### README Alignment
- **[STALE_DOC]** README claims SSO support
  - **Evidence**: `README.md` line 6 lists "SSO" as a feature. No SSO implementation found in the codebase. SSO (OAuth) is explicitly listed as Out of Scope in `docs/roadmap/phase-1/1.1-auth.md` (marked as Phase 3).
  - **Severity**: MEDIUM
  - **Delta**: PERSISTS (was in previous run)

## What's Verified
The following Phase 1 commitments passed audit with evidence:

**1.1 User Authentication (5 of 9 commitments verified):**
- Signup with email/password: `src/api/auth/signup.ts:5-18`
- Login with credentials: `src/api/auth/login.ts:5-23`
- Failed login returns 401: `src/api/auth/login.ts:10-12` and `login.ts:17-19`
- Passwords hashed with bcrypt: `src/api/auth/signup.ts:1,11` and `src/api/auth/login.ts:1,15`
- JWT tokens expire after 24h: `src/api/auth/signup.ts:17` and `src/api/auth/login.ts:22`

**1.2 Task CRUD (4 of 6 commitments verified):**
- Create task with title/description: `src/api/tasks/index.ts:4-12`
- View tasks in list: `src/api/tasks/index.ts:15-18` + `src/components/TaskList.tsx`
- Update task fields: `src/api/tasks/index.ts:21-30`
- Only owner can edit/delete: `src/api/tasks/index.ts:25-26,35` (userId filter in WHERE clause)

**1.3 Task Assignment (2 of 6 commitments verified):**
- Assign by email: `src/api/tasks/assign.ts:4-26`
- Only existing users as assignees: `src/api/tasks/assign.ts:8-14` (404 if not found)

## Accepted Divergences (from previous runs)
None

## Out of Scope (excluded from audit)
- Phase 2 items: 2.1 Real-time Updates, 2.2 Team Management
- Anti-commitments: Social login, 2FA, drag-and-drop, task labels, multiple assignees, push notifications
