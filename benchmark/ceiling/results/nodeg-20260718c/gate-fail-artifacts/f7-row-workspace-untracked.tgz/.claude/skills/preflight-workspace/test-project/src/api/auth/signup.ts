import { hash } from 'bcrypt';
import { db } from '../db';
import { signJwt } from '../jwt';

export async function signup(req: Request) {
  const { email, password } = await req.json();

  // GAP: No email format validation (spec 1.1 requires it)
  // GAP: No password length check (spec 1.1 requires min 8 chars)

  const hashedPassword = await hash(password, 10);

  const user = await db.user.create({
    data: { email, password: hashedPassword },
  });

  const token = signJwt({ userId: user.id }, { expiresIn: '24h' });
  return Response.json({ token, user: { id: user.id, email: user.email } });
}
