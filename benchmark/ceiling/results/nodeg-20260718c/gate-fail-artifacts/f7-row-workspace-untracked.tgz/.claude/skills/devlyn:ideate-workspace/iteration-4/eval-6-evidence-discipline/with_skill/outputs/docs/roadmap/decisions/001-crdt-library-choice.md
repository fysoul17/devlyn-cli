---
id: 001
title: "CRDT library for shared-document state"
date: 2026-04-22
status: accepted
---

# 001 CRDT library for shared-document state

## Context

The product requires two or more clients to edit the same document simultaneously and converge to the same state without a central lock or manual merge. The user explicitly asked, during ideation, "what CRDT should we use?" — so the choice is load-bearing and deserves a decision record rather than being buried in an item spec.

Real-time collaborative text editing has two well-known algorithmic families: **CRDTs** (conflict-free replicated data types) and **Operational Transformation (OT)**. CRDTs were selected as the family because they do not require a central server to linearize operations, which simplifies the server role to a message relay + persistence layer rather than a transformation engine. [UNVERIFIED — this is the commonly cited tradeoff between the two families; the specific claim "CRDTs require no central linearization" is the accurate version and is a direct consequence of the algorithm design, not a market claim.]

Inside the CRDT family, multiple open-source JavaScript-compatible implementations exist. We have internet-free context in this ideation session, so we are documenting the option space and the decision criteria rather than declaring a "most popular" winner.

## Decision

**Adopt a Yjs-family CRDT for the document's shared state in Phase 1**, integrated via a rich-text binding suitable for the chosen editor (for Phase 1, plain text or a minimal prose model). This decision is revisited if Phase 1 implementation surfaces a concrete blocker (bundle size, memory profile at our document size, or a binding mismatch with the chosen editor).

Concrete criteria the library must meet in our context:
1. Ships as an npm package compatible with a Next.js client bundle.
2. Provides a shared text / rich-text type usable with a known editor layer (ProseMirror, Tiptap, Lexical, or similar).
3. Has a documented binary update format so server persistence stores opaque updates rather than a proprietary format.
4. Has a documented WebSocket / connection provider, or its wire format is simple enough that we can write one.

## Alternatives Considered

### Automerge (CRDT)
- Pros: JSON-like data model, thorough documentation of its merge algorithm, active open-source project. [UNVERIFIED — "active" is subjective and not sourced in this session.]
- Cons: Historically had a different performance profile than Yjs-family for long text documents [UNVERIFIED — this is a commonly repeated comparison in the CRDT community that would need a fresh benchmark to treat as current]; API shape differs from common rich-text editor bindings; we would need to evaluate current bindings against our chosen editor.
- Why rejected: we are not rejecting Automerge on technical grounds — we are deferring it. Our working assumption is that the Yjs-family has more off-the-shelf editor bindings that we would otherwise need to re-integrate if we switched later [UNVERIFIED — impression, not a sourced inventory of bindings]. If Phase 1 surfaces a blocker with the Yjs-family choice, Automerge is the next candidate, not a rewrite to OT.

### Operational Transformation (non-CRDT)
- Pros: Long deployment history in production editors [UNVERIFIED — OT has been publicly associated with widely-used editors historically, but this is stated from memory, not a source in this session]; a well-understood algorithmic family.
- Cons: Requires a central authoritative server that transforms every operation against concurrent history; the server becomes a correctness-critical algorithm, not just a relay.
- Why rejected: at ~500 MAU the operational simplicity of CRDT-based sync (server is a relay + persistence layer) outweighs any maturity advantage OT offers.

### A custom-built diff-and-merge on top of a plain text field
- Pros: No dependency; full control.
- Cons: Correctness of concurrent-edit merging is a known-hard problem; rolling our own is a classic mistake-category ("I'll just implement diff3 myself").
- Why rejected: the complexity lives somewhere — either in a battle-tested library or in our code — and our code is the wrong place for it at a 500-MAU small-team product.

## Consequences

- Positive: server becomes a thin relay + persistence layer, simplifying operational model.
- Positive: binary update format means the database stores opaque blobs; we do not need to model document structure in SQL.
- Accepted cost: we take on a third-party dependency for the core data model; upgrades and security patches follow the library's cadence, not ours.
- Accepted cost: rich-text formatting vocabulary is whatever our editor binding supports; adding exotic formatting later may require binding work, not just UI work.
- Open item: the specific library version, the specific editor binding, and the specific connection provider are implementation decisions tracked in Phase 1 item spec 1.1 rather than in this decision record.
