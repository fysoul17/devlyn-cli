# Phase 1: Daily Use

## Goal
Deliver the smallest slice that replaces the shared spreadsheet for an individual rep: sign in, see my cold prospects, log a touchpoint, manage my prospect list.

## Why this phase comes first
Every item here is something a rep does every day. No infrastructure-only items; the app is useful after 1.1 alone (even without CSV import or edit flows — a rep could add a few prospects manually and immediately get the cold list benefit). 1.2 and 1.3 then make the daily workflow real.

## Sequencing notes
- **1.1** bundles scaffold, Clerk auth, Neon schema, and the cold-list page because separating them would produce dead items (no user would notice "scaffold done"). Deploy to Vercel is part of 1.1's done-criteria.
- **1.2** depends on 1.1 (touchpoints need a prospect to attach to).
- **1.3** depends on 1.1 (editing needs the list view; CSV import needs the schema).
- 1.2 and 1.3 can be built in parallel once 1.1 is done.

## Out of scope for Phase 1
- Team/aggregate views (Phase 2)
- Email digests (Phase 2)
- Any automation, integration, or notification outside the web app
