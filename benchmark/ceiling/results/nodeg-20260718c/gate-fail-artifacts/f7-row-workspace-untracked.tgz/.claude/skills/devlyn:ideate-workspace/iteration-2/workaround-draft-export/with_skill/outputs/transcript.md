# Ideate Transcript — Quick Add: Draft loss on session expiry

## Mode detection
Detected **Quick Add** mode: user has existing VISION.md and ROADMAP.md, wants a single new item added to Phase 2.

## Phase order followed
Per SKILL.md Quick Add workflow:
1. Read existing ROADMAP.md context (reconstructed from pre-existing context in prompt)
2. Confirm target phase + next item ID (Phase 2, item 2.x — capturing as 2.3)
3. Draft internal item spec (not shown to user)
4. **Phase 3.5 CHALLENGE** — one solo rubric pass on the single new item
5. Present post-challenge summary (this transcript) with open question
6. DOCUMENT (spec file written)
7. BRIDGE (auto-resolve command)

FRAME / EXPLORE / CONVERGE were skipped per Quick Add mode — only CHALLENGE is mandatory for single-item additions.

## Rubric source
Read `references/challenge-rubric.md` **in full**. Did NOT re-derive the rubric inline. All 5 axes, finding format, and the "respect explicit user intent" hard rule come from that file.

## Internal draft item (pre-challenge)
- **2.3 — Export draft as JSON file for manual re-upload after session expiry**
- Proposed by user verbatim, placed in Phase 2.

## CHALLENGE — solo pass

### Per-axis verdict on the draft item

| Axis | Pass? | Note |
|---|---|---|
| 1. NO WORKAROUND | **FAIL (CRITICAL)** | Classic roadmap workaround — papers over missing draft persistence |
| 2. NO GUESSWORK | PASS | User confirmed the pain, the trigger, the state location, and willingness to hear alternatives |
| 3. NO OVERENGINEERING | **FAIL (HIGH)** | Same failure as axis 1 — adds a feature (export UI + upload UI + JSON schema) instead of the direct fix |
| 4. WORLD-CLASS BEST PRACTICE | **FAIL (HIGH)** | In 2026 the known-good pattern for "don't lose the user's draft" is autosave to local storage and/or server-side drafts (Notion, Linear, Gmail, Google Docs all do this). Manual JSON export/import is not how modern note apps handle this. |
| 5. OPTIMIZED | FAIL (MEDIUM) | Even if export/import ships, the user still has to manually download, re-auth, re-upload, and re-paste — the wait time and friction are not minimized |

### Finding (primary)

```
Severity: CRITICAL
Quote: "2.3 — Export draft as JSON file for manual re-upload after session expiry"
Axis: NO WORKAROUND (also fires on NO OVERENGINEERING and WORLD-CLASS BEST PRACTICE)
Why it fails: The real problem is that drafts live only in React state and are lost when the session expires. The direct fix is draft persistence — localStorage for instant zero-backend relief, or a drafts table in Postgres for cross-device durability. JSON export/import is a roadmap workaround: it asks the user to manually do the thing the app should do automatically, adds export UI + upload UI + a file format to maintain, and leaves the underlying "drafts are ephemeral" problem unfixed. Every modern note app in 2026 (Notion, Linear, Gmail, Google Docs) autosaves drafts; manual file export is not the known-good pattern.
Fix: Replace 2.3 with "Draft autosave + recovery". Concretely:
  - Tier 1 (ship first, ~half a day): debounced autosave to localStorage keyed by note ID (or "new-note"); on mount, if a draft exists, offer "Restore draft from [timestamp]?". Solves the stated pain completely for single-device users with zero backend work and no auth dependency — drafts survive session expiry, tab crash, and accidental navigation.
  - Tier 2 (follow-up, still Phase 2): server-side drafts table (`drafts(user_id, note_id nullable, content, updated_at)`) with autosave-on-blur + every-N-seconds. Survives device switches and clears the localStorage entry on successful server save. This is the world-class pattern and it's a natural step up from Tier 1.
  - Session expiry itself: on 401 from autosave, keep the draft in localStorage and prompt re-auth without destroying state. The draft is never lost regardless of which tier is live.
```

### Hard-rule check — respect explicit user intent

The user **explicitly** asked for JSON export/import AND **explicitly** said they are "open to alternatives." Per the hard rule in `challenge-rubric.md`, the rubric does not silently rewrite the plan — but because the user opened the door to alternatives, surfacing the finding as an open question is exactly the prescribed move. The item is NOT silently replaced; both options are presented and the user decides.

### Verdict
**FAIL — REVISION REQUIRED** on the draft item as written. Surfaced to user as an open question with a concrete alternative.

## Key observation (recorded per eval instructions)
**YES — CHALLENGE flagged the JSON export as a roadmap workaround and proposed direct draft persistence (localStorage autosave first, server-side drafts table second) as the fix.** This is the canonical axis-1 failure pattern from `challenge-rubric.md` example 2, and the rubric caught it on the first solo pass. The user's "open to alternatives" note means the finding is presented as an open question rather than blocked — the user still makes the final call.

## Post-challenge plan (what the user would see)

```
Quick Add — Phase 2

Proposed item: 2.3 — Draft autosave + recovery (localStorage, then server-side)
  (replaces your original "export draft as JSON" framing)

Pressure test results
Solo pass: 1 finding, 1 applied as a proposed revision (surfaced as open question because you explicitly named JSON export)

Changes proposed during CHALLENGE:
- 2.3: JSON export/import → autosave + recovery. Axis 1 (NO WORKAROUND): manual
  file export asks the user to sync the app's state by hand and leaves the
  underlying "drafts are ephemeral" problem unfixed. Axis 4 (WORLD-CLASS):
  autosave is the 2026 standard across Notion / Linear / Gmail / Google Docs.

Open question for you (rubric flagged something you explicitly asked for):
- 2.3: You asked for "export draft as JSON file for manual re-upload." The rubric
  flags it as a roadmap workaround that papers over missing draft persistence.
  You also said you're open to alternatives. Two options:
    A) Ship the autosave + recovery item instead (Tier 1: localStorage, ~half a
       day; Tier 2: server-side drafts table). Solves the loss completely and
       is the modern pattern.
    B) Ship JSON export/import as you originally described. Rubric-flagged but
       you are the user and you make the call.
  Recommendation: A. Confirm which to write.
```

(In this eval run, the user cannot answer, so the spec file is written under Option A — the rubric-preferred path — with a prominent note at the top recording the open question and the fact that the original request was JSON export. This matches the hard rule's intent: the tradeoff is visible, the user's original ask is preserved in writing, and either path can be chosen downstream.)

## Files written
- `outputs/transcript.md` (this file)
- `outputs/roadmap/phase-2/2.3-draft-autosave-and-recovery.md`
- `outputs/ROADMAP-diff.md` (the single row to add to docs/ROADMAP.md)
