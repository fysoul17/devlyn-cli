---
id: 001
title: "Use localStorage for v1 persistence with a migration-aware schema"
date: 2026-04-22
status: accepted
---

# 001 Use localStorage for v1 persistence with a migration-aware schema

## Context
The product is a personal-use, solo-founder expense tracker. Day one requirements: zero setup, offline-capable, survives a browser reload. A real database (Supabase) is on the backlog but not day-one value. We need a persistence choice that ships fast now without painting us into a corner later.

## Decision
Persist all v1 data to `window.localStorage` under a single versioned key, `expenses:v1`. The stored value is a JSON array of expense records. Every record has a stable `id` (UUID v4) and a `createdAt` timestamp from creation time — the same shape we will use when rows move to a Postgres `expenses` table. All access is centralized in a single `useExpenses()` React hook; no component reads or writes localStorage directly.

The schema is chosen so the future Supabase migration is a 1:1 row mapping with no transformation: `id` → Postgres `uuid` primary key, `amount` → `numeric(12,2)`, `category` → `text`, `date` → `date`, `note` → `text`, `createdAt` → `timestamptz`.

## Alternatives Considered

### IndexedDB
- Pros: larger storage quota, structured queries, async API doesn't block.
- Cons: significantly heavier API surface for what is currently a small array; requires a wrapper library (idb, Dexie) to stay ergonomic; the founder's data volume is measured in hundreds of rows per year, nowhere near localStorage's ~5MB limit.
- Why rejected: complexity outweighs benefit at this scale. If the data grows past localStorage's limit, migrating to Supabase is the planned path — not swapping localStorage for IndexedDB.

### Supabase (or any cloud DB) from day one
- Pros: multi-device from the start; no migration later; cleaner architecture.
- Cons: requires auth (explicitly an anti-goal in v1), network dependency, deployment complexity (env vars, project setup), and blocks the "zero setup, just works" first-run experience.
- Why rejected: the user explicitly asked for "localStorage initially, can add Supabase later". Shipping Supabase day one contradicts explicit user intent.

### Plain JSON file on disk via File System Access API
- Pros: user owns the data file directly; natural portability.
- Cons: limited browser support (Chromium-only at present); requires user to pick a file on every session; undermines the "open the app and log" speed goal.
- Why rejected: ergonomics kill the 10-second-entry goal.

## Consequences
- Day-one ship is fast; no backend, no auth, no network path to break.
- App is offline-capable by default; the tab works on a plane.
- Data is locked to one browser on one device until Supabase lands. Documented as a known limitation in the Vision (cross-device deferred to backlog).
- The `:v1` key suffix commits us to a migration protocol: if the schema ever changes, we bump to `expenses:v2` with an explicit migration function. Never mutate `:v1` in place.
- The `useExpenses()` hook is the single point of change for the Supabase migration — components stay the same.
