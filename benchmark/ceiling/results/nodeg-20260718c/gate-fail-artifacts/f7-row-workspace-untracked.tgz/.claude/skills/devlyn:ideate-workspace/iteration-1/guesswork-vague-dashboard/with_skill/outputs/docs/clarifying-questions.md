# Clarifying Questions (unanswered — user gave near-zero framing)

The user said only: *"I want to improve our dashboard. Plan the next phase."*

Per the skill's Conversation Protocol ("Ask, don't assume"), the following questions MUST be answered before any real plan can be written. None of these have been answered in this run — every item in the generated plan is therefore [ASSUMED].

## FRAME phase — problem space

1. **What dashboard?** Which product, which surface, which URL/route? Is it an internal admin panel, a customer-facing analytics view, a devops monitoring screen, a game HUD, something else?
2. **Who are the users of this dashboard?** Internal ops? Paying customers? Engineers? What role/persona?
3. **What problem are you trying to solve?** Is it slow, ugly, missing data, confusing, unreliable, outdated, hard to extend? "Improve" is ambiguous — what's the felt pain?
4. **Why now?** Is there a deadline, a complaint, a metric that regressed, a strategic push?
5. **What does success look like?** A metric that should move (load time, task completion, NPS, churn, ticket volume)? A capability that should exist?
6. **What are the anti-goals?** What should we explicitly NOT touch or change in this phase?

## Mode detection — does anything exist already?

7. **Is there an existing `docs/VISION.md` or `docs/ROADMAP.md`?** (Determines Greenfield vs Expand vs Replan.)
8. **What phase are we in?** "Next phase" implies there was a previous one — what shipped, what's in flight, what's parked?
9. **Are there existing roadmap items or decisions I should read before planning?**

## Constraints

10. **Tech stack?** Framework, hosting, data source, auth, design system?
11. **Team size and timeline for this phase?** One person / one sprint? Three people / one quarter?
12. **Hard constraints?** Compliance, accessibility floor, browser/device support, budget, vendors locked in?

## Scope of "improve"

13. **Performance, UX, data model, new features, visual redesign, reliability, or all of the above?**
14. **Any specific complaints or user feedback driving this?**
15. **Are there competitor/reference dashboards you're benchmarking against?**

## Success criteria for the plan itself

16. **How many items do you want in the next phase?** (1-2 focused items, or a broad 6-10 item phase?)
17. **Is this meant to be handed directly to `/devlyn:auto-resolve`, or reviewed by a human PM first?**

---

Until these are answered, any plan produced is guesswork. The minimal plan in this workspace is produced under protest, with every requirement flagged [ASSUMED].
