# Habit Tracker Roadmap

> **North Star**: A minimal local-first habit tracker.

## Phase 3: Engagement

| # | Feature | Status | Priority | Complexity | Spec |
|---|---------|--------|----------|-----------|------|
| 3.1 | Weekly email summary of streaks | Planned | High | Medium | [spec](roadmap/phase-3/3.1-weekly-email-summary.md) |

## Completed
<details>
<summary>Phase 1: Core (completed 2026-04-22, 2 items)</summary>

| # | Feature | Completed |
|---|---------|-----------|
| 1.1 | Log habit | 2026-04-22 |
| 1.2 | Streak | 2026-04-22 |
</details>

<details>
<summary>Phase 2: Stats (completed 2026-04-22, 2 items)</summary>

| # | Feature | Completed |
|---|---------|-----------|
| 2.1 | History view | 2026-04-22 |
| 2.2 | Streak heatmap | 2026-04-22 |
</details>
