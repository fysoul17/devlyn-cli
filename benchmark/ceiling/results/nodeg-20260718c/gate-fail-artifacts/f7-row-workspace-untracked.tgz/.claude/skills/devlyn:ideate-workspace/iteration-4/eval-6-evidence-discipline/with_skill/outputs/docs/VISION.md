# Collaborative Document Editor Vision

## North Star
A small-team real-time collaborative document editor that lets 2–10 people edit the same document simultaneously without merge conflicts, for teams that find Google Docs heavier than they need.

## Principles
1. **Thin vertical slices over horizontal infrastructure** — each phase ships one user-visible collaboration capability end-to-end. Tradeoff: we accept rough edges inside a shipped slice rather than polish across an unshipped feature.
2. **Convergence over feature parity** — correctness of the shared state (all clients see the same document) is non-negotiable; richness of formatting is secondary. Tradeoff: we accept a smaller formatting vocabulary than Google Docs in exchange for simpler, provable sync behavior.
3. **Small scale is a design asset, not a stopgap** — the product is being designed for roughly 500 monthly active users, not 500,000. Tradeoff: we accept choices that would need to be revisited at 100x scale in exchange for operational simplicity and faster iteration now.
4. **Evidence over folklore** — technology choices are made from documented behavior of libraries we can read, not from "X is popular" assumptions. Tradeoff: we may pick a less trendy option if its contract is clearer for our specific needs.
5. **Explicit failure modes** — when sync, auth, or persistence fails, the UI shows the user what happened and offers a recovery path. Tradeoff: more error-path UI work than a product that silently papers over failures.

## Target Users

### Primary
**Small collaborating teams (2–10 people) who write shared docs together** — a founder and co-founder drafting a spec, a tutor and a student editing an essay, a team drafting a meeting note. Pain: coordinating edits in chat apps or emailing versions around; Google Docs feels too heavy, too account-gated, or too many features to navigate for a lightweight note. Need: open a link, type, see the other person's cursor, trust that the document won't lose their changes.

### Not For
- **Enterprise customers requiring compliance certifications (SOC 2, HIPAA, data residency)** — Why: these compliance programs are multi-quarter efforts and out of scope for the first roadmap at the current scale.
- **Teams needing rich-document parity with Word / Google Docs** (tables, comments threads, track changes, complex formatting) — Why: that's a different product surface; we explicitly choose a smaller feature set.
- **Single-user note-taking** — Why: there are already many excellent single-user editors; our reason to exist is the collaboration layer.

## Anti-Goals
- **No offline-first semantics in the first roadmap** — Why: offline-first correctness with CRDTs is achievable but adds real complexity (local persistence, reconciliation UI, conflict-free merge across long absences). At ~500 MAU on typical network conditions, a live-connection-required experience is acceptable, and offline support can be added later without re-architecting core sync.
- **No rich media (images, embeds, video) in the first roadmap** — Why: blob storage, upload pipelines, and inline-media rendering are each their own vertical. Plain text + minimal inline formatting is enough to prove the collaboration loop works.
- **No multi-region infrastructure in the first roadmap** — Why: single-region single-instance is operationally cheapest at 500 MAU and doesn't close off multi-region later.
- **No real-time video / voice / chat alongside editing** — Why: that is a different product (Figma-style presence, Loom-style calls). Presence in our product means cursors and selection highlights, nothing more.

## Success Metrics
- **Sync correctness**: two clients editing the same document converge to byte-identical state within 1 second of the last edit in more than 99 percent of automated concurrency tests.
- **Perceived latency**: a local edit renders locally in under 50 ms (no server round-trip on the typing path), and appears on a peer client under typical conditions in under 500 ms. [TARGET — to be calibrated once first slice is deployed]
- **Document durability**: zero reports of a completed edit being lost across a session reconnect during closed alpha (≤10 test docs).
- **Onboarding friction**: a new user can open a shared link and start typing in under 15 seconds, without creating an account, in Phase 1.
- **Operational simplicity**: the full stack runs on one small managed Node/Next.js host and one managed datastore, with monthly infrastructure cost under $50 at 500 MAU. [TARGET — subject to chosen stack]
