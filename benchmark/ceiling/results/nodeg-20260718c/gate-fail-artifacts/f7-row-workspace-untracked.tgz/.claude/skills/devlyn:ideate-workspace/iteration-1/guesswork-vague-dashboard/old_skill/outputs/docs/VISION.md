# Vision

> STATUS: PLACEHOLDER — generated from a single-sentence prompt with no product, user, stack, or metric context provided. See `clarifying-questions.md`. Every non-trivial line is tagged `[ASSUMED]` or `[CONFIRMED]`.

## What we're building
- [CONFIRMED] An unspecified product has a dashboard that the user wants to improve.
- [ASSUMED] The dashboard is the primary surface through which users view state and take action. (Unverified — could be secondary/internal.)

## Why now
- [CONFIRMED] The user stated a desire to "improve" the dashboard and "plan the next phase."
- [ASSUMED] There is an existing phase (or phases) already shipped. Not verified — no prior docs were provided.

## Who it's for
- [ASSUMED] Unknown. Could be end users, internal operators, admins, or developers. This MUST be answered before spec generation.

## Success criteria
- [ASSUMED] None provided. Real criteria will replace this once the user answers Batch 3 in `clarifying-questions.md`.

## Anti-goals
- [CONFIRMED] No code changes in this session (skill hard boundary: planning only).
- [ASSUMED] Placeholder: no ground-up rewrite, no stack change. Must be confirmed.

---

This document is deliberately thin. Per the old skill's `hard_boundary` and `conversation_rhythm` rules, generating a full Vision from a vague prompt would fabricate facts and poison downstream auto-resolve runs. The correct next action is to answer `clarifying-questions.md`, then re-run ideation.
