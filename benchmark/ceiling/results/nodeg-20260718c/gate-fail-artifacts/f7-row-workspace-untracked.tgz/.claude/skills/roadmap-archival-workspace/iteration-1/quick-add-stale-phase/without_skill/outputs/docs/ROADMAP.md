# Habitly Roadmap

> **North Star**: Help people build lasting habits through daily gentle feedback.

## Phase 1: Foundation (Target: 2026-Q1)
<!-- Core scaffolding — auth, data model, onboarding. -->

| # | Feature | Status | Priority | Complexity | Spec |
|---|---------|--------|----------|-----------|------|
| 1.1 | User auth & signup | Done | High | Medium | [spec](roadmap/phase-1/1.1-user-auth.md) |
| 1.2 | Habit data model | Done | High | Low | [spec](roadmap/phase-1/1.2-habit-model.md) |
| 1.3 | Onboarding flow | Done | High | Medium | [spec](roadmap/phase-1/1.3-onboarding.md) |

## Phase 2: Daily Use (Target: 2026-Q2)
<!-- What users see every day — the core loop. -->

| # | Feature | Status | Priority | Complexity | Spec |
|---|---------|--------|----------|-----------|------|
| 2.1 | Daily check-in screen | In Progress | High | Medium | [spec](roadmap/phase-2/2.1-daily-checkin.md) |
| 2.2 | Streak visualization | Planned | High | Low | [spec](roadmap/phase-2/2.2-streak-viz.md) |
| 2.3 | Weekly recap email | Planned | Medium | Medium | [spec](roadmap/phase-2/2.3-weekly-recap-email.md) |

## Backlog
| Feature | Reason Deferred | Revisit |
|---------|----------------|---------|
| Social sharing | Out of scope for MVP | 2026-Q3 |

## Decisions
| # | Decision | Date | Record |
|---|----------|------|--------|
| 1 | Use SQLite for local data | 2026-01-10 | [record](roadmap/decisions/001-sqlite.md) |
