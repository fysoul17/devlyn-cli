import { db } from '../db';
import { authMiddleware } from '../middleware/auth';

export async function assignTask(req: Request, taskId: string) {
  const user = await authMiddleware(req);
  const { assigneeEmail } = await req.json();

  const assignee = await db.user.findUnique({
    where: { email: assigneeEmail },
  });
  if (!assignee) {
    return new Response(JSON.stringify({ error: 'User not found' }), {
      status: 404,
    });
  }

  const task = await db.task.update({
    where: { id: taskId, userId: user.id },
    data: { assigneeId: assignee.id },
  });

  // TODO: send email notification to assignee
  // GAP: spec 1.3 requires email notification, not implemented

  return Response.json(task);
}

// GAP: No unassign endpoint (spec 1.3 requires "Unassign action available to task owner")
