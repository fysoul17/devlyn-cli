# Phase 1: Frame the Problem

## Goal
Turn the vague prompt "improve our dashboard — plan the next phase" into a written brief that downstream phases can plan against. The output of this phase is a document, not a code change.

## Why this phase exists
The original user prompt contained no audience, no pain, no success criterion, no tech stack, and no description of what is wrong with the current dashboard. Under the CHALLENGE rubric (NO GUESSWORK), planning features from that prompt would be speculation. The rubric's best-practice axis (WORLD-CLASS BEST PRACTICE) points to a senior-team pattern: when a stakeholder says "improve X" with no detail, the first move is a short framing spike, not a sprint of invented features.

## What "done" looks like for Phase 1
- `docs/clarifying-questions.md` has answers from the stakeholder.
- `docs/VISION.md` is regenerated with the [ASSUMED] tags replaced by real, confirmed facts.
- A ranked list of 3-7 candidate improvements exists, each with a sentence on user value and a rough complexity estimate.
- The team and the stakeholder agree on which 1-3 candidates move into Phase 2.

## What Phase 1 is NOT
- Not a redesign.
- Not a performance pass.
- Not new widgets or data sources.
- Not a tech stack migration.

## Items
- 1.1 — Dashboard Improvement Brief (discovery spike)
