# Phase 1 — Clarify scope of "improve the dashboard"

## Goal
Replace the vague prompt "improve the dashboard" with a concrete, confirmed problem statement that a real next-phase plan can be built on.

## Why this is the whole phase
The user's only input was: "I want to improve our dashboard. Plan the next phase." No domain, users, stack, metrics, constraints, or prior-phase history were provided. Planning concrete implementation items from this input would be guesswork — exactly the failure the CHALLENGE rubric's axis 2 (NO GUESSWORK) exists to catch.

## Items
- 1.1 Frame dashboard improvement (blocked-on-user)
