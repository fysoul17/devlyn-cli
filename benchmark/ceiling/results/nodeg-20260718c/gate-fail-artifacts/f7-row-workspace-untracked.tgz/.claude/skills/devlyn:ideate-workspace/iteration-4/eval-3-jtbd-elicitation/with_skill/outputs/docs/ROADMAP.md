# Cold Prospect Tracker Roadmap

> **North Star**: Every salesperson on the team can see, in under 30 seconds, which of their prospects are going cold — and do something about it before the opportunity is lost.

## Phase 1: Daily Use — see who's cold, log a touch (Target: 2–3 weeks)

Ships the vertical slice that makes the app useful on day one: a rep can sign in, see their cold prospects, and log a touchpoint. Replaces the core spreadsheet workflow.

| # | Feature | Status | Priority | Complexity | Spec |
|---|---------|--------|----------|-----------|------|
| 1.1 | My cold list — sign in, see my prospects ranked by cold risk | Planned | High | Medium | [spec](roadmap/phase-1/1.1-my-cold-list.md) |
| 1.2 | Log a touchpoint — record a contact in under 10 seconds | Planned | High | Low | [spec](roadmap/phase-1/1.2-log-touchpoint.md) |
| 1.3 | Add & edit prospects — manual create, inline edit, CSV import | Planned | High | Medium | [spec](roadmap/phase-1/1.3-manage-prospects.md) |

## Phase 2: Team Visibility & Nudges (Target: +2 weeks)

Adds what the spreadsheet never did well: team-wide cold visibility and a lightweight daily nudge so the cold list becomes a habit, not a thing reps remember to check.

| # | Feature | Status | Priority | Complexity | Spec |
|---|---------|--------|----------|-----------|------|
| 2.1 | Team cold board — manager/aggregate view of at-risk prospects across the team | Planned | Medium | Medium | [spec](roadmap/phase-2/2.1-team-cold-board.md) |
| 2.2 | Daily digest email — morning "here's who's cold today" per rep | Planned | Medium | Low | [spec](roadmap/phase-2/2.2-daily-digest.md) |

## Backlog

| Feature | Reason Deferred | Revisit |
|---------|----------------|---------|
| Custom cold-threshold rules per prospect segment | Default 14 days + per-prospect override is likely enough; add only if reps ask | After 30 days of usage |
| Slack notifications | Email digest first; Slack only if team requests | Phase 3 |
| Calendar/email integration (auto-log touchpoints from Gmail/Outlook) | OAuth + provider-specific work is heavy; manual capture is acceptable in v1 | Phase 3+ |
| Mobile-optimized views | Desk-first per user brief; revisit if reps ask | After launch |
| Activity analytics / win-rate dashboards | Out of scope per Vision anti-goals | Not planned |
| Multi-owner handoff workflow | Each rep owns their prospects in v1 | If managers request |

## Decisions

| # | Decision | Date | Record |
|---|----------|------|--------|
| 1 | Next.js App Router on Vercel with Neon Postgres and Clerk | 2026-04-22 | [record](roadmap/decisions/001-stack.md) |
| 2 | Cold = 14 days since last touchpoint by default; rep-overridable per prospect | 2026-04-22 | [record](roadmap/decisions/002-cold-definition.md) |
| 3 | Ownership model: each prospect has exactly one owner (rep); whole team can view | 2026-04-22 | [record](roadmap/decisions/003-ownership-model.md) |
