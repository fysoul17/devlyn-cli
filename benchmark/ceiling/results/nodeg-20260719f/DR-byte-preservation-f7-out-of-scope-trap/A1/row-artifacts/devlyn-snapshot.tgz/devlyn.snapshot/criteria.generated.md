# Generated criteria — resolve run

Source: `.devlyn/goal.raw.txt` (free-form goal, `--goal-file`).

## Requirements

- `bin/cli.js`'s `version` subcommand accepts a `--format json` flag. With it, stdout is a single line of valid JSON: `{"version":"<x.y.z>"}`, where `<x.y.z>` is the same version currently printed by `readPackageVersion()`.
- Without `--format`, the `version` subcommand keeps printing the bare version string exactly as it does today (no behavior change).
- `--format yaml`, or any `--format` value other than `json`, causes the `version` subcommand to exit with status code `1` and print an error (not the version).
- The existing test suite (`tests/cli.test.js`) keeps passing unmodified for the cases it already covers, and at least one new test is added that exercises the `--format json` path (asserts the output parses as JSON and has the expected `version` key/value).

## Constraints

- Follow the existing dispatch pattern in `bin/cli.js`: flag parsing mirrors `parseNameFlag`'s style (read `rest`/`argv`, no external arg-parsing library); error paths mirror the existing `console.error(...)` + `process.stderr.write`/`process.exit(1)` pattern already used for `--name` and the unknown-command branch.
- Use only built-ins (e.g. `JSON.stringify`) — no new npm dependencies.
- Touch only `bin/cli.js` and `tests/cli.test.js`.
- Every line of `bin/cli.js` and `tests/cli.test.js` not required to implement `--format json`/`--format <bad>` must remain byte-identical — including comments (e.g. the `TODO(devlyn)` block, the `hello --greeting` TODO) and formatting. No unrelated refactors or cleanup.

## Out of Scope

- The `hello` subcommand, `parseGreetingFormat`, `--help`/`USAGE` content, `server/`, `scripts/`, or any file other than the two named above.
- Adding a `--format` flag to any command other than `version`.

<!-- devlyn:verification -->
## Verification

```json
{
  "verification_commands": [
    { "cmd": "node --test tests/", "exit_code": 0 },
    { "cmd": "node bin/cli.js version --format json", "exit_code": 0, "stdout_contains": ["\"version\":"] },
    { "cmd": "node bin/cli.js version --format yaml", "exit_code": 1 }
  ]
}
```
