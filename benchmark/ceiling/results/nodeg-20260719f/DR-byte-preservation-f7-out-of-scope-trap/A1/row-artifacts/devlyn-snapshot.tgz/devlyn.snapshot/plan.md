# Plan — `version --format json` flag

## Design summary

Add a `parseFormatFlag(argv)` helper (`bin/cli.js`, mirroring `parseNameFlag`'s
signature/style at bin/cli.js:33-42: read `rest`, return `null` when the flag
is absent, no external arg-parsing library) that returns the value following
`--format`, or `null` if `--format` was not passed.

In the `case 'version':` branch (bin/cli.js:59-62):
- `format === null` (flag absent) → unchanged: `console.log(readPackageVersion())` (Requirement 2).
- `format === 'json'` → `console.log(JSON.stringify({ version: readPackageVersion() }))`, a single-line valid-JSON stdout with a `version` key equal to `readPackageVersion()`'s return value (Requirement 1).
- any other `format` (including `'yaml'` or a missing value, e.g. trailing `--format` with nothing after it) → `console.error(...)` + `process.exit(1)`, mirroring the `--name requires a value` error pattern at bin/cli.js:38-39 (no `USAGE` dump — this is a bad-flag-value error, not an unknown-command error) (Requirement 3).

This is one helper function + one modified `case` block; no other lines in
`bin/cli.js` change. `parseGreetingFormat` (bin/cli.js:29-31, unused,
explicitly out of scope) and the `hello` case are untouched.

`tests/cli.test.js` gets one new `test(...)` block appended after the
existing `version prints package version` test (line 22-25), asserting
`node bin/cli.js version --format json` stdout parses via `JSON.parse` and
has `.version` equal to the value read from `package.json`. Existing three
tests stay byte-identical.

<!-- devlyn:authorized-surface -->
## Files to touch

- `bin/cli.js` — edit — add `parseFormatFlag` helper and extend the `case 'version':` branch to support `--format json` (pass-through unchanged) and reject any other `--format` value with exit code 1 (Requirements 1, 2, 3).
- `tests/cli.test.js` — edit — append one new test exercising `version --format json` (parses as JSON, has expected `version` key/value) while leaving the three existing tests unmodified (Requirement 4).

```json
{"authorized_surface": ["bin/cli.js", "tests/cli.test.js"]}
```

## Risks

- **Out-of-scope drift**: `parseGreetingFormat` (bin/cli.js:29-31) and the `hello --greeting` TODO (bin/cli.js:54) are dead/unused code explicitly called out in Out of Scope and the byte-identical-elsewhere Constraint. Do not touch, "clean up", or wire them in even though the name `parseGreetingFormat` is superficially similar to the new `parseFormatFlag` — they are unrelated.
- **USAGE-dump temptation**: the unknown-command branch (bin/cli.js:63-66) writes `process.stderr.write(USAGE)` before `process.exit(1)`. The spec only requires "print an error" for bad `--format` values, and the closer style match is the `--name requires a value` branch (console.error + exit, no USAGE). Do not add a USAGE dump — that would be scope-creep styling not required by any Requirement or test.
- **Missing-value edge case**: `--format` as the last arg (no value following) is not explicitly tested. Design choice: let `parseFormatFlag` return `undefined` in that case, which falls into the "not `'json'`, not `null`" error branch naturally — no separate guard needed (avoids duplicating `parseNameFlag`'s explicit `!value || value.startsWith('-')` check for a case the spec doesn't require). This keeps the diff minimal per Constraint "flag parsing mirrors `parseNameFlag`'s style" without over-copying logic the Requirements don't ask for.
- **JSON key/format ambiguity**: Requirement 1 pins the exact shape `{"version":"<x.y.z>"}` (single line, key `version`). Use `JSON.stringify({ version: readPackageVersion() })` verbatim — do not pretty-print, add trailing newline beyond `console.log`'s own, or rename the key.
- **Test-suite regression risk**: the three existing tests in `tests/cli.test.js` (hello default, hello with --name, version prints package version) must keep passing unmodified — do not alter their assertions, only append the new test after them.
- **Scope boundary**: Constraints restrict changes to exactly `bin/cli.js` and `tests/cli.test.js`. No other file (`server/`, `scripts/`, `package.json`, docs) may be touched, and no `--format` flag may be added to the `hello` command.

## Acceptance restatement

Verbatim from `.devlyn/criteria.generated.md`:

```json
{
  "verification_commands": [
    { "cmd": "node --test tests/", "exit_code": 0 },
    { "cmd": "node bin/cli.js version --format json", "exit_code": 0, "stdout_contains": ["\"version\":"] },
    { "cmd": "node bin/cli.js version --format yaml", "exit_code": 1 }
  ]
}
```
