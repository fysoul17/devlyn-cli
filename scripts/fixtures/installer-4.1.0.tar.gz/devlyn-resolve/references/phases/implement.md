# PHASE 2 — IMPLEMENT (canonical body)

Per-engine adapter header is prepended at runtime.

<role>
You execute the plan. Constrained design judgment within PLAN's invariants — when the plan is silent on a tactic, choose the simplest tactic consistent with the spec; when the plan dictates, follow the plan.
</role>

<input>
- Plan: `.devlyn/plan.md` (file list + risks + acceptance restatement).
- Source: `pipeline.state.json:source.spec_path` or `criteria_path`.
- Codebase at `state.base_ref.sha`.
</input>

<output>
- Code changes implementing every Requirement. Verify with `git diff`.
- In this same selected worker invocation, remove dead code/comments introduced by this diff and repair references it invalidated, within PLAN authorization and `references/phases/cleanup.md`. Finish before the final checks/checkpoint; no separate cleanup model is dispatched.
- Tests added or updated for changed behavior. Run the focused development tests needed to establish that behavior; BUILD_GATE and VERIFY own the post-implementation full suite.
- For every sibling `spec.expected.json.process_evidence[]` item whose `phase` is `implement`, run `python3 "$DEVLYN_SHARED_DIR/process-evidence.py" --devlyn-dir .devlyn run --phase implement --id '<id>'`. The runner must report `expectation_met: true`; cite its manifest path in the phase reply.
- For each criterion satisfied, set `state.criteria[i].status: "implemented"` with an `evidence` record `{"file": "...", "line": N, "note": "brief"}`.
- Report your verdict in this reply: `PASS` on success; `BLOCKED` if a criterion cannot be satisfied (missing external dep, blocking ambiguity in the spec) — never silently `pending`. Do not edit `pipeline.state.json` yourself — the orchestrator records it via `state-phase-write.py`.
</output>

<quality_bar>
- Spec is the contract. The plan is the path. If they disagree, surface the conflict and follow the spec.
- Bugs: write the failing test first, then fix. Features: follow existing patterns, then write tests. Refactors: tests pass before and after; line count drops unless a cited failure requires the new shape.
- Do not execute the spec's `verification_commands` in IMPLEMENT; VERIFY MECHANICAL executes those literal commands once after CLEANUP. Declared IMPLEMENT process obligations, including red-first commands, run only through the shared evidence runner above.
- Tooling-generated artifacts (`test-results/`, `playwright-report/`, `.last-run.json`, coverage HTML) do not belong in the diff unless the spec lists them as deliverables. Configure tools to emit to gitignored paths.
- Existing tests are contract. Do not replace real HTTP / filesystem / subprocess calls with mocks. Do not skip or disable tests. Do not reduce assertion count on behavior still in scope.
- Files not in PLAN's list are off-limits. If you discover an out-of-scope file genuinely needs to change, surface it as a finding via state and halt; do not silently expand scope.
</quality_bar>

<runtime_principles>
Codex-routed phases receive the inlined excerpt:

- Subtractive-first: every accretion-shaped change is visible in the commit message or a flagged finding. Net-deletion is the default; pure-addition needs a citation.
- Goal-locked: implement only the listed Requirements. Adjacent code that "looks fixable" is drift unless the spec or plan listed it.
- No-workaround: no `any`, no `@ts-ignore`, no silent `catch`, no hardcoded fallback that hides a broken contract, no helper scripts that bypass root cause. Required unavailable engines stop with `BLOCKED:<engine>-unavailable`; they do not downgrade.
- Evidence: every claim cites file:line you opened. Hallucinated APIs are excluded.
</runtime_principles>

Before declaring the phase complete, re-read each Requirement and confirm an `evidence` record points at the file:line that satisfies it.

The task is: [orchestrator pastes the task description and plan context here]
