#!/usr/bin/env python3
"""Archive devlyn-resolve run artifacts per references/pipeline-state.md#archive-contract.

Usage:
    python3 scripts/archive_run.py [--devlyn-dir .devlyn]

Reads run_id from .devlyn/pipeline.state.json, moves per-run artifacts into
.devlyn/runs/<run_id>/, then best-effort prunes to last 10 completed runs
(unfinished or indeterminate runs are never deleted).

The contract lives in pipeline-state.md. This script implements it so that
archive behavior is identical across every invocation.
"""
from __future__ import annotations

import argparse
import datetime
import hashlib
import json
import pathlib
import re
import runpy
import shutil
import subprocess
import sys
import tempfile


PER_RUN_PATTERNS = (
    "pipeline.state.json",
    "untracked.baseline",
    "external-diff.patch",
    "plan.task-context",
    "plan.prompt",
    "probe-derive.stdout",
    "probe-derive.stderr",
    "*.findings.jsonl",
    "*.log.md",
    "fix-batch.round-*.json",
    "closure-durability.round-*.json",
    "resolve-stop-hook.*.json",
    "criteria.generated.md",
    "goal.raw.txt",
    "surface-close.input.patch",
    "surface-close.prompt",
    "surface-close.output.json",
    "surface-close.stdout",
    # Mutation workers retain the exact session JSONL identified by their
    # dispatch receipt. Round-scoped root files avoid engine-global scans.
    "*.worker-session.*.jsonl",
    "*.invocation.*.json",
    "*.argv.*.json",
    "*.prompt.*",
    "risk-probes.jsonl",
    # Probe scripts referenced by risk-probes.jsonl preserve probes/<file>
    # layout through the common preflight/move plan below.
    # iter-0019.8: spec-verify carrier artifacts get archived alongside
    # other per-run state. Killed mid-run cleanup is enforced separately
    # by spec-verify-check.py main() — when source markdown has no json
    # block AND BENCH_WORKDIR is unset (real-user mode), the script drops
    # any pre-existing .devlyn/spec-verify.json so a stale orphan from a
    # killed prior run cannot poison this run's gate.
    "spec-verify.json",
    "spec-verify.results.json",
    "spec-verify-findings.jsonl",
    "verify-merge.summary.json",
    "verify.primary.timeout.json",
    "verify.pair.timeout.json",
    "finish-gate.summary.json",
    # iter-0033a/2026-04-30 archive-fix iter: NEW /devlyn-resolve emits
    # plan.md (PLAN output) + final-report.md (PHASE 6 render) +
    # cumulative.patch (cumulative diff). Smoke 2's archive listing
    # captured all three; archive_run.py was missing them because the
    # patterns predated the new skill's artifact set. Added explicitly
    # so the move is deterministic.
    "plan.md",
    "final-report.md",
    "cumulative.patch",
    # iter-0033c (Codex R-final-smoke Q2): pair-mode VERIFY emits per-judge
    # deliberation transcripts (verify-judge-claude.md / verify-judge-codex.md
    # — and any future-engine analogue via wildcard). Smoke 1a (F2 l2_forced)
    # surfaced the gap: the orchestrator wrote them and listed them as
    # artifacts, but archive_run.py left them in .devlyn/. Gate 8
    # ("pair_judge findings archive distinguishable") would false-fail on
    # every paired fixture without this glob.
    "verify-judge-*.md",
    # *-judge.*: every engine's pair-judge stdout/stderr capture
    # (codex-judge.*, claude-judge.* — adapters/claude.md ## Invocation).
    "*-judge.*",
    # Phase-owned prompt, context, raw-stream, event, and retry carriers use
    # a phase prefix. Keep the ownership surface here so bootstrap and final
    # archive cannot drift onto separate cleanup lists.
)
PER_RUN_PATTERNS += tuple(
    f"{phase}.{suffix}"
    for phase in (
        "plan", "probe-derive", "implement", "surface-close", "build_gate",
        "build-gate", "cleanup", "verify", "final-report", "finish-gate",
    )
    for suffix in (
        "task-context", "prompt", "stdout", "stderr", "events.jsonl",
        "event-stream.jsonl", "retry.*",
    )
)
BOOTSTRAP_TEMP_PATTERNS = tuple(
    name + ".tmp.*" for name in (
        "goal.raw.txt", "spec-verify.json", "external-diff.patch", "pipeline.state.json",
    )
)
PER_RUN_PATTERNS += BOOTSTRAP_TEMP_PATTERNS

SAFE_RUN_ID_RE = re.compile(r"^[A-Za-z0-9_.-]+$")
valid_final_verdict = runpy.run_path(
    pathlib.Path(__file__).with_name("terminal-claim-check.py")
)["valid_final_verdict"]


class ArchiveError(Exception):
    pass


def process_evidence_module():
    return runpy.run_path(pathlib.Path(__file__).with_name("process-evidence.py"))


def invocation_receipt_module():
    return runpy.run_path(pathlib.Path(__file__).with_name("invocation-receipt.py"))


def reject_json_constant(token: str) -> None:
    raise ValueError(f"invalid JSON numeric constant: {token}")


def reject_duplicate_keys(pairs: list[tuple[str, object]]) -> dict:
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError(f"duplicate JSON key: {key}")
        result[key] = value
    return result


def loads_strict_json(text: str):
    return json.loads(
        text,
        parse_constant=reject_json_constant,
        object_pairs_hook=reject_duplicate_keys,
    )


def read_state(devlyn: pathlib.Path) -> dict:
    state_path = devlyn / "pipeline.state.json"
    if not state_path.is_file():
        raise ArchiveError(f"{state_path} not found")
    try:
        state = loads_strict_json(state_path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, ValueError) as exc:
        raise ArchiveError(f"{state_path} is not valid JSON: {exc}") from exc
    if not isinstance(state, dict):
        raise ArchiveError(f"{state_path} must contain a JSON object")
    run_id = state.get("run_id")
    if not isinstance(run_id, str) or not run_id:
        raise ArchiveError(f"{state_path} has no run_id")
    if not SAFE_RUN_ID_RE.fullmatch(run_id):
        raise ArchiveError(f"{state_path} run_id must match [A-Za-z0-9_.-]+")
    return state


def read_run_id(devlyn: pathlib.Path) -> str:
    try:
        return read_state(devlyn)["run_id"]
    except ArchiveError as exc:
        raise SystemExit(f"error: {exc}") from exc


def is_completed(state: object) -> bool:
    phases = state.get("phases") if isinstance(state, dict) else None
    final = phases.get("final_report") if isinstance(phases, dict) else None
    if not isinstance(final, dict) or not valid_final_verdict(final.get("verdict")):
        return False
    timestamp = final.get("completed_at")
    if not isinstance(timestamp, str) or not re.fullmatch(
        r"[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}(?:\.[0-9]{3})?Z",
        timestamp,
    ):
        return False
    try:
        datetime.datetime.strptime(
            timestamp, "%Y-%m-%dT%H:%M:%S.%fZ" if "." in timestamp else "%Y-%m-%dT%H:%M:%SZ",
        )
    except ValueError:
        return False
    return True


def has_bootstrap_residue(devlyn: pathlib.Path) -> bool:
    return any(path for pattern in BOOTSTRAP_TEMP_PATTERNS for path in devlyn.glob(pattern))


def static_artifacts(devlyn: pathlib.Path) -> list[pathlib.Path]:
    found: dict[pathlib.Path, None] = {}
    for pattern in PER_RUN_PATTERNS:
        for path in devlyn.glob(pattern):
            if path.is_file():
                found[path] = None
    probes = devlyn / "probes"
    if probes.is_dir():
        for path in probes.rglob("*"):
            if path.is_file():
                found[path] = None
    return sorted(found)


def has_owned_artifacts(devlyn: pathlib.Path) -> bool:
    if not devlyn.is_dir():
        return False
    if has_bootstrap_residue(devlyn) or static_artifacts(devlyn):
        return True
    evidence = devlyn / "process-evidence"
    return evidence.is_dir() and any(path.is_file() for path in evidence.rglob("*"))


def dynamic_evidence_artifacts(devlyn: pathlib.Path, state: dict) -> list[pathlib.Path]:
    carriers = state.get("process_evidence")
    evidence_root = devlyn / "process-evidence"
    if carriers is None:
        if evidence_root.is_dir() and any(path.is_file() for path in evidence_root.rglob("*")):
            raise ArchiveError("process-evidence files exist without state bindings")
        return []
    if not isinstance(carriers, list):
        raise ArchiveError("state.process_evidence must be null or an array")

    runner = process_evidence_module()
    work = devlyn.parent.resolve()
    run_id = state["run_id"]
    expected_root = pathlib.PurePosixPath(".devlyn") / "process-evidence" / run_id
    found: dict[pathlib.Path, None] = {}
    for carrier in carriers:
        try:
            runner["validate_bound_carrier"](work, carrier)
        except (runner["EvidenceError"], OSError, UnicodeError, ValueError) as exc:
            raise ArchiveError(f"invalid bound process evidence: {exc}") from exc
        manifest = carrier["manifest"]
        paths = [manifest["path"]]
        for stream in carrier["streams"]:
            paths.extend((stream["stdout"]["path"], stream["stderr"]["path"]))
        for relative_text in paths:
            relative = pathlib.PurePosixPath(relative_text)
            try:
                relative.relative_to(expected_root)
            except ValueError as exc:
                raise ArchiveError(
                    f"process evidence is not owned by state.run_id {run_id}: {relative_text}"
                ) from exc
            source = work.joinpath(*relative.parts)
            if source in found:
                raise ArchiveError(f"duplicate state-bound process-evidence path: {relative_text}")
            found[source] = None

    actual = {
        path.resolve()
        for path in evidence_root.rglob("*")
        if path.is_file()
    } if evidence_root.is_dir() else set()
    bound = {path.resolve() for path in found}
    unbound = []
    for path in actual - bound:
        try:
            unbound.append(path.relative_to(work).as_posix())
        except ValueError as exc:
            raise ArchiveError(f"process-evidence file escapes the worktree: {path}") from exc
    unbound.sort()
    if unbound:
        raise ArchiveError("unbound process-evidence file(s): " + ",".join(unbound))
    return sorted(found)


def dynamic_invocation_artifacts(devlyn: pathlib.Path, state: dict) -> list[pathlib.Path]:
    phases = state.get("phases")
    if not isinstance(phases, dict):
        return []
    work = devlyn.parent.resolve()
    found: dict[pathlib.Path, None] = {}
    for phase_name, phase in phases.items():
        if not isinstance(phase, dict):
            continue
        records = [phase]
        history = phase.get("history")
        if isinstance(history, list):
            records.extend(record for record in history if isinstance(record, dict))
        for record in records:
            receipt = record.get("invocation_receipt")
            if receipt is None:
                continue
            if not isinstance(receipt, dict) or set(receipt) != {
                "path", "sha256", "sandbox", "sandbox_network_access",
                "argv_sha256", "exit_code",
            }:
                raise ArchiveError(f"phases.{phase_name} invocation receipt binding is invalid")
            relative_text = receipt["path"]
            if not isinstance(relative_text, str):
                raise ArchiveError(f"phases.{phase_name} invocation receipt path is invalid")
            relative = pathlib.PurePosixPath(relative_text)
            if (
                relative.is_absolute()
                or ".." in relative.parts
                or relative.parts[:1] != (".devlyn",)
            ):
                raise ArchiveError(f"invocation receipt escapes .devlyn: {relative_text}")
            source = work.joinpath(*relative.parts)
            try:
                resolved = source.resolve(strict=True)
                resolved.relative_to(work)
                if source.is_symlink() or not resolved.is_file():
                    raise ArchiveError(
                        f"bound invocation receipt is not a regular worktree file: {relative_text}"
                    )
                raw = source.read_bytes()
            except (OSError, ValueError) as exc:
                raise ArchiveError(f"bound invocation receipt is missing: {relative_text}") from exc
            if receipt["sha256"] != hashlib.sha256(raw).hexdigest():
                raise ArchiveError(f"bound invocation receipt digest mismatch: {relative_text}")
            try:
                document, receipt_file, prompt_file, session_file = (
                    invocation_receipt_module()["validate_receipt_artifacts"](
                        work, source, run_id=state["run_id"], phase=phase_name,
                    )
                )
            except (OSError, UnicodeError, ValueError) as exc:
                raise ArchiveError(f"invalid bound invocation receipt: {exc}") from exc
            if (
                not isinstance(receipt["sandbox"], str)
                or type(receipt["sandbox_network_access"]) is not bool
                or not isinstance(receipt["argv_sha256"], str)
                or isinstance(receipt["exit_code"], bool)
                or not isinstance(receipt["exit_code"], int)
                or receipt["sandbox"] != document["sandbox"]
                or receipt["sandbox_network_access"] is not document["sandbox_network_access"]
                or receipt["argv_sha256"] != document["argv_sha256"]
                or receipt["exit_code"] != document["exit_code"]
            ):
                raise ArchiveError(
                    f"bound invocation receipt fields mismatch sealed file: {relative_text}"
                )
            for artifact in (receipt_file, prompt_file, session_file):
                if artifact in found:
                    raise ArchiveError(
                        f"duplicate state-bound invocation artifact: {artifact.relative_to(work)}"
                    )
                found[artifact] = None
            if "role_argv" in record:
                binding = record["role_argv"]
                expected = f".devlyn/{phase_name}.argv.{document['round']}.json"
                if not isinstance(binding, dict) or binding.get("path") != expected:
                    raise ArchiveError("invalid state-bound worker argv path")
                argv_file = work / expected
                if argv_file.is_symlink() or not argv_file.is_file():
                    raise ArchiveError("missing regular state-bound worker argv")
                argv_raw = argv_file.read_bytes()
                try:
                    argv = json.loads(argv_raw)
                except (ValueError, UnicodeError) as exc:
                    raise ArchiveError("malformed state-bound worker argv") from exc
                if (not isinstance(argv, list) or any(not isinstance(arg, str) for arg in argv)
                        or len(argv_raw) != binding.get("bytes")
                        or hashlib.sha256(argv_raw).hexdigest() != binding.get("sha256")
                        or hashlib.sha256(json.dumps(argv, separators=(",", ":")).encode()).hexdigest() != receipt["argv_sha256"]):
                    raise ArchiveError("altered state-bound worker argv")
                found[argv_file] = None
    return sorted(found)


def dynamic_judge_role_artifacts(devlyn: pathlib.Path, state: dict) -> list[pathlib.Path]:
    verify = state.get("phases", {}).get("verify", {})
    if verify is None:
        return []
    if not isinstance(verify, dict) or not isinstance(verify.get("history", []), list):
        raise ArchiveError("malformed VERIFY phase/history")
    records = [verify] + (verify.get("history") or [])
    found = set()
    for record in records:
        if not isinstance(record, dict):
            continue
        bindings = record.get("role_evidence") or {}
        if not isinstance(bindings, dict):
            raise ArchiveError("malformed state-bound judge role evidence")
        for binding in bindings.values():
            if not isinstance(binding, dict) or not isinstance(binding.get("artifacts"), list):
                raise ArchiveError("malformed judge role artifact binding")
            for artifact in [binding, *binding["artifacts"]]:
                relative = pathlib.PurePosixPath(artifact.get("path", ""))
                if len(relative.parts) != 2 or relative.parts[0] != ".devlyn":
                    raise ArchiveError("judge role artifact path escapes canonical .devlyn")
                path = devlyn / relative.name
                if path.is_symlink() or not path.is_file():
                    raise ArchiveError(f"missing regular judge role artifact: {relative}")
                raw = path.read_bytes()
                if hashlib.sha256(raw).hexdigest() != artifact.get("sha256") or len(raw) != artifact.get("bytes"):
                    raise ArchiveError(f"altered judge role artifact: {relative}")
                found.add(path)
    return sorted(found)


def archive_plan(devlyn: pathlib.Path, dest: pathlib.Path, state: dict) -> list[tuple[pathlib.Path, pathlib.Path]]:
    devlyn = devlyn.resolve()
    dest = dest.resolve(strict=False)
    phases = state.get("phases")
    final = phases.get("final_report") if isinstance(phases, dict) else None
    if isinstance(final, dict) and "output_sha256" in final:
        digest = final["output_sha256"]
        artifacts = final.get("artifacts")
        report = devlyn / "final-report.md"
        if (
            not isinstance(digest, str) or not re.fullmatch(r"[0-9a-f]{64}", digest)
            or not isinstance(artifacts, dict)
            or artifacts.get("log_file") != ".devlyn/final-report.md"
            or report.is_symlink() or not report.is_file()
        ):
            raise ArchiveError("final-report binding or canonical file is invalid")
        if hashlib.sha256(report.read_bytes()).hexdigest() != digest:
            raise ArchiveError("final-report bytes differ from completed output_sha256")
    moves: list[tuple[pathlib.Path, pathlib.Path]] = []
    sources: set[pathlib.Path] = set()
    targets: set[pathlib.Path] = set()

    def add(source: pathlib.Path, target: pathlib.Path) -> None:
        if source in sources:
            return
        if target in targets:
            raise ArchiveError(f"archive destination is ambiguous: {target}")
        if target.exists() or target.is_symlink():
            raise ArchiveError(f"archive destination collision: {target}")
        parent = target.parent
        while parent != dest.parent:
            if parent.exists() and (parent.is_symlink() or not parent.is_dir()):
                raise ArchiveError(f"archive destination parent is unsafe: {parent}")
            if parent == dest:
                break
            parent = parent.parent
        sources.add(source)
        targets.add(target)
        moves.append((source, target))

    for source in static_artifacts(devlyn):
        relative = source.relative_to(devlyn)
        target = dest / relative if relative.parts[0] == "probes" else dest / source.name
        add(source, target)
    for source in dynamic_evidence_artifacts(devlyn, state):
        add(source, dest / source.relative_to(devlyn))
    for source in dynamic_invocation_artifacts(devlyn, state):
        add(source, dest / source.relative_to(devlyn))
    for source in dynamic_judge_role_artifacts(devlyn, state):
        add(source, dest / source.relative_to(devlyn))
    return moves


def move_artifacts(devlyn: pathlib.Path, dest: pathlib.Path) -> int:
    devlyn = devlyn.resolve()
    dest = dest.resolve()
    state = read_state(devlyn)
    if dest.name != state["run_id"] or dest.parent != devlyn / "runs":
        raise ArchiveError("archive destination does not match authenticated state.run_id")
    moves = archive_plan(devlyn, dest, state)
    completed: list[tuple[pathlib.Path, pathlib.Path]] = []
    try:
        for source, target in moves:
            target.parent.mkdir(parents=True, exist_ok=True)
            try:
                shutil.move(str(source), str(target))
            except OSError:
                target.unlink(missing_ok=True)
                raise
            completed.append((source, target))
    except BaseException:
        for source, target in reversed(completed):
            source.parent.mkdir(parents=True, exist_ok=True)
            shutil.move(str(target), str(source))
        raise
    for root in (devlyn / "probes", devlyn / "process-evidence" / state["run_id"]):
        if root.is_dir():
            for directory in sorted(
                (path for path in root.rglob("*") if path.is_dir()),
                key=lambda path: len(path.parts), reverse=True,
            ):
                directory.rmdir()
            root.rmdir()
    return len(completed)


def prune(runs_dir: pathlib.Path, keep: int = 10) -> int:
    """Delete oldest completed runs beyond `keep`. In-flight runs never removed."""
    candidates = []
    for d in sorted(runs_dir.glob("*/"), key=lambda p: p.name):
        try:
            s = read_state(d)
        except ArchiveError:
            # Can't decide flight-state safely; skip (never prune)
            continue
        if not is_completed(s) or has_bootstrap_residue(d):
            continue  # in-flight or indeterminate
        candidates.append(d)
    over = len(candidates) - keep
    if over <= 0:
        return 0
    pruned = 0
    for d in candidates[:over]:  # oldest first (lex sort = chronological)
        shutil.rmtree(d, ignore_errors=False)
        pruned += 1
    return pruned


def completion_self_test() -> None:
    valid = [
        {"verdict": verdict, "completed_at": timestamp}
        for verdict in ("PASS", "PASS_WITH_ISSUES", "NEEDS_WORK", "BLOCKED")
        for timestamp in ("2024-02-29T23:59:59Z", "2024-02-29T23:59:59.123Z")
    ]
    invalid = [None, [], "PASS", {}, {"verdict": "PASS"}]
    invalid += [
        {"verdict": verdict, "completed_at": "2026-09-06T00:00:00Z"}
        for verdict in (None, [], {}, 1, "", "FAIL", "UNKNOWN", "pass")
    ]
    invalid += [
        {"verdict": "PASS", "completed_at": timestamp}
        for timestamp in (
            None, [], 1, "", "2026-09-06T00:00:00", "2026-09-06T00:00:00+00:00",
            "2026-02-29T00:00:00Z", "2026-13-01T00:00:00Z", "0000-01-01T00:00:00Z",
            "2026-09-06T24:00:00Z", "2026-09-06T00:60:00Z", "2026-09-06T00:00:60Z",
            "2026-09-06T00:00:00.1Z", "2026-09-06T00:00:00.123456Z",
            "2026-9-06T00:00:00Z", "2026-09-06 00:00:00Z", "2026-09-06T00:00:00Z\n",
        )
    ]
    invalid.append({"completed_at": "2026-09-06T00:00:00Z"})
    assert all(is_completed({"phases": {"final_report": final}}) for final in valid)
    assert not any(is_completed({"phases": {"final_report": final}}) for final in invalid)
    assert not any(is_completed(state) for state in (None, [], {}, {"phases": []}))
    with tempfile.TemporaryDirectory() as tmp:
        runs = pathlib.Path(tmp)
        preserved = []
        for i, final in enumerate(invalid):
            path = runs / f"indeterminate-{i:02d}" / "pipeline.state.json"
            path.parent.mkdir()
            path.write_text(json.dumps({"run_id": path.parent.name, "phases": {"final_report": final}}), encoding="utf-8")
            preserved.append(path)
        for i, raw in enumerate((b"{", b"\xff", b"null", b'{"phases":{}}', b'{"run_id":[]}')):
            path = runs / f"malformed-{i}" / "pipeline.state.json"
            path.parent.mkdir()
            path.write_bytes(raw)
            preserved.append(path)
        for i, pattern in enumerate(BOOTSTRAP_TEMP_PATTERNS):
            path = runs / f"residue-{i}" / "pipeline.state.json"
            path.parent.mkdir()
            path.write_text(json.dumps({"run_id": path.parent.name, "phases": {"final_report": valid[0]}}), encoding="utf-8")
            residue = path.with_name(pattern.replace("*", "interrupted"))
            residue.write_bytes(b"interrupted initialization")
            preserved.extend((path, residue))
        for i in range(12):
            path = runs / f"complete-{i:02d}" / "pipeline.state.json"
            path.parent.mkdir()
            path.write_text(json.dumps({"run_id": path.parent.name, "phases": {"final_report": valid[i % 8]}}), encoding="utf-8")
        before = {p: p.read_bytes() for p in preserved}
        assert prune(runs) == 2
        assert {p: p.read_bytes() for p in preserved} == before
        assert not (runs / "complete-00").exists() and not (runs / "complete-01").exists()
        assert all((runs / f"complete-{i:02d}").is_dir() for i in range(2, 12))
        assert prune(runs) == 0
    print("PASS archive completion: 8 terminal forms; malformed/unfinished/residue retained beyond keep-10")


def full_terminal_verdict_completion_self_test() -> None:
    timestamp = "2026-09-06T00:00:00Z"
    assert is_completed({"phases": {"final_report": {
        "verdict": "BLOCKED:repair-budget-exhausted", "completed_at": timestamp,
    }}})
    assert not is_completed({"phases": {"final_report": {
        "verdict": "BLOCKED:", "completed_at": timestamp,
    }}})


def self_test() -> int:
    assert dynamic_judge_role_artifacts(pathlib.Path(".devlyn"), {"phases": {"verify": None}}) == []
    assert dynamic_judge_role_artifacts(pathlib.Path(".devlyn"), {"phases": {}}) == []
    try:
        dynamic_judge_role_artifacts(pathlib.Path(".devlyn"), {"phases": {"verify": []}})
    except ArchiveError:
        pass
    else:
        raise AssertionError("malformed non-null VERIFY phase accepted")
    try:
        loads_strict_json('{"run_id":"a","run_id":"b"}')
    except ValueError as exc:
        assert "duplicate JSON key" in str(exc)
    else:
        raise AssertionError("duplicate archive state key was accepted")
    with tempfile.TemporaryDirectory() as tmp:
        work = pathlib.Path(tmp)
        devlyn = pathlib.Path(tmp) / ".devlyn"
        devlyn.mkdir()
        invocation = invocation_receipt_module()
        prior_prompt = devlyn / "build_gate.prompt.1"
        prior_prompt.write_text("verify prior archive\n", encoding="utf-8")
        prior_session = devlyn / "build_gate.worker-session.1.jsonl"
        prior_session.write_text('{"type":"thread.started","round":1}\n', encoding="utf-8")
        prior_receipt = devlyn / "build_gate.invocation.1.json"
        invocation["start_receipt"](
            work, prior_receipt, "run-1", "build_gate", 1,
            str(prior_prompt), str(prior_session),
            ["--json", "-C", str(work), "-s", "workspace-write", "-m", "gpt-test",
             "-c", "sandbox_workspace_write.network_access=true",
             "verify prior archive"],
        )
        invocation["finish_receipt"](work, prior_receipt, 0)
        prior_binding = invocation["validate_receipt"](
            work, prior_receipt, run_id="run-1", phase="build_gate", round_=1,
            model="gpt-test", prompt_sha256=hashlib.sha256(prior_prompt.read_bytes()).hexdigest(),
            session_path=prior_session,
        )
        build_prompt = devlyn / "build_gate.prompt.2"
        build_prompt.write_text("verify archive\n", encoding="utf-8")
        build_session = devlyn / "build_gate.worker-session.2.jsonl"
        build_session.write_text('{"type":"thread.started"}\n', encoding="utf-8")
        build_receipt = devlyn / "build_gate.invocation.2.json"
        invocation["start_receipt"](
            work, build_receipt, "run-1", "build_gate", 2,
            str(build_prompt), str(build_session),
            ["--json", "-C", str(work), "-s", "workspace-write", "-m", "gpt-test",
             "-c", "sandbox_workspace_write.network_access=true", "verify archive"],
        )
        invocation["finish_receipt"](work, build_receipt, 0)
        receipt_binding = invocation["validate_receipt"](
            work, build_receipt, run_id="run-1", phase="build_gate", round_=2,
            model="gpt-test", prompt_sha256=hashlib.sha256(build_prompt.read_bytes()).hexdigest(),
            session_path=build_session,
        )
        plan_prompt = devlyn / "plan.prompt.0"
        plan_prompt.write_text("plan archive\n", encoding="utf-8")
        plan_session = devlyn / "plan.worker-session.0.jsonl"
        plan_session.write_text('{"type":"thread.started"}\n', encoding="utf-8")
        plan_receipt = devlyn / "plan.invocation.0.json"
        invocation["start_receipt"](
            work, plan_receipt, "run-1", "plan", 0,
            str(plan_prompt), str(plan_session),
            ["--json", "-C", str(work), "-s", "workspace-write",
             "-m", "gpt-test", "-c",
             "sandbox_workspace_write.network_access=false", "plan archive"],
        )
        invocation["finish_receipt"](work, plan_receipt, 0)
        plan_binding = invocation["validate_receipt"](
            work, plan_receipt, run_id="run-1", phase="plan", round_=0,
            model="gpt-test", prompt_sha256=hashlib.sha256(plan_prompt.read_bytes()).hexdigest(),
            session_path=plan_session,
        )
        state = {
            "run_id": "run-1",
            "phases": {
                "plan": {
                    "round": 1,
                    "history": [{"invocation_receipt": plan_binding}],
                },
                "verify": {"round": 2},
                "build_gate": {
                    "round": 2,
                    "history": [{"invocation_receipt": prior_binding}],
                    "invocation_receipt": receipt_binding,
                },
                "final_report": {"verdict": "PASS", "completed_at": "2026-09-06T00:00:00Z"},
            },
            "process_evidence": None,
        }
        runner = process_evidence_module()
        obligation = runner["normalize_obligation"]({
            "id": "mechanical-0",
            "phase": "verify",
            "argv": [sys.executable, "-c", "import sys;sys.stdout.buffer.write(b'raw\\x00out')"],
        })
        manifest_rel = runner["manifest_relative_path"](state, "verify")
        runner["capture_process"](
            work, work / manifest_rel, state["run_id"], "verify", 2, obligation,
        )
        state["process_evidence"] = [runner["validate_manifest"](
            work, manifest_rel, state["run_id"], "verify", 2,
            [obligation], require_expectations=False,
        )]
        (devlyn / "pipeline.state.json").write_text(
            json.dumps(state) + "\n", encoding="utf-8",
        )
        for name in (
            "risk-probes.jsonl",
            "goal.raw.txt",
            "surface-close.input.patch",
            "surface-close.prompt",
            "surface-close.output.json",
            "surface-close.stdout",
            "implement.worker-session.0.jsonl",
            "surface-close.worker-session.0.jsonl",
            "cleanup.worker-session.1.jsonl",
            "resolve-stop-hook.run-1.123.456.json",
            "verify.pair.findings.jsonl",
            "verify-merge.summary.json",
            "untracked.baseline",
            "external-diff.patch",
            "plan.task-context",
            "plan.prompt",
            "probe-derive.stdout",
            "probe-derive.stderr",
            "verify.primary.timeout.json",
            "verify.pair.timeout.json",
            "codex-judge.stdout",
            "codex-judge.summary.json",
            "claude-judge.stdout",
            "claude-judge.stderr",
            "implement.task-context",
            "implement.prompt",
            "implement.stdout",
            "implement.stderr",
            "implement.events.jsonl",
            "implement.retry.1.stdout",
        ):
            (devlyn / name).write_text("{}\n", encoding="utf-8")
        (devlyn / "probes").mkdir()
        (devlyn / "probes" / "P1.py").write_text("print('probe')\n", encoding="utf-8")
        global_rollout = devlyn / "engine-sessions" / "rollout-global.jsonl"
        global_rollout.parent.mkdir()
        global_rollout.write_text("{}\n", encoding="utf-8")
        unrelated = devlyn / "unrelated.data"
        unrelated.write_text("preserve\n", encoding="utf-8")
        run_id = read_run_id(devlyn)
        assert run_id == "run-1", run_id
        original_session = build_session.read_bytes()
        build_session.write_bytes(original_session + b"altered\n")
        try:
            archive_plan(devlyn, devlyn / "runs" / run_id, state)
        except ArchiveError as exc:
            assert "worker-session digest mismatch" in str(exc)
        else:
            raise AssertionError("archive accepted a mutated invocation worker session")
        build_session.write_bytes(original_session)
        receipt_binding["sandbox_network_access"] = False
        try:
            archive_plan(devlyn, devlyn / "runs" / run_id, state)
        except ArchiveError as exc:
            assert "fields mismatch sealed file" in str(exc)
        else:
            raise AssertionError("archive accepted a falsified invocation receipt binding")
        receipt_binding["sandbox_network_access"] = True

        escape = work / "archive-escape"
        escape.mkdir()
        unsafe_dest = devlyn / "runs" / run_id
        unsafe_dest.mkdir(parents=True)
        unsafe_parent = unsafe_dest / "process-evidence"
        unsafe_parent.symlink_to(escape, target_is_directory=True)
        try:
            move_artifacts(devlyn, unsafe_dest)
        except ArchiveError as exc:
            assert "archive destination parent is unsafe" in str(exc)
        else:
            raise AssertionError("archive followed a symlinked destination parent")
        unsafe_parent.unlink()
        unsafe_dest.rmdir()
        moved = move_artifacts(devlyn, devlyn / "runs" / run_id)
        assert moved >= 12, moved
        for name in (
            "pipeline.state.json",
            "risk-probes.jsonl",
            "goal.raw.txt",
            "surface-close.input.patch",
            "surface-close.prompt",
            "surface-close.output.json",
            "surface-close.stdout",
            "implement.worker-session.0.jsonl",
            "surface-close.worker-session.0.jsonl",
            "build_gate.prompt.1",
            "build_gate.worker-session.1.jsonl",
            "build_gate.invocation.1.json",
            "build_gate.prompt.2",
            "build_gate.worker-session.2.jsonl",
            "cleanup.worker-session.1.jsonl",
            "build_gate.invocation.2.json",
            "plan.prompt.0",
            "plan.worker-session.0.jsonl",
            "plan.invocation.0.json",
            "probes/P1.py",
            "verify.pair.findings.jsonl",
            "verify-merge.summary.json",
            "untracked.baseline",
            "external-diff.patch",
            "plan.task-context",
            "plan.prompt",
            "probe-derive.stdout",
            "probe-derive.stderr",
            "verify.primary.timeout.json",
            "verify.pair.timeout.json",
            "codex-judge.stdout",
            "codex-judge.summary.json",
            "claude-judge.stdout",
            "claude-judge.stderr",
            "implement.task-context",
            "implement.prompt",
            "implement.stdout",
            "implement.stderr",
            "implement.events.jsonl",
            "implement.retry.1.stdout",
            f"process-evidence/{run_id}/verify/round-2/manifest.json",
            f"process-evidence/{run_id}/verify/round-2/mechanical-0.stdout",
            f"process-evidence/{run_id}/verify/round-2/mechanical-0.stderr",
        ):
            assert (devlyn / "runs" / run_id / name).is_file(), name
            assert not (devlyn / name).exists(), name
        assert global_rollout.is_file(), "engine-global session files must stay untouched"
        assert not (devlyn / "runs" / run_id / global_rollout.name).exists()
        assert unrelated.read_text(encoding="utf-8") == "preserve\n"
        assert not (devlyn / "runs" / run_id / unrelated.name).exists()
        assert not (devlyn / "process-evidence" / run_id).exists()

        for label in ("digest", "missing", "unsafe", "unbound", "collision"):
            isolated_work = pathlib.Path(tmp) / f"{label}-work"
            isolated_devlyn = isolated_work / ".devlyn"
            isolated_devlyn.mkdir(parents=True)
            isolated_state = {
                "run_id": f"run-{label}",
                "phases": {"verify": {"round": 0}},
                "process_evidence": None,
            }
            isolated_manifest_rel = runner["manifest_relative_path"](isolated_state, "verify")
            runner["capture_process"](
                isolated_work,
                isolated_work / isolated_manifest_rel,
                isolated_state["run_id"],
                "verify",
                0,
                obligation,
            )
            isolated_state["process_evidence"] = [runner["validate_manifest"](
                isolated_work,
                isolated_manifest_rel,
                isolated_state["run_id"],
                "verify",
                0,
                [obligation],
                require_expectations=False,
            )]
            (isolated_devlyn / "pipeline.state.json").write_text(
                json.dumps(isolated_state) + "\n", encoding="utf-8",
            )
            target = isolated_devlyn / "runs" / isolated_state["run_id"]
            if label == "digest":
                stream = isolated_work / isolated_state["process_evidence"][0]["streams"][0]["stdout"]["path"]
                stream.write_bytes(stream.read_bytes() + b"altered")
            elif label == "missing":
                stream = isolated_work / isolated_state["process_evidence"][0]["streams"][0]["stderr"]["path"]
                stream.unlink()
            elif label == "unsafe":
                isolated_state["process_evidence"][0]["manifest"]["path"] = "../escape/manifest.json"
                (isolated_devlyn / "pipeline.state.json").write_text(
                    json.dumps(isolated_state) + "\n", encoding="utf-8",
                )
            elif label == "unbound":
                extra = isolated_devlyn / "process-evidence" / isolated_state["run_id"] / "verify" / "round-0" / "extra.stdout"
                extra.write_text("not state-bound\n", encoding="utf-8")
            else:
                collision = target / pathlib.PurePosixPath(isolated_manifest_rel).relative_to(".devlyn")
                collision.parent.mkdir(parents=True)
                collision.write_text("occupied\n", encoding="utf-8")
            before = {
                str(path.relative_to(isolated_devlyn)): path.read_bytes()
                for path in isolated_devlyn.rglob("*") if path.is_file()
            }
            try:
                move_artifacts(isolated_devlyn, target)
            except ArchiveError:
                pass
            else:
                raise AssertionError(f"{label} archive violation was accepted")
            after = {
                str(path.relative_to(isolated_devlyn)): path.read_bytes()
                for path in isolated_devlyn.rglob("*") if path.is_file()
            }
            assert after == before, label

        null_states = {
            "run-0-final-report-null": {"phases": {"final_report": None}},
            "run-0-phases-null": {"phases": None},
            "run-0-root-null": None,
        }
        for name, state in null_states.items():
            null_run = devlyn / "runs" / name
            null_run.mkdir()
            (null_run / "pipeline.state.json").write_text(
                json.dumps(state) + "\n",
                encoding="utf-8",
            )
        newest_run = devlyn / "runs" / "run-2"
        newest_run.mkdir()
        (newest_run / "pipeline.state.json").write_text(
            json.dumps({"run_id": "run-2", "phases": {"final_report": {
                "verdict": "PASS", "completed_at": "2026-09-06T00:00:00.123Z",
            }}}) + "\n",
            encoding="utf-8",
        )
        assert prune(devlyn / "runs", keep=1) == 1
        assert all((devlyn / "runs" / name).is_dir() for name in null_states)
        assert not (devlyn / "runs" / run_id).exists(), "oldest completed archive must be pruned"
        assert newest_run.is_dir(), "newest completed archive must remain"

        bad = pathlib.Path(tmp) / "bad"
        bad.mkdir()
        (bad / "pipeline.state.json").write_text('{"run_id": "../escape"}\n', encoding="utf-8")
        try:
            read_run_id(bad)
        except SystemExit as exc:
            assert "run_id must match" in str(exc)
        else:
            raise AssertionError("unsafe archive run_id was accepted")
        blocked_cli = subprocess.run(
            [sys.executable, str(pathlib.Path(__file__).resolve()), "--devlyn-dir", str(bad)],
            capture_output=True,
            text=True,
            encoding="utf-8",
        )
        assert blocked_cli.returncode == 1
        assert "error: archive blocked:" in blocked_cli.stderr
        assert "Traceback" not in blocked_cli.stderr

        nan = pathlib.Path(tmp) / "nan"
        nan.mkdir()
        (nan / "pipeline.state.json").write_text('{"run_id": NaN}\n', encoding="utf-8")
        try:
            read_run_id(nan)
        except SystemExit as exc:
            assert "invalid JSON numeric constant: NaN" in str(exc)
        else:
            raise AssertionError("NaN archive run_id was accepted")
    completion_self_test()
    full_terminal_verdict_completion_self_test()
    return 0


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--devlyn-dir", default=".devlyn")
    ap.add_argument("--keep", type=int, default=10, help="keep N most recent completed runs")
    ap.add_argument("--self-test", action="store_true")
    args = ap.parse_args()
    if args.self_test:
        return self_test()

    devlyn = pathlib.Path(args.devlyn_dir)
    if not devlyn.is_dir():
        sys.stderr.write(f"error: {devlyn} is not a directory\n")
        return 1

    try:
        state = read_state(devlyn)
        run_id = state["run_id"]
        dest = devlyn / "runs" / run_id
        moved = move_artifacts(devlyn, dest)
        pruned = prune(devlyn / "runs", keep=args.keep)
    except (ArchiveError, OSError, UnicodeError, ValueError) as exc:
        sys.stderr.write(f"error: archive blocked: {exc}\n")
        return 1

    sys.stdout.write(f"archived run_id={run_id} files={moved} pruned={pruned}\n")
    return 0


if __name__ == "__main__":
    runpy.run_path(str(pathlib.Path(__file__).with_name("platform-support.py")))["configure_utf8"]()
    raise SystemExit(main())
