#!/usr/bin/env bash
# codex-monitored.sh — run `codex exec` in a monitored shape that keeps the
# outer claude -p API stream from going silent during long Codex calls.
#
# WHY (iter-0009, post iter-0006/0007/0008):
#   • iter-0007 isolation proved a single foreground `codex exec` Bash dispatch
#     can starve the outer API stream of bytes during a 10+ min run; Anthropic's
#     byte-level idle watchdog fires (~300s) and kills the orchestrator.
#   • iter-0008 saw the orchestrator pick `codex exec ... 2>&1 | tail -200` from
#     its own pattern prior — `tail` on a pipe buffers until EOF, suppressing
#     ALL bytes. Same starvation, amplified.
#   • iter-0008 also documented codex 0.124.0 reads stdin as a `<stdin>` block
#     when the prompt is passed as an arg AND stdin is open; without
#     `< /dev/null` the call hangs indefinitely.
#
# WHAT THIS WRAPPER DOES:
#   1. Refuses to run if stdout is a pipe. Piping wrapper output to text tools
#      (tail/head/awk/sed/grep without --line-buffered) re-introduces the
#      iter-0008 starvation mechanism — the downstream tool buffers until EOF
#      and the outer claude -p byte-watchdog never sees bytes. Exits 64 with a
#      clear message so the orchestrator can self-correct on retry.
#      (Round 2 finding #1 fix: shim alone does not defeat `| tail`; the
#      wrapper must reject the pipe shape directly.)
#   2. Closes stdin unless DEVLYN_CODEX_PROMPT_FILE supplies the sole prompt.
#   3. Streams codex stdout to OUR stdout line-by-line — the orchestrator reads
#      stdout as the subagent reply (per `_shared/codex-config.md`) so we MUST
#      NOT swallow it (e.g. `tail -n 200`). codex stderr forwards to OUR stderr.
#   4. Emits a `[codex-monitored] heartbeat` line every CODEX_MONITORED_HEARTBEAT
#      seconds (default 30s) on STDERR while codex is alive. Heartbeat-on-stderr
#      keeps the orchestrator's combined-output stream non-silent without
#      polluting the codex-reply view of stdout.
#   5. Forwards SIGTERM/SIGINT from the outer watchdog to the codex child so a
#      timeout actually reaps codex (otherwise process group kill races with
#      backgrounded codex).
#   6. Preserves codex's exact exit code.
#
# USAGE:
#   bash codex-monitored.sh -C <repo> -s read-only -c model_reasoning_effort=xhigh "<prompt>"
#   bash codex-monitored.sh resume --last
#   (Args after the script name are passed verbatim to `codex exec`.)
#
# ENV OVERRIDES:
#   CODEX_MONITORED_HEARTBEAT      — heartbeat interval seconds (default 30).
#   CODEX_MONITORED_TIMEOUT_SEC    — optional hard timeout. When >0, kill the
#                                     codex process group and exit 124.
#   CODEX_BIN                      — real codex binary path. Default:
#                                     CODEX_REAL_BIN when set, else `codex`.
#                                     Set this when the shim has put us first
#                                     on PATH.
#   CODEX_MONITORED_ISOLATED       — set non-empty for bounded read-only
#                                     probe/judge calls that must ignore
#                                     user config, project rules, session
#                                     persistence, and hook side effects.
#   CODEX_MONITORED_ALLOW_PIPED    — set non-empty to skip the pipe-stdout
#                                     refusal. Reserved for tests; don't use
#                                     in skill prompts.
#   DEVLYN_CODEX_PROMPT_FILE      — exact binary stdin prompt; requires sole `-`.
#   DEVLYN_INVOCATION_*             — run/phase/round/workdir/prompt/session/
#                                     receipt identity. When any is set, all
#                                     are required and the wrapper seals a
#                                     canonical invocation receipt.

set -uo pipefail

# iter-0019 — solo_claude (L1) arm enforcement (defense in depth alongside
# scripts/codex-shim/codex). If this env is set, the wrapper refuses to invoke
# codex at all, regardless of how it was reached. Two enforcement points
# protect against the case where one is bypassed: the shim catches PATH-based
# resolution, and this wrapper catches direct-path invocations of
# codex-monitored.sh that don't go through the shim.
if [ -n "${CODEX_BLOCKED:-}" ]; then
  printf '[codex-monitored] CODEX_BLOCKED=%s — refusing codex invocation (solo_claude / L1 arm enforcement). args: %s\n' \
    "${CODEX_BLOCKED}" "$*" >&2
  exit 126
fi

HEARTBEAT_SEC="${CODEX_MONITORED_HEARTBEAT:-30}"
TIMEOUT_SEC="${CODEX_MONITORED_TIMEOUT_SEC:-0}"
CODEX_BIN="${CODEX_BIN:-${CODEX_REAL_BIN:-codex}}"
START=$(date +%s)
TIMEOUT_FLAG=""
CODEX_ARGS=("$@")

for codex_arg in "${CODEX_ARGS[@]}"; do
  case "$codex_arg" in
    --dangerously-bypass-approvals-and-sandbox|--yolo)
      printf '[codex-monitored] error: forbidden Codex bypass flag: %s\n' "$codex_arg" >&2
      exit 64
      ;;
    danger-full-access|-s=danger-full-access|--sandbox=danger-full-access)
      printf '[codex-monitored] error: forbidden Codex sandbox: danger-full-access\n' >&2
      exit 64
      ;;
  esac
done

require_nonnegative_int() {
  local name="$1"
  local value="$2"
  case "$value" in
    ''|*[!0-9]*)
      printf '[codex-monitored] error: %s must be a non-negative integer (got %s)\n' \
        "$name" "$value" >&2
      exit 64
      ;;
  esac
}

require_positive_int() {
  local name="$1"
  local value="$2"
  require_nonnegative_int "$name" "$value"
  if [ "$value" -le 0 ]; then
    printf '[codex-monitored] error: %s must be > 0 (got %s)\n' \
      "$name" "$value" >&2
    exit 64
  fi
}

require_positive_int CODEX_MONITORED_HEARTBEAT "$HEARTBEAT_SEC"
require_nonnegative_int CODEX_MONITORED_TIMEOUT_SEC "$TIMEOUT_SEC"

RECEIPT_ENABLED=""
for receipt_value in \
  "${DEVLYN_INVOCATION_RUN_ID:-}" \
  "${DEVLYN_INVOCATION_PHASE:-}" \
  "${DEVLYN_INVOCATION_ROUND:-}" \
  "${DEVLYN_INVOCATION_WORKDIR:-}" \
  "${DEVLYN_INVOCATION_PROMPT_FILE:-}" \
  "${DEVLYN_INVOCATION_SESSION_FILE:-}" \
  "${DEVLYN_INVOCATION_RECEIPT:-}"; do
  if [ -n "$receipt_value" ]; then
    RECEIPT_ENABLED=1
  fi
done
if [ -n "$RECEIPT_ENABLED" ]; then
  for receipt_name in \
    DEVLYN_INVOCATION_RUN_ID DEVLYN_INVOCATION_PHASE DEVLYN_INVOCATION_ROUND \
    DEVLYN_INVOCATION_WORKDIR DEVLYN_INVOCATION_PROMPT_FILE \
    DEVLYN_INVOCATION_SESSION_FILE DEVLYN_INVOCATION_RECEIPT; do
    eval "receipt_value=\${$receipt_name:-}"
    if [ -z "$receipt_value" ]; then
      printf '[codex-monitored] error: %s is required for invocation receipt\n' \
        "$receipt_name" >&2
      exit 64
    fi
  done
  require_nonnegative_int DEVLYN_INVOCATION_ROUND "$DEVLYN_INVOCATION_ROUND"
fi

if [ -n "${CODEX_MONITORED_ISOLATED:-}" ]; then
  CODEX_ARGS=(
    --ignore-user-config
    --ignore-rules
    --ephemeral
    --disable codex_hooks
    --disable hooks
    "${CODEX_ARGS[@]}"
  )
fi

# --- Pipe-stdout refusal (iter-0009 R2 finding #1) -------------------------
# `[ -p /dev/stdout ]` is the POSIX test for "is fd 1 a FIFO/pipe". Verified
# correct on macOS via lsof: distinguishes piped (`| cat`) from redirected
# (`> file`) and from claude-bash-tool capture (regular file). Without this
# refusal, `bash WRAPPER ... 2>&1 | tail -200` would buffer wrapper output —
# including the heartbeat on stderr after `2>&1` — until EOF, reproducing
# the iter-0008 byte-watchdog kill.
if [ -z "${CODEX_MONITORED_ALLOW_PIPED:-}" ] && [ -p /dev/stdout ]; then
  cat >&2 <<'EOF'
[codex-monitored] error: stdout is a pipe.

Piping the wrapper to tail/head/awk/sed/grep buffers wrapper output until EOF,
which starves the outer claude -p byte-watchdog (iter-0008 starvation mechanism)
and kills the run after ~300s with empty transcript.

Fix: invoke the wrapper directly so the bash tool captures its stdout. The
wrapper streams full Codex output and emits a heartbeat on stderr; you do NOT
need to truncate.

  WRONG: bash codex-monitored.sh ... 2>&1 | tail -200
  RIGHT: bash codex-monitored.sh ...

If you absolutely must filter, use a line-buffered tool (e.g. `grep --line-buffered`)
and set CODEX_MONITORED_ALLOW_PIPED=1 in the wrapper's environment.
EOF
  exit 64
fi

# --- Heartbeat + signal forwarding ----------------------------------------
heartbeat_loop() {
  local pid="$1"
  while kill -0 "$pid" 2>/dev/null; do
    sleep "$HEARTBEAT_SEC"
    if kill -0 "$pid" 2>/dev/null; then
      local elapsed=$(( $(date +%s) - START ))
      printf '[codex-monitored] heartbeat: elapsed=%ds\n' "$elapsed" >&2
    fi
  done
}

timeout_loop() {
  local pid="$1"
  local seconds="$2"
  local flag="$3"
  [ "$seconds" -gt 0 ] || return 0
  sleep "$seconds"
  if kill -0 "$pid" 2>/dev/null; then
    : > "$flag"
    printf '[codex-monitored] timeout: elapsed=%ds limit=%ds\n' \
      "$(( $(date +%s) - START ))" "$seconds" >&2
    kill -TERM -- "-$pid" 2>/dev/null || kill -TERM "$pid" 2>/dev/null || true
    sleep 5
    kill -KILL -- "-$pid" 2>/dev/null || kill -KILL "$pid" 2>/dev/null || true
  fi
}

terminate_process_group() {
  local pgid="$1"
  local reason="$2"
  if ! kill -0 -- "-$pgid" 2>/dev/null; then
    return 0
  fi
  printf '[codex-monitored] reap: reason=%s pgid=%s\n' "$reason" "$pgid" >&2
  kill -TERM -- "-$pgid" 2>/dev/null || true
  local i
  for i in 1 2 3 4 5; do
    sleep 1
    if ! kill -0 -- "-$pgid" 2>/dev/null; then
      return 0
    fi
  done
  kill -KILL -- "-$pgid" 2>/dev/null || true
}

terminate_monitor_group() {
  local pid="$1"
  kill -TERM -- "-$pid" 2>/dev/null || kill -TERM "$pid" 2>/dev/null || true
  kill -KILL -- "-$pid" 2>/dev/null || kill -KILL "$pid" 2>/dev/null || true
  wait "$pid" 2>/dev/null || true
}

forward_signal() {
  local sig="$1"
  if [ -n "${CODEX_PID:-}" ] && kill -0 "$CODEX_PID" 2>/dev/null; then
    kill -"$sig" -- "-$CODEX_PID" 2>/dev/null || kill -"$sig" "$CODEX_PID" 2>/dev/null || true
  fi
  if [ -n "${HB_PID:-}" ]; then
    terminate_monitor_group "$HB_PID"
    HB_PID=""
  fi
  if [ -n "${WATCHDOG_PID:-}" ]; then
    terminate_monitor_group "$WATCHDOG_PID"
    WATCHDOG_PID=""
  fi
}

cleanup() {
  forward_signal TERM
  [ -z "$TIMEOUT_FLAG" ] || rm -f "$TIMEOUT_FLAG"
}

trap 'forward_signal TERM; exit 143' TERM
trap 'forward_signal INT; exit 130' INT
trap cleanup EXIT

printf '[codex-monitored] start: ts=%s heartbeat=%ds timeout=%ss bin=%s\n' \
  "$(date -u +%FT%TZ)" "$HEARTBEAT_SEC" "$TIMEOUT_SEC" "$CODEX_BIN" >&2
if [ -n "${CODEX_MONITORED_ISOLATED:-}" ]; then
  printf '[codex-monitored] isolated=1\n' >&2
fi

RECEIPT_HELPER="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/invocation-receipt.py"
# Native Python owns Windows PIDs and the timeout tree; MSYS PIDs are different.
if [ "${OS:-}" = Windows_NT ]; then
  exec python3 "$RECEIPT_HELPER" dispatch --binary "$CODEX_BIN" \
    --timeout "$TIMEOUT_SEC" --heartbeat "$HEARTBEAT_SEC" -- "${CODEX_ARGS[@]}" < /dev/null
fi

# The dispatcher snapshots file input, seals actual argv, then execs in this group.
set -m
python3 "$RECEIPT_HELPER" dispatch --binary "$CODEX_BIN" \
  --timeout "$TIMEOUT_SEC" --heartbeat "$HEARTBEAT_SEC" -- "${CODEX_ARGS[@]}" < /dev/null &
CODEX_PID=$!
printf '[codex-monitored] codex pid=%d\n' "$CODEX_PID" >&2

heartbeat_loop "$CODEX_PID" &
HB_PID=$!

if [ "$TIMEOUT_SEC" -gt 0 ]; then
  TIMEOUT_FLAG=$(mktemp "${TMPDIR:-/tmp}/codex-monitored-timeout.XXXXXX")
  rm -f "$TIMEOUT_FLAG"
  timeout_loop "$CODEX_PID" "$TIMEOUT_SEC" "$TIMEOUT_FLAG" &
  WATCHDOG_PID=$!
fi
set +m

wait "$CODEX_PID"
EXIT=$?
terminate_process_group "$CODEX_PID" "post-exit-descendants"
CODEX_PID=""
forward_signal TERM
if [ -n "$TIMEOUT_FLAG" ] && [ -f "$TIMEOUT_FLAG" ]; then
  EXIT=124
fi

if [ -n "$RECEIPT_ENABLED" ] || [ -n "${DEVLYN_CODEX_PROMPT_FILE:-}" ]; then
  python3 "$RECEIPT_HELPER" complete-dispatch --exit-code "$EXIT" || exit 64
fi

printf '[codex-monitored] codex exited: code=%d elapsed=%ds\n' \
  "$EXIT" $(( $(date +%s) - START )) >&2
exit "$EXIT"
