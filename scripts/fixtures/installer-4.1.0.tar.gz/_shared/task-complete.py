#!/usr/bin/env python3
"""Outer-owner delivery and recoverable cleanup (task-completion spec, R1–7).

No phase/state writer, staging, scheduler, or implicit adoption. See
devlyn-resolve/references/task-completion.md for the owner acceptance contract.
"""
from __future__ import annotations

import argparse
import contextlib
import functools
import hashlib
import json
import os
from pathlib import Path
import re
import runpy
import shlex
import shutil
import stat
import subprocess
import sys
import tempfile
import unittest


class CompletionError(Exception):
    pass


def require(condition, message):
    if not condition:
        raise CompletionError(message)


def command(argv, *, cwd=None, ok=(0,)):
    result = subprocess.run(argv, cwd=cwd, capture_output=True, text=True, encoding="utf-8")
    require(result.returncode in ok, f"{shlex.join(argv[:4])}: {result.stderr.strip() or result.stdout.strip()}")
    return result.stdout.removesuffix("\n")


def git(work, *args):
    return command(["git", "-C", str(work), *args])


@functools.lru_cache(maxsize=None)
def shared(name):
    return runpy.run_path(str(Path(__file__).with_name(name + ".py")))


def read_json(path):
    require(stat.S_ISREG(path.lstat().st_mode), f"JSON must be a nonsymlink regular file: {path}")
    return shared("archive_run")["loads_strict_json"](path.read_text(encoding="utf-8"))


def atomic_json(path, value):
    fd, temporary = tempfile.mkstemp(dir=path.parent, prefix=".receipt-")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as stream:
            json.dump(value, stream, sort_keys=True, indent=2)
            stream.write("\n")
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
        if os.name != "nt":
            directory = os.open(path.parent, os.O_RDONLY)
            try:
                os.fsync(directory)
            finally:
                os.close(directory)
    finally:
        Path(temporary).unlink(missing_ok=True)


def safe_path(root, relative):
    require(root == root.resolve(), f"custody/workspace root traverses a symlink: {root}")
    p = Path(relative)
    require(not p.is_absolute() and p.parts and ".." not in p.parts, f"unsafe relative path: {relative}")
    result = root / p
    require(result.resolve().is_relative_to(root.resolve()), f"path escapes custody: {relative}")
    for ancestor in [result, *result.parents]:
        if ancestor == root:
            break
        require(not ancestor.is_symlink(), f"symlink is not owned evidence: {relative}")
    return result


def file_record(path):
    mode = path.lstat().st_mode
    require(stat.S_ISREG(mode), f"evidence is not a regular file: {path}")
    raw = path.read_bytes()
    return {"sha256": hashlib.sha256(raw).hexdigest(), "bytes": len(raw), "mode": stat.S_IMODE(mode)}


def snapshot_files(root, paths):
    result = {}
    for relative in paths:
        p = safe_path(root, relative)
        if p.is_dir():
            for child in sorted(p.rglob("*")):
                rel = str(child.relative_to(root))
                safe_path(root, rel)
                if not child.is_dir():
                    result[rel] = file_record(child)
        else:
            result[str(Path(relative))] = file_record(p)
    require(result, "acceptance has no evidence files")
    return result


def verify_files(root, files):
    for relative, expected in files.items():
        require(file_record(safe_path(root, relative)) == expected, f"evidence bytes/mode changed: {relative}")


def custody(work, destination, files):
    destination.mkdir(exist_ok=True)
    for relative, expected in files.items():
        source = safe_path(work, relative)
        target = safe_path(destination, relative)
        target.parent.mkdir(parents=True, exist_ok=True)
        if not target.exists():
            # Interrupted partial copies are diagnosed, never silently overwritten.
            with source.open("rb") as incoming, target.open("xb") as outgoing:
                shutil.copyfileobj(incoming, outgoing)
                outgoing.flush()
                os.fsync(outgoing.fileno())
            target.chmod(expected["mode"])
        require(file_record(target) == expected, f"custody copy mismatch; retain original: {relative}")
    verify_files(work, files)
    verify_files(destination, files)
    atomic_json(destination.parent / "manifest.json", files)


def gref(receipt, *args):
    return command(["git", "--git-dir", receipt["common_gitdir"], *args])


def ref_sha(receipt, ref):
    return command(["git", "--git-dir", receipt["common_gitdir"], "rev-parse", "--verify", "--quiet", ref], ok=(0, 1)) or None


def registrations(receipt):
    rows = {}
    for raw in gref(receipt, "worktree", "list", "--porcelain", "-z").split("\0\0"):
        row = dict(field.partition(" ")[::2] for field in raw.split("\0") if field)
        if "worktree" in row:
            rows[str(Path(row["worktree"]).resolve())] = row
    return rows


def remote_url(receipt):
    values = [gref(receipt, "remote", "get-url", "--all", receipt["remote"]),
              gref(receipt, "remote", "get-url", "--push", "--all", receipt["remote"])]
    # --get-url expands insteadOf; compare the stored literal remote config as
    # well, while preserving Git's normal transport configuration.
    literal = gref(receipt, "config", "--get-all", "remote." + receipt["remote"] + ".url")
    urls = {"literal": literal, "fetch": values[0], "push": values[1]}
    require(all(repository_from_url(url).lower() == receipt["repository"].lower() for url in urls.values()), "repository differs from remote")
    return urls


def repository_from_url(url):
    match = re.fullmatch(r"(?:https://github\.com/|git@github\.com:|ssh://git@github\.com/)([A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+?)(?:\.git)?", url)
    require(match is not None, "remote must unambiguously identify one GitHub repository")
    return match.group(1)


def policy(receipt, override):
    config = subprocess.run(["git", "--git-dir", receipt["common_gitdir"], "config", "--local", "--get-all", "devlyn.completionMode"], capture_output=True, text=True, encoding="utf-8")
    require(config.returncode in {0, 1}, "cannot read local completion policy: " + config.stderr.strip())
    require(config.returncode == 1 or config.stdout in {"auto\n", "pr\n"}, "invalid local devlyn.completionMode; use auto|pr")
    value = config.stdout.strip() if config.returncode == 0 else None
    require(override is None or override in {"auto", "pr"}, "invalid task mode; use auto|pr")
    return override or value or "auto"


def allocate(args):
    work = Path(git(Path(args.repo).resolve(), "rev-parse", "--show-toplevel")).resolve()
    common = Path(git(work, "rev-parse", "--path-format=absolute", "--git-common-dir")).resolve()
    require(args.task.strip(), "task identity is required")
    git(work, "check-ref-format", "refs/heads/" + args.branch)
    git(work, "check-ref-format", "refs/heads/" + args.base)
    require(args.branch != args.base and args.branch not in {"main", "master"}, "cannot own a base/default branch")
    require(re.fullmatch(r"[A-Za-z0-9_.-]+", args.remote), "unsafe remote name")
    receipt = {"task": args.task, "repository": args.repository, "remote": args.remote,
               "base": args.base, "branch": args.branch, "common_gitdir": str(common),
               "anchor": str(work), "linked": True, "allocation": "allocating"}
    policy(receipt, None)
    receipt["remote_url"] = remote_url(receipt)
    require("\n" not in receipt["remote_url"]["push"] and receipt["remote_url"]["push"] == receipt["remote_url"]["fetch"], "split/multiple remote URLs are unsupported")
    require(not ref_sha(receipt, "refs/heads/"+args.branch), "existing branch cannot be adopted")
    receipt["baseline"] = remote_base(receipt)
    target = Path(args.worktree).absolute()
    require(target == target.resolve(), "worktree path must not traverse symlinks")
    require(not target.exists() and all(not target.is_relative_to(p) and not p.is_relative_to(target) for p in map(Path, registrations(receipt))), "linked worktree must be an absent path disjoint from every registered worktree")
    receipt["worktree"] = str(target)
    key = hashlib.sha256(args.branch.encode()).hexdigest()[:24]
    directory = common / "devlyn-completion" / key
    directory.mkdir(parents=True, exist_ok=False)
    path = directory / "receipt.json"
    receipt["id"] = key
    receipt["recovery_ref"] = "refs/devlyn/completed/" + key
    scratch = directory / "scratch"
    scratch.mkdir()
    receipt["scratch_identity"] = workspace_identity(scratch, directory)
    # Persist prospective intent BEFORE native creation. An interrupted allocation
    # stays visibly incomplete; a later call may not adopt whatever now exists.
    atomic_json(path, receipt)
    gref(receipt, "worktree", "add", "-b", args.branch, str(target), receipt["baseline"])
    receipt["worktree_gitdir"] = git(target, "rev-parse", "--absolute-git-dir")
    receipt["worktree_identity"] = workspace_identity(target, Path(receipt["worktree_gitdir"]))
    receipt["allocation"] = "owned"
    atomic_json(path, receipt)
    return {"status": "ALLOCATED", "receipt": str(path), "worktree": str(target), "scratch": str(scratch),
            "reconciled": reconcile(common, path, work)}


def pipeline_acceptance(work, acceptance, files, directory):
    run_id = acceptance["run_id"]
    require(re.fullmatch(r"[A-Za-z0-9_.-]+", run_id) and run_id not in {".", ".."}, "invalid intended run id")
    archive = safe_path(work, ".devlyn/runs/" + run_id)
    state_file = archive / "pipeline.state.json"
    classifier = shared("terminal-claim-check")
    classification, state = classifier["classify_state_bytes"](work, state_file, state_file.read_bytes(), archived=True)
    require(classification.status == "CLEAN" and state["run_id"] == run_id, "intended archive is not terminal CLEAN")
    require(state.get("mode") in {"spec", "free-form"}, "only normal archived runs may publish")
    require((state.get("source") or {}).get("type") in {"spec", "generated"}, "normal archive must bind its source contract")
    phases = state["phases"]
    success = {"PASS", "PASS_WITH_ISSUES"}
    verify = phases.get("verify") or {}
    final = phases.get("final_report") or {}
    require(verify.get("verdict") in success and final.get("verdict") == verify["verdict"], "archive did not finish successfully")
    require(not any(str((phase or {}).get("verdict", "")).startswith("BLOCKED") for phase in phases.values()), "blocked phase takes terminal precedence")
    for name in ("plan", "implement", "cleanup", "verify", "final_report", "build_gate"):
        if name == "build_gate" and "build-gate" in (state.get("bypasses") or []):
            continue
        phase = phases.get(name) or {}
        require(phase.get("completed_at") and phase.get("verdict") in success, f"required {name} evidence is incomplete")
    require(phases["cleanup"].get("post_sha") == acceptance["source_sha"], "accepted source must equal cleanup.post_sha")
    report_digest = shared("state-phase-write")["final_report_digest"](state, archive, str(archive / "final-report.md"))
    require(final.get("output_sha256") == report_digest and final.get("artifacts", {}).get("log_file") == ".devlyn/final-report.md", "final report binding mismatch")
    finish = read_json(archive / "finish-gate.summary.json")
    require(finish.get("mode") == state["mode"] and finish.get("exit") == 0 and finish.get("offenders") == 0 and not finish.get("skipped") and not finish.get("malformed"), "finish gate was not clean")
    require(read_json(archive / "verify-merge.summary.json").get("verdict") == verify["verdict"], "VERIFY summary disagrees with terminal result")
    # Existing evidence validators expect the pre-archive .devlyn layout. Rebuild
    # it in a temporary directory; never move or mutate the original archive.
    with tempfile.TemporaryDirectory(prefix="validate-", dir=directory) as tmp:
        reconstructed = Path(tmp)
        devlyn = reconstructed / ".devlyn"
        devlyn.mkdir()
        prefix = f".devlyn/runs/{run_id}/"
        for rel in files:
            if rel.startswith(prefix):
                dest = safe_path(devlyn, rel[len(prefix):])
                dest.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(safe_path(work, rel), dest)
        archive_module = shared("archive_run")
        try:
            for validator in ("dynamic_evidence_artifacts", "dynamic_invocation_artifacts", "dynamic_judge_role_artifacts"):
                archive_module[validator](devlyn, state)
        except archive_module["ArchiveError"] as exc:
            raise CompletionError(str(exc)) from exc
        evidence_module = shared("process-evidence")
        for carrier in state.get("process_evidence") or []:
            if carrier["round"] == (phases.get(carrier["phase"]) or {}).get("round"):
                require(evidence_module["bound_carrier_outcome"](reconstructed, carrier)["verdict"] == "PASS", "required process evidence failed")
        source = state.get("source") or {}
        if source.get("spec_path"):
            expected = Path(source["spec_path"]).with_name("spec.expected.json")
            original = safe_path(work, str(expected))
            if original.exists():
                dest = safe_path(reconstructed, str(expected))
                dest.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(original, dest)
                for phase in ("implement", "build_gate", "verify"):
                    obligations = evidence_module["declared_obligations"](reconstructed, state, phase)
                    if obligations:
                        carriers = [c for c in state.get("process_evidence") or [] if c.get("phase") == phase and c.get("round") == (phases.get(phase) or {}).get("round")]
                        require(len(carriers) == 1, f"missing/ambiguous current {phase} process evidence")
                        carrier = carriers[0]
                        evidence_module["validate_manifest"](reconstructed, carrier["manifest"]["path"], run_id, phase, carrier["round"], obligations)
        if evidence_module["mechanical_evidence_required"](reconstructed, state):
            require((devlyn / "spec-verify.results.json").is_file(), "required MECHANICAL results are missing")
        carrier = shared("verify-merge-findings")["mechanical_evidence_carrier"](devlyn)
        if carrier:
            require(evidence_module["bound_carrier_outcome"](reconstructed, carrier)["verdict"] == "PASS", "MECHANICAL checks did not pass")


def bind_acceptance(receipt, path, supplied):
    work = Path(receipt["worktree"])
    if receipt.get("acceptance"):
        if supplied:
            require(file_record(Path(supplied))["sha256"] == receipt["acceptance_digest"], "acceptance changed; resume with the original acceptance")
        verify_files(path.parent / "custody", receipt["files"])
        return
    require(supplied, "first completion requires explicit root acceptance")
    acceptance_path = Path(supplied).absolute()
    require(acceptance_path.is_relative_to(work), "acceptance must be a regular file in its task checkout")
    safe_path(work, str(acceptance_path.relative_to(work)))
    acceptance = read_json(acceptance_path)
    require(acceptance.get("task") == receipt["task"], "acceptance belongs to another task")
    sha = acceptance.get("source_sha")
    require(isinstance(sha, str) and re.fullmatch(r"[0-9a-f]{40,64}", sha), "acceptance must name an exact commit")
    require(gref(receipt, "rev-parse", sha+"^{commit}") == sha, "source is not a commit")
    gref(receipt, "merge-base", "--is-ancestor", receipt["baseline"], sha)
    publish = sha
    queue = acceptance.get("queue")
    if queue:
        publish = queue["commit"]
        safe_path(work, queue["file"])
        require(gref(receipt, "rev-list", "--parents", "-n", "1", publish).split() == [publish, sha], "queue commit must be directly atop verified source with one parent")
        require(gref(receipt, "diff-tree", "--no-commit-id", "--name-only", "-r", "-z", publish).strip("\0") == queue["file"], "queue commit must change exactly the declared queue file")
    require(ref_sha(receipt, "refs/heads/"+receipt["branch"]) == publish and git(work, "rev-parse", "HEAD") == publish, "unverified source delta or changed task ref")
    paths = [str(acceptance_path.relative_to(work))]
    kind = acceptance.get("kind")
    if kind == "direct":
        checks = acceptance.get("checks")
        require(isinstance(checks, list) and checks, "direct acceptance must name actual root-accepted checks")
        for check in checks:
            require(isinstance(check.get("command"), str) and check["command"].strip(), "direct check must name its command")
            paths.append(check["evidence"])
    elif kind == "pipeline":
        paths.append(".devlyn/runs/" + acceptance["run_id"])
        state = read_json(safe_path(work, paths[-1]) / "pipeline.state.json")
        source = state.get("source") or {}
        for key in ("spec_path", "criteria_path"):
            if source.get(key):
                if key == "criteria_path" and source.get("type") == "generated":
                    require(source[key] == ".devlyn/criteria.generated.md", "generated criteria path is not canonical")
                    relative = f".devlyn/runs/{acceptance['run_id']}/criteria.generated.md"
                else:
                    relative = source[key]
                paths.append(relative)
                source_file = safe_path(work, relative)
                if relative == source[key]:
                    committed = subprocess.run(["git", "--git-dir", receipt["common_gitdir"], "show", sha+":"+relative], capture_output=True)
                    require(committed.returncode == 0 and committed.stdout == source_file.read_bytes(), "source contract changed since accepted commit")
                bound_digest = source.get(key.replace("_path", "_sha256"))
                require(file_record(source_file)["sha256"] == bound_digest, "source contract differs from run binding")
                source_path = Path(source[key])
                expected = str(source_path.with_name("spec.expected.json") if key == "spec_path" else source_path.with_suffix(".expected.json"))
                if safe_path(work, expected).exists():
                    paths.append(expected)
    else:
        raise CompletionError("acceptance kind must be direct|pipeline")
    files = snapshot_files(work, paths)
    if kind == "pipeline":
        pipeline_acceptance(work, acceptance, files, path.parent)
    custody(work, path.parent / "custody", files)
    recovery = ref_sha(receipt, receipt["recovery_ref"])
    require(recovery in {None, publish}, "recovery ref changed")
    if recovery is None:
        gref(receipt, "update-ref", receipt["recovery_ref"], publish, "0"*len(publish))
    receipt.update(acceptance=acceptance, acceptance_digest=file_record(acceptance_path)["sha256"], source_sha=sha, publish_sha=publish, files=files)
    atomic_json(path, receipt)


PR_FIELDS = "number,url,headRefName,baseRefName,headRefOid,headRepository,headRepositoryOwner,isCrossRepository,state,mergedAt,mergeCommit,autoMergeRequest"


def gh(receipt, *args):
    return command(["gh", *args, "--repo", "github.com/"+receipt["repository"]])


def repo_policy(receipt):
    info = json.loads(command(["gh", "repo", "view", "github.com/"+receipt["repository"], "--json", "nameWithOwner,url,defaultBranchRef,mergeCommitAllowed"]))
    require(info["nameWithOwner"].lower() == receipt["repository"].lower() and info["url"].lower() == "https://github.com/"+receipt["repository"].lower(), "GitHub repository identity changed")
    require(info["defaultBranchRef"]["name"] == receipt["base"] and receipt["branch"] != info["defaultBranchRef"]["name"], "base/default branch changed; retain resources")
    return info


def remote_base(receipt):
    # Never write FETCH_HEAD: a concurrent `git pull` in the anchor would merge ours.
    tracking = "refs/remotes/" + receipt["remote"] + "/" + receipt["base"]
    gref(receipt, "fetch", "--no-tags", "--no-write-fetch-head", receipt["remote"], "+refs/heads/" + receipt["base"] + ":" + tracking)
    return gref(receipt, "rev-parse", "--verify", tracking)


def remote_head(receipt, branch):
    rows = gref(receipt, "ls-remote", "--heads", receipt["remote"], "refs/heads/"+branch).splitlines()
    require(len(rows) <= 1, "ambiguous remote ref")
    return rows[0].split()[0] if rows else None


def validate_pr(receipt, pr):
    owner, name = receipt["repository"].split("/")
    require(pr["url"].lower() == f"https://github.com/{receipt['repository']}/pull/{pr['number']}".lower(), "PR repository mismatch")
    require(pr["headRefName"] == receipt["branch"] and pr["baseRefName"] == receipt["base"] and pr["headRefOid"] == receipt["publish_sha"], "PR head/base/commit changed")
    require(not pr["isCrossRepository"] and pr["headRepository"]["name"].lower() == name.lower() and pr["headRepositoryOwner"]["login"].lower() == owner.lower(), "PR head repository differs")
    require(pr["state"] in {"OPEN", "MERGED"}, "PR is closed without merge; retain task")


def workspace_identity(work, gitdir):
    return [[p.stat().st_dev, p.stat().st_ino] for p in (work, gitdir)]


def inspect_workspace(receipt):
    work = Path(receipt["worktree"])
    row = registrations(receipt).get(str(work))
    require(row and "locked" not in row and "prunable" not in row and "detached" not in row, "worktree missing, detached or locked; retain and inspect registration")
    expected = "refs/heads/" + receipt["branch"]
    require(row.get("branch") == expected, "foreign worktree branch; retain workspace")
    require(git(work, "rev-parse", "--absolute-git-dir") == receipt["worktree_gitdir"] and str(Path(git(work, "rev-parse", "--path-format=absolute", "--git-common-dir")).resolve()) == receipt["common_gitdir"], "worktree Gitdir ownership changed")
    require(workspace_identity(work, Path(receipt["worktree_gitdir"])) == receipt["worktree_identity"], "worktree/registration was replaced; receipt no longer owns it")
    require(git(work, "rev-parse", "HEAD") == receipt.get("publish_sha", receipt["baseline"]), "task HEAD changed")
    require(not git(work, "status", "--porcelain", "--untracked-files=all"), "dirty/untracked workspace; retain files and commit only accepted scope")


def outside(work):
    require(not Path.cwd().resolve().is_relative_to(work), "caller cwd is inside removable worktree; yield it and resume from outside")
    require(not Path(__file__).resolve().is_relative_to(work), "invoke the installed helper outside the removable worktree so resume remains available")


def removable(receipt, work):
    inspect_workspace(receipt)
    verify_files(work, receipt["files"])
    # Git lists a nested repository or worktree under an ignored path as `dir/`;
    # native removal would delete it with its uncommitted work.
    nested = [p for p in git(work, "ls-files", "--others", "--ignored", "--exclude-standard", "-z").split("\0") if p.endswith("/")]
    require(not nested, "nested repository or worktree inside the task tree: " + ", ".join(nested) + "; retain")
    stopped_writers(work)


def stopped_writers(work):
    outside(work)
    # The owner assertion covers its actual children; an OS observation catches
    # other currently open files/cwds, not future writers or a universal lease.
    if sys.platform == "darwin":
        result = subprocess.run(["lsof", "-Fpn", "+D", str(work)], capture_output=True, text=True, encoding="utf-8")
        require(result.returncode in {0, 1} and not result.stderr.strip(), "writer observation unavailable; retain tree and inspect writers")
        pid = None
        for line in result.stdout.splitlines():
            if line.startswith("p"):
                pid = int(line[1:])
            elif line.startswith("n") and pid != os.getpid():
                raise CompletionError(f"active process {pid} uses task files; stop/yield actual writers before resume")
    elif sys.platform.startswith("linux"):
        for process in Path("/proc").iterdir():
            if not process.name.isdigit() or int(process.name) == os.getpid():
                continue
            try:
                links = [process / "cwd", *(process / "fd").iterdir()]
                for link in links:
                    try:
                        target = Path(os.readlink(link))
                    except FileNotFoundError:
                        if link == process / "cwd":
                            break
                        continue
                    require(not target.is_absolute() or not target.is_relative_to(work), f"active process {process.name} uses task files; stop/yield it before resume")
            except FileNotFoundError:
                continue  # Process exited during observation.
            except PermissionError as exc:
                raise CompletionError("unknown process access; retain tree until writer cessation can be established") from exc
    else:
        raise CompletionError("writer observation unsupported on this platform; retain workspace")


def scratch_mounts():
    if sys.platform.startswith("linux"):
        rows = Path("/proc/self/mountinfo").read_text(encoding="utf-8").splitlines()
        paths = []
        for line in rows:
            fields = line.split()
            require(len(fields) >= 6, "cannot parse mount table; retain scratch")
            paths.append(re.sub(r"\\([0-7]{3})", lambda m: chr(int(m[1], 8)), fields[4]))
    elif sys.platform == "darwin":
        paths = []
        for line in command(["mount"]).splitlines():
            description, separator, options = line.rpartition(" (")
            candidates = [description[match.end():] for match in re.finditer(" on ", description)]
            require(separator and options.endswith(")") and candidates, "cannot parse mount table; retain scratch")
            # Darwin prints literal paths. Consider every possible separator so
            # ' on ' in a device or directory name can only cause retention.
            paths.extend(candidates)
    else:
        raise CompletionError("mount observation unsupported; retain scratch")
    return [Path(value).resolve() for value in paths]


def raise_walk_error(error):
    raise error


def clean_scratch(receipt, path, writers_stopped):
    """Empty the owned build directory; keep its identity across resume/reuse."""
    scratch = path.parent / "scratch"
    if "scratch_identity" not in receipt:
        return {"status": "NOT_OWNED"}
    require(writers_stopped, "stop/yield scratch writers, then use --writers-stopped")
    require(scratch == scratch.resolve() and scratch.is_dir(), "owned scratch missing or redirected; retain and inspect")
    identity = receipt["scratch_identity"]
    require(workspace_identity(scratch, path.parent) == identity, "scratch directory was replaced; retain")
    require(shutil.rmtree.avoids_symlink_attacks, "safe scratch removal unsupported on this platform; retain")
    require(not any(mount.is_relative_to(scratch) for mount in scratch_mounts()), "scratch contains a mounted filesystem; retain")
    stopped_writers(scratch)
    size = 0
    for directory, dirs, files in os.walk(scratch, followlinks=False, onerror=raise_walk_error):
        require(not any(name.casefold() == ".git" for name in dirs + files), "scratch contains Git recovery data; move it to retained custody before cleanup")
        for name in dirs + files:
            item = Path(directory) / name
            info = item.lstat()
            require(info.st_dev == identity[0][0], "scratch contains a mounted filesystem; retain")
            size += info.st_size if stat.S_ISREG(info.st_mode) else 0
    stopped_writers(scratch)
    require(workspace_identity(scratch, path.parent) == identity, "scratch changed before removal; retain")
    require(not any(mount.is_relative_to(scratch) for mount in scratch_mounts()), "scratch mount appeared before removal; retain")
    for item in scratch.iterdir():
        if item.is_dir() and not item.is_symlink():
            shutil.rmtree(item)
        else:
            item.unlink()
    require(workspace_identity(scratch, path.parent) == identity and not any(scratch.iterdir()), "scratch changed during cleanup; retain and inspect")
    result = {"status": "CLEAN", "logical_bytes_removed": size}
    receipt["scratch_cleanup"] = result
    atomic_json(path, receipt)
    return result


def clean_scratch_command(args):
    path = Path(args.receipt).absolute()
    with locked_receipt(path) as receipt:
        result = clean_scratch(receipt, path, args.writers_stopped)
        return {"status": "SCRATCH_CLEAN" if result["status"] == "CLEAN" else "SCRATCH_NOT_OWNED",
                "receipt": str(path), "scratch_cleanup": result, "product_verdict_unchanged": True}


def cleanup(receipt, path, pr):
    require(pr["state"] == "MERGED" and pr.get("mergedAt") and pr.get("mergeCommit", {}).get("oid"), "actual matching merge evidence is required")
    sha = receipt["publish_sha"]
    branch_ref = "refs/heads/" + receipt["branch"]
    # The recovery ref keeps the accepted commit reachable, so squash and
    # rebase merges need only the merge commit on base.
    require(ref_sha(receipt, receipt["recovery_ref"]) == sha, "recovery reachability changed; retain resources")
    verify_files(path.parent / "custody", receipt["files"])
    require(read_json(path.parent / "manifest.json") == receipt["files"], "custody manifest changed")
    gref(receipt, "merge-base", "--is-ancestor", pr["mergeCommit"]["oid"], remote_base(receipt))
    gref(receipt, "merge-base", "--is-ancestor", receipt["source_sha"], sha)
    work = Path(receipt["worktree"])
    local = ref_sha(receipt, branch_ref)
    require(local in {None, sha}, "local task ref changed; retain")
    if receipt["linked"]:
        if work.exists():
            require(receipt.get("writers_released"), "wait actual children, stop/yield known writers, then resume with --writers-stopped")
            require(work != Path(receipt["anchor"]) and work != Path(receipt["common_gitdir"]).parent, "cannot remove retained/main checkout")
            removable(receipt, work)
            devlyn = safe_path(work, ".devlyn")
            if devlyn.exists():
                require(devlyn.is_dir(), ".devlyn records must be a directory; retain tree")
                paths = [str((Path(directory) / name).relative_to(work))
                         for directory, dirs, files in os.walk(devlyn, onerror=raise_walk_error)
                         for name in files + [name for name in dirs if (Path(directory) / name).is_symlink()]]
                if paths:
                    records = snapshot_files(work, paths)
                    destination = path.parent / "records"
                    if not destination.exists():
                        with tempfile.TemporaryDirectory(prefix=".records-", dir=path.parent) as temporary:
                            shutil.copytree(devlyn, Path(temporary) / ".devlyn", symlinks=True)
                            verify_files(Path(temporary), records)
                            Path(temporary).rename(destination)
                    verify_files(destination, records)
                    verify_files(work, records)
            removable(receipt, work)
            gref(receipt, "worktree", "remove", str(work))
        else:
            require(str(work) not in registrations(receipt), "missing worktree is still registered; retain")
    checked_out = [p for p, row in registrations(receipt).items() if row.get("branch") == branch_ref]
    require(not checked_out, "task branch is still checked out at " + ", ".join(checked_out) + "; switch it off the task branch before cleanup")
    # Check ownership/ref identity once more immediately before each deletion.
    repo_policy(receipt)
    require(remote_url(receipt) == receipt["remote_url"], "remote changed before deletion")
    remote = remote_head(receipt, receipt["branch"])
    require(remote in {None, sha}, "remote branch changed after merge; retain ref")
    if remote == sha:
        # Deletion with an exact lease is the remote compare-and-delete primitive;
        # product publication above never uses force or a lease.
        gref(receipt, "push", f"--force-with-lease={branch_ref}:{sha}", receipt["remote"], ":"+branch_ref)
    if ref_sha(receipt, branch_ref) is not None:
        require(all(row.get("branch") != branch_ref for row in registrations(receipt).values()), "task branch became checked out; retain ref")
        gref(receipt, "update-ref", "-d", branch_ref, sha)
    receipt["status"] = "COMPLETE"
    atomic_json(path, receipt)


@contextlib.contextmanager
def locked_receipt(path, *, blocking=True):
    require(path.name == "receipt.json" and path.parent.parent.name == "devlyn-completion" and path == path.resolve(), "receipt must be its original external nonsymlink path")
    require(not (path.parent / "lock").is_symlink(), "receipt lock must not be a symlink")
    with contextlib.ExitStack() as stack:
        try:
            stack.enter_context(shared("platform-support")["file_lock"](path.parent / "lock", blocking=blocking))
        except (ImportError, OSError, AttributeError) as exc:
            raise CompletionError(f"receipt lock unavailable: {path}: {exc}") from exc
        receipt = read_json(path)
        require(path == Path(receipt["common_gitdir"]) / "devlyn-completion" / receipt["id"] / "receipt.json", "receipt/common Gitdir binding mismatch")
        require(receipt["id"] == hashlib.sha256(receipt["branch"].encode()).hexdigest()[:24] and receipt["branch"] not in {receipt["base"], "main", "master"}, "receipt branch ownership changed")
        require(receipt["allocation"] == "owned", "allocation was interrupted; no historical adoption is permitted")
        yield receipt


def completion_result(receipt, path, status):
    released = receipt.get("writers_released", False)
    resume = shlex.join([sys.executable, str(Path(__file__).resolve()), "complete", "--receipt", str(path)] +
                        (["--writers-stopped"] if released else []))
    scratch = {"status": "NOT_OWNED"}
    if "scratch_identity" in receipt:
        try:
            scratch = clean_scratch(receipt, path, released)
        except (CompletionError, OSError, ValueError, KeyError, TypeError, IndexError) as error:
            scratch = {"status": "RETAINED", "reason": str(error), "resume": shlex.join([
                sys.executable, str(Path(__file__).resolve()), "clean-scratch", "--receipt", str(path), "--writers-stopped"])}
            receipt["scratch_cleanup"] = scratch
            try:
                atomic_json(path, receipt)
            except OSError as record_error:
                scratch["record_error"] = str(record_error)
    return {"status": "CLEANUP_PENDING" if status == "COMPLETE" and scratch["status"] == "RETAINED" else status,
            "delivery_status": status, "receipt": str(path), "pr": receipt.get("pr_url"), "resume": resume,
            "acceptance": (receipt.get("acceptance") or {}).get("kind"), "product_verdict_unchanged": True,
            "scratch_path": str(path.parent / "scratch") if "scratch_identity" in receipt else None,
            "scratch_cleanup": scratch}


def reconcile(common, allocated, anchor):
    results = []
    for path in sorted((common / "devlyn-completion").glob("*/receipt.json")):
        if path == allocated:
            continue
        try:
            receipt = read_json(path)
            if receipt.get("allocation") != "owned" or not receipt.get("acceptance") or not receipt.get("pr_number") or receipt.get("local_only"):
                continue
            if receipt.get("status") == "COMPLETE" and (not receipt.get("writers_released") or "scratch_identity" not in receipt or receipt.get("scratch_cleanup", {}).get("status") == "CLEAN"):
                continue
            with locked_receipt(path, blocking=False) as receipt:
                if receipt.get("status") == "COMPLETE":
                    if receipt.get("writers_released") and "scratch_identity" in receipt and receipt.get("scratch_cleanup", {}).get("status") != "CLEAN":
                        results.append(completion_result(receipt, path, "COMPLETE"))
                    continue
                if not receipt.get("acceptance") or not receipt.get("pr_number") or receipt.get("local_only"):
                    continue
                pr = json.loads(gh(receipt, "pr", "view", str(receipt["pr_number"]), "--json", PR_FIELDS))
                if pr["state"] != "MERGED":
                    continue
                validate_pr(receipt, pr)
                require(not receipt["linked"] or Path(receipt["worktree"]) != anchor, "cannot clean the current allocation's anchor checkout: " + str(anchor))
                require(remote_url(receipt) == receipt["remote_url"], "remote URL changed since allocation")
                repo_policy(receipt)
                receipt["merge"] = pr
                atomic_json(path, receipt)
                cleanup(receipt, path, pr)
                results.append(completion_result(receipt, path, "COMPLETE"))
        except (Exception, SystemExit) as error:
            results.append({"receipt": str(path), "status": "RETAINED", "reason": str(error)})
    return results


def complete(args):
    path = Path(args.receipt).absolute()
    with locked_receipt(path) as receipt:
        if args.writers_stopped:
            if receipt["linked"]:
                outside(Path(receipt["worktree"]))
            receipt["writers_released"] = True
            atomic_json(path, receipt)
        def result(status):
            return completion_result(receipt, path, status)
        if args.local_only or receipt.get("local_only"):
            receipt["local_only"] = True
            atomic_json(path, receipt)
            return result("LOCAL_ONLY")
        mode = policy(receipt, args.mode or receipt.get("mode_override"))
        if args.mode:
            receipt["mode_override"] = args.mode
            atomic_json(path, receipt)
        require(remote_url(receipt) == receipt["remote_url"], "remote URL changed since allocation")
        if receipt.get("status") == "COMPLETE":
            verify_files(path.parent / "custody", receipt["files"])
            return result("COMPLETE")
        if not receipt.get("acceptance"):
            # Before first binding the owner has committed the product; inspect
            # uses the actual branch head until acceptance pins its exact SHA.
            current = dict(receipt, publish_sha=ref_sha(receipt, "refs/heads/"+receipt["branch"]))
            inspect_workspace(current)
        bind_acceptance(receipt, path, args.acceptance)
        info = repo_policy(receipt)
        if receipt.get("pr_number"):
            pr = json.loads(gh(receipt, "pr", "view", str(receipt["pr_number"]), "--json", PR_FIELDS))
        else:
            prs = json.loads(gh(receipt, "pr", "list", "--head", receipt["branch"], "--base", receipt["base"], "--state", "all", "--json", PR_FIELDS))
            require(len(prs) <= 1, "multiple PRs for task head/base; retain and resolve ambiguity")
            pr = prs[0] if prs else None
        if pr:
            validate_pr(receipt, pr)
        actual = remote_head(receipt, receipt["branch"])
        if not pr or pr["state"] != "MERGED":
            inspect_workspace(receipt)
            verify_files(Path(receipt["worktree"]), receipt["files"])
            require(actual in {None, receipt["publish_sha"]}, "remote task head changed; refusing to overwrite or merge")
            require(actual is not None or (not pr and not receipt.get("pushed")), "published task ref disappeared; retain and inspect")
            if actual is None:
                gref(receipt, "push", receipt["remote"], receipt["publish_sha"]+":refs/heads/"+receipt["branch"])
            receipt["pushed"] = True
            atomic_json(path, receipt)
            if pr is None:
                gh(receipt, "pr", "create", "--head", receipt["branch"], "--base", receipt["base"], "--title", receipt["task"], "--body", "Accepted task commit: " + receipt["publish_sha"])
                prs = json.loads(gh(receipt, "pr", "list", "--head", receipt["branch"], "--base", receipt["base"], "--state", "all", "--json", PR_FIELDS))
                require(len(prs) == 1, "created PR could not be reconciled; resume from receipt")
                pr = prs[0]
                validate_pr(receipt, pr)
        receipt.update(pr_number=pr["number"], pr_url=pr["url"])
        atomic_json(path, receipt)
        if mode == "pr" and pr["state"] == "OPEN":
            if pr.get("autoMergeRequest"):
                gh(receipt, "pr", "merge", str(pr["number"]), "--disable-auto")
                pr = json.loads(gh(receipt, "pr", "view", str(pr["number"]), "--json", PR_FIELDS))
                validate_pr(receipt, pr)
                require(not pr.get("autoMergeRequest"), "auto-merge request remains on owned PR; retain and inspect")
            if pr["state"] == "OPEN":
                return result("PR")
        if pr["state"] != "MERGED":
            inspect_workspace(receipt)
            verify_files(Path(receipt["worktree"]), receipt["files"])
            require(remote_head(receipt, receipt["branch"]) == receipt["publish_sha"], "remote head race before merge")
            refused = None
            if not pr.get("autoMergeRequest"):
                try:
                    require(info["mergeCommitAllowed"], "repository disallows merge commits")
                    gh(receipt, "pr", "merge", str(pr["number"]), "--auto", "--merge", "--match-head-commit", receipt["publish_sha"])
                except CompletionError as error:
                    refused = str(error)
            pr = json.loads(gh(receipt, "pr", "view", str(pr["number"]), "--json", PR_FIELDS))
            validate_pr(receipt, pr)
            if pr["state"] != "MERGED":
                # Merge only when the repository allows it; a refused request leaves the PR for a person.
                return dict(result("PR"), merge_refused=refused) if refused and not pr.get("autoMergeRequest") else result("PENDING")
        receipt["merge"] = pr
        atomic_json(path, receipt)
        cleanup(receipt, path, pr)
        return result("COMPLETE")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--self-test", action="store_true")
    actions = parser.add_subparsers(dest="action")
    allocation = actions.add_parser("allocate")
    allocation.add_argument("--repo", default=".")
    for name in ("task", "branch", "repository", "base"):
        allocation.add_argument("--"+name, required=True)
    allocation.add_argument("--remote", default="origin")
    allocation.add_argument("--worktree", required=True)
    completion = actions.add_parser("complete")
    completion.add_argument("--receipt", required=True)
    completion.add_argument("--acceptance")
    completion.add_argument("--mode", choices=("auto", "pr"))
    completion.add_argument("--local-only", "--no-push", action="store_true")
    completion.add_argument("--writers-stopped", action="store_true")
    scratch_cleanup = actions.add_parser("clean-scratch")
    scratch_cleanup.add_argument("--receipt", required=True)
    scratch_cleanup.add_argument("--writers-stopped", action="store_true")
    args = parser.parse_args()
    if args.self_test:
        return self_test()
    if args.action is None:
        parser.error("allocate, complete or clean-scratch is required")
    try:
        result = (allocate(args) if args.action == "allocate" else
                  clean_scratch_command(args) if args.action == "clean-scratch" else complete(args))
        print(json.dumps(result, sort_keys=True))
        return 0
    except (CompletionError, OSError, ValueError, KeyError, TypeError, IndexError, SystemExit) as exc:
        result = {"status": "BLOCKED", "reason": str(exc)}
        if args.action in {"complete", "clean-scratch"}:
            result["receipt"] = str(Path(args.receipt).absolute())
            result["resume"] = shlex.join([sys.executable, str(Path(__file__).resolve()), args.action, "--receipt", result["receipt"], *(["--writers-stopped"] if args.writers_stopped else [])])
        print(json.dumps(result, sort_keys=True))
        return 1


def self_test(names=None):
    suite = (unittest.TestSuite(CompletionTests(name) for name in names) if names
             else unittest.defaultTestLoader.loadTestsFromTestCase(CompletionTests))
    result = unittest.TextTestRunner(verbosity=1).run(suite)
    if result.wasSuccessful():
        print(f"task-complete self-test: PASS ({result.testsRun} isolated tests)")
    return 0 if result.wasSuccessful() else 1


# Fixtures use real Git and isolated config. Wrappers translate only transport
# to the local bare remote and inject interruption AFTER real effects; gh is fake.
FAKE_GH = r'''#!/usr/bin/env python3
import json, os, pathlib, subprocess, sys
p = pathlib.Path(os.environ['FIXTURE_GH'])
d = json.loads(p.read_text(encoding="utf-8")); a = sys.argv[1:]
def save(): p.write_text(json.dumps(d), encoding="utf-8")
def remote(ref):
    r = subprocess.run([os.environ['REAL_GIT'], '--git-dir', d['bare'], 'rev-parse', '--verify', ref], capture_output=True, text=True, encoding="utf-8")
    return r.stdout.strip() if r.returncode == 0 else None
if a[:2] == ['repo', 'view']:
    assert a[2:] == ['github.com/test/project', '--json', 'nameWithOwner,url,defaultBranchRef,mergeCommitAllowed'], 'unsupported gh repo view arguments: '+str(a)
    print(json.dumps({'nameWithOwner':'test/project', 'url':'https://github.com/test/project', 'defaultBranchRef':{'name':d.get('default_branch','main')}, 'mergeCommitAllowed':d.get('merge_allowed',True)}))
elif a[:2] == ['pr', 'list']:
    assert '--repo' in a and a[a.index('--repo')+1] == 'github.com/test/project'
    print(json.dumps([d['pr']] if d.get('pr') else []))
elif a[:2] == ['pr', 'create']:
    d['creates'] = d.get('creates',0)+1
    assert not d.get('pr'), 'duplicate PR'
    head = a[a.index('--head')+1]; base = a[a.index('--base')+1]
    d['pr'] = {'number':1,'url':'https://github.com/test/project/pull/1','headRefName':head,'baseRefName':base,'headRefOid':remote('refs/heads/'+head),'headRepository':{'name':'project','owner':{'login':'test'}}, 'headRepositoryOwner':{'login':'test'},'isCrossRepository':False,'state':'OPEN','mergedAt':None,'mergeCommit':None,'autoMergeRequest':None}
    save()
    print(d['pr']['url'])
    if d.pop('interrupt_create',False): save(); sys.exit(1)
elif a[:2] == ['pr', 'view']:
    print(json.dumps(d['pr']))
elif a[:2] == ['pr', 'merge'] and '--disable-auto' in a:
    d['disables'] = d.get('disables',0)+1
    d['pr']['autoMergeRequest'] = None
    save()
elif a[:2] == ['pr', 'merge']:
    assert '--admin' not in a and '--delete-branch' not in a
    assert '--auto' in a and '--merge' in a and '--match-head-commit' in a
    sha = a[a.index('--match-head-commit')+1]
    assert sha == remote('refs/heads/'+d['pr']['headRefName'])
    d['merges'] = d.get('merges',0)+1
    if not d.get('auto_allowed',True) and d.get('pending'):
        save(); print('repository disallows auto merge',file=sys.stderr); sys.exit(1)
    if d.get('pending'):
        d['pr']['autoMergeRequest'] = {'enabledAt':'now'}
    else:
        g = [os.environ['REAL_GIT'],'--git-dir',d['bare']]
        base = remote('refs/heads/main')
        tree = subprocess.check_output(g+['rev-parse',sha+'^{tree}'],text=True, encoding="utf-8").strip()
        merge = subprocess.check_output(g+['commit-tree',tree,'-p',base,'-p',sha,'-m','merge fixture'],text=True, encoding="utf-8").strip()
        subprocess.check_call(g+['update-ref','refs/heads/main',merge,base])
        d['pr'].update(state='MERGED',mergedAt='now',mergeCommit={'oid':merge})
    save()
    if d.pop('interrupt_merge',False): save(); sys.exit(1)
else:
    raise SystemExit('unexpected gh arguments: '+str(a))
'''

GIT_DISPATCH = r'''#!/bin/sh
for arg do
    case "$arg" in push|fetch|ls-remote|remove) exec python3 "$0.py" "$@";; esac
done
exec "$REAL_GIT" "$@"
'''


GIT_WRAPPER = r'''#!/usr/bin/env python3
import json, os, pathlib, subprocess, sys
a = sys.argv[1:]
p = pathlib.Path(os.environ['FIXTURE_GH']); d = json.loads(p.read_text(encoding="utf-8"))
if 'push' in a and any(x.startswith('--force-with-lease=') for x in a) and d.pop('remote_delete_race',False):
    subprocess.check_call([os.environ['REAL_GIT'],'--git-dir',d['bare'],'update-ref','refs/heads/'+d['pr']['headRefName'],d['race_sha']])
    p.write_text(json.dumps(d), encoding="utf-8")
for operation in ('push', 'fetch', 'ls-remote'):
    if operation in a and 'origin' in a:
        prefix = a[:a.index(operation)]
        url = subprocess.check_output([os.environ['REAL_GIT'], *prefix, 'remote', 'get-url', *(['--push'] if operation == 'push' else []), '--all', 'origin'], text=True, encoding="utf-8").strip()
        if url in {'https://github.com/test/project.git', 'git@github.com:test/project.git', 'ssh://git@github.com/test/project.git'}:
            a[a.index('origin')] = d['bare']
        break
r = subprocess.run([os.environ['REAL_GIT'],*a])
event = 'delete' if 'push' in a and any(x.startswith(':refs/') for x in a) else 'push' if 'push' in a else 'remove' if 'worktree' in a and 'remove' in a else None
if r.returncode == 0 and event:
    d = json.loads(p.read_text(encoding="utf-8")); d[event+'s'] = d.get(event+'s',0)+1
    fail = d.pop('interrupt_'+event,False); p.write_text(json.dumps(d), encoding="utf-8")
    if fail: sys.exit(1)
sys.exit(r.returncode)
'''


class CompletionTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="devlyn-completion-")
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name).resolve()
        self.work = self.root / "work"
        self.bare = self.root / "remote.git"
        self.bin = self.root / "bin"
        self.bin.mkdir()
        self.data = self.root / "gh.json"
        self.data.write_text(json.dumps({"bare": str(self.bare)}), encoding="utf-8")
        self.env = {**os.environ, "GIT_CONFIG_NOSYSTEM": "1", "GIT_CONFIG_GLOBAL": str(self.root / "gitconfig"),
                    "GIT_AUTHOR_NAME": "Fixture", "GIT_AUTHOR_EMAIL": "fixture@example.invalid",
                    "GIT_COMMITTER_NAME": "Fixture", "GIT_COMMITTER_EMAIL": "fixture@example.invalid",
                    "FIXTURE_GH": str(self.data), "REAL_GIT": shutil.which("git"),
                    "GIT_CONFIG_COUNT": "0", "GIT_ALLOW_PROTOCOL": "file"}
        for key in list(self.env):
            if key in {"GIT_DIR", "GIT_WORK_TREE", "GIT_INDEX_FILE", "GIT_COMMON_DIR"}:
                del self.env[key]
        for name, body in (("gh", FAKE_GH), ("git.py", GIT_WRAPPER), ("git", GIT_DISPATCH)):
            path = self.bin / name
            path.write_text(body, encoding="utf-8")
            path.chmod(0o755)
        self.env["PATH"] = str(self.bin) + os.pathsep + os.environ["PATH"]
        self.run_cmd(["git", "init", "--bare", "--initial-branch=main", str(self.bare)])
        self.run_cmd(["git", "init", "--initial-branch=main", str(self.work)])
        (self.work / ".gitignore").write_text(".devlyn/\nignored/\nnode_modules/\n.env\n", encoding="utf-8")
        (self.work / "product").write_text("baseline\n", encoding="utf-8")
        self.g("add", ".")
        self.g("commit", "-m", "baseline")
        self.g("remote", "add", "origin", "https://github.com/test/project.git")
        self.g("push", "origin", "main")
        self.configure(pushs=0)

    def run_cmd(self, args, *, cwd=None, success=True):
        r = subprocess.run(args, cwd=cwd or self.root, env=self.env, capture_output=True, text=True, encoding="utf-8")
        if success:
            self.assertEqual(r.returncode, 0, r.stderr + r.stdout)
        return r

    def g(self, *args, work=None):
        return self.run_cmd(["git", "-C", str(work or self.work), *args]).stdout.strip()

    def configure(self, **values):
        d = json.loads(self.data.read_text(encoding="utf-8")); d.update(values)
        self.data.write_text(json.dumps(d), encoding="utf-8")

    def cli(self, *args, success=True, cwd=None):
        r = self.run_cmd([sys.executable, str(Path(__file__).resolve()), *map(str, args)], success=success, cwd=cwd)
        return json.loads(r.stdout), r

    def allocate(self, name="fixture", base="main"):
        args = ["allocate", "--repo", self.work, "--task", name, "--branch", "task/"+name, "--repository", "test/project", "--base", base,
                "--worktree", self.root / ("linked" if name == "fixture" else name)]
        result, _ = self.cli(*args)
        self.receipt = Path(result["receipt"])
        self.task = Path(result["worktree"])
        return result

    def allocate_legacy(self):
        common = Path(self.g("rev-parse", "--absolute-git-dir"))
        key = hashlib.sha256(b"task/fixture").hexdigest()[:24]
        receipt = {"task": "fixture", "repository": "test/project", "remote": "origin", "base": "main", "branch": "task/fixture",
                   "common_gitdir": str(common), "anchor": str(self.work), "linked": False, "allocation": "owned",
                   "baseline": self.g("rev-parse", "HEAD"), "worktree": str(self.work), "id": key,
                   "recovery_ref": "refs/devlyn/completed/"+key, "worktree_gitdir": str(common),
                   "remote_url": dict.fromkeys(("literal", "fetch", "push"), "https://github.com/test/project.git")}
        self.receipt = common / "devlyn-completion" / key / "receipt.json"
        self.receipt.parent.mkdir(parents=True)
        scratch = self.receipt.parent / "scratch"
        scratch.mkdir()
        receipt["scratch_identity"] = workspace_identity(scratch, self.receipt.parent)
        self.g("switch", "-c", "task/fixture")
        receipt["worktree_identity"] = workspace_identity(self.work, common)
        self.receipt.write_text(json.dumps(receipt), encoding="utf-8")
        self.task = self.work

    def merge_pr(self):
        self.configure(pending=False)
        self.run_cmd(["gh", "pr", "merge", "1", "--auto", "--merge", "--match-head-commit", self.sha])

    def anchor_state(self, work=None):
        work = work or self.work
        return (self.g("symbolic-ref", "HEAD", work=work), self.g("rev-parse", "HEAD", work=work),
                self.g("status", "--porcelain", "--untracked-files=all", work=work), (work / "product").read_bytes(),
                (Path(self.g("rev-parse", "--absolute-git-dir", work=work)) / "index").read_bytes())

    def test_allocate_base_with_same_named_tag(self):
        self.g("tag", "main")
        result = self.allocate()
        self.assertEqual(result["status"], "ALLOCATED")
        self.assertEqual(json.loads(self.receipt.read_text(encoding="utf-8"))["base"], "main")

    def test_allocate_base_preserves_unicode_whitespace(self):
        base = "main\u00a0"
        self.g("switch", "-c", base)
        self.g("push", "origin", "HEAD:refs/heads/"+base)
        result = self.allocate(base=base)
        self.assertEqual(result["status"], "ALLOCATED")
        self.assertEqual(json.loads(self.receipt.read_text(encoding="utf-8"))["base"], base)

    def assert_base_identity_rejected(self, actual, base):
        result, process = self.cli("allocate", "--repo", self.work, "--task", "fixture",
            "--branch", "task/fixture", "--repository", "test/project", "--base", base, "--worktree", self.root / "linked", success=False)
        self.assertNotEqual(process.returncode, 0)
        self.assertIn("refs/heads/"+base, result["reason"])
        head = self.run_cmd(["git", "-C", str(self.work), "symbolic-ref", "HEAD"]).stdout
        self.assertEqual(head, "refs/heads/" + actual + "\n")
        self.assertFalse((self.work / ".git/devlyn-completion").exists())
        self.assertNotEqual(self.run_cmd(["git", "-C", str(self.work), "show-ref", "--verify",
            "refs/heads/task/fixture"], success=False).returncode, 0)

    def test_allocate_rejects_trimmed_base_alias(self):
        self.g("switch", "-c", "main\u00a0")
        self.g("push", "origin", "HEAD:refs/heads/main\u00a0")
        self.run_cmd(["git", "--git-dir", str(self.bare), "update-ref", "-d", "refs/heads/main"])
        self.assert_base_identity_rejected("main\u00a0", "main")

    def test_allocate_rejects_short_base_alias(self):
        self.g("branch", "heads/main")
        self.g("tag", "main")
        self.assert_base_identity_rejected("main", "heads/main")

    def test_allocate_uses_remote_base_with_dirty_foreign_anchor(self):
        baseline = self.g("rev-parse", "main")
        (self.work / "product").write_text("remote advance\n", encoding="utf-8")
        self.g("commit", "-am", "remote advance")
        self.g("push", "origin", "main")
        remote = self.g("rev-parse", "main")
        self.g("switch", "-c", "busy")
        (self.work / "product").write_text("local advance\n", encoding="utf-8")
        self.g("commit", "-am", "local advance")
        ahead = self.g("rev-parse", "HEAD")
        (self.work / "product").write_text("busy edits\n", encoding="utf-8")
        (self.work / "untracked").write_bytes(b"owner data")
        for name, local in (("behind", baseline), ("ahead", ahead)):
            self.g("update-ref", "refs/heads/main", local)
            before = self.anchor_state()
            result = self.allocate(name)
            self.assertEqual(result["status"], "ALLOCATED")
            self.assertEqual(json.loads(self.receipt.read_text())["baseline"], remote)
            self.assertEqual(self.g("rev-parse", "HEAD", work=self.task), remote)
            self.assertEqual(self.anchor_state(), before)
            self.assertEqual((self.work / "untracked").read_bytes(), b"owner data")
            self.assertFalse((self.work / ".git" / "FETCH_HEAD").exists())

    @unittest.skipUnless(sys.platform == "darwin" or sys.platform.startswith("linux"), "writer observation requires POSIX")
    def test_disposable_scratch_cleans_for_local_only_and_preserves_source(self):
        result = self.allocate()
        scratch = Path(result["scratch"])
        (scratch / "target").mkdir()
        (scratch / "target" / "object").write_bytes(b"rebuildable")
        (self.task / "uncommitted-work").write_text("preserve")
        result, _ = self.cli("complete", "--receipt", self.receipt, "--local-only", "--writers-stopped")
        self.assertEqual(result["status"], "LOCAL_ONLY")
        self.assertFalse(any(scratch.iterdir()))
        self.assertEqual((self.task / "uncommitted-work").read_text(), "preserve")
        self.assertEqual(result["scratch_cleanup"]["logical_bytes_removed"], 11)
        result, _ = self.cli("clean-scratch", "--receipt", self.receipt, "--writers-stopped")
        self.assertEqual(result["status"], "SCRATCH_CLEAN")

    @unittest.skipUnless(sys.platform == "darwin" or sys.platform.startswith("linux"), "writer observation requires POSIX")
    def test_scratch_rejects_active_writer_and_requires_owner_assertion(self):
        scratch = Path(self.allocate()["scratch"])
        result, _ = self.cli("clean-scratch", "--receipt", self.receipt, success=False)
        self.assertIn("--writers-stopped", result["reason"])
        child = subprocess.Popen([sys.executable, "-c", "import time; time.sleep(30)"], cwd=scratch)
        try:
            result, _ = self.cli("clean-scratch", "--receipt", self.receipt, "--writers-stopped", success=False)
            self.assertIn("active process", result["reason"])
            self.assertTrue(scratch.is_dir())
        finally:
            child.terminate()
            child.wait(timeout=5)
        self.cli("clean-scratch", "--receipt", self.receipt, "--writers-stopped")

    def test_linux_writer_scan_continues_after_vanished_fd(self):
        from unittest.mock import patch
        process = Path("/proc") / str(os.getpid() + 1)
        vanished, active = process / "fd/0", process / "fd/1"
        iterdir, readlink = Path.iterdir, os.readlink
        def entries(path):
            if path == Path("/proc"):
                return iter([process])
            if path == process / "fd":
                return iter([vanished, active])
            return iterdir(path)
        def target(path, *args, **kwargs):
            if path == process / "cwd":
                return str(self.root)
            if path == vanished:
                raise FileNotFoundError(path)
            if path == active:
                return str(self.work / "product")
            return readlink(path, *args, **kwargs)
        with patch.object(sys, "platform", "linux"), patch.object(Path, "iterdir", entries), patch.object(os, "readlink", target):
            with self.assertRaisesRegex(CompletionError, "active process " + process.name):
                stopped_writers(self.work)

    @unittest.skipUnless(sys.platform == "darwin" or sys.platform.startswith("linux"), "writer observation requires POSIX")
    def test_scratch_rejects_redirect_and_git_data_but_does_not_follow_child_links(self):
        scratch = Path(self.allocate()["scratch"])
        outside = self.root / "outside"
        outside.mkdir()
        (outside / "keep").write_text("source")
        retained = scratch.with_name("retained")
        scratch.rename(retained)
        scratch.symlink_to(outside, target_is_directory=True)
        result, _ = self.cli("clean-scratch", "--receipt", self.receipt, "--writers-stopped", success=False)
        self.assertIn("redirected", result["reason"])
        scratch.unlink()
        retained.rename(scratch)
        (scratch / ".GiT").write_text("gitdir: elsewhere")
        result, _ = self.cli("clean-scratch", "--receipt", self.receipt, "--writers-stopped", success=False)
        self.assertIn("Git recovery data", result["reason"])
        (scratch / ".GiT").unlink()
        (scratch / "external-link").symlink_to(outside, target_is_directory=True)
        self.cli("clean-scratch", "--receipt", self.receipt, "--writers-stopped")
        self.assertEqual((outside / "keep").read_text(), "source")

    @unittest.skipUnless(sys.platform == "darwin" or sys.platform.startswith("linux"), "writer observation requires POSIX")
    def test_scratch_reuse_and_partial_cleanup_keep_original_identity(self):
        scratch = Path(self.allocate()["scratch"])
        (scratch / "first-build").write_bytes(b"first")
        self.cli("clean-scratch", "--receipt", self.receipt, "--writers-stopped")
        (scratch / "resumed-build").write_bytes(b"next")
        result, _ = self.cli("clean-scratch", "--receipt", self.receipt, "--writers-stopped")
        self.assertEqual(result["scratch_cleanup"]["logical_bytes_removed"], 4)
        self.assertFalse(any(scratch.iterdir()))
        scratch.rename(scratch.with_name("original"))
        scratch.mkdir()
        (scratch / "foreign").write_text("preserve")
        result, _ = self.cli("clean-scratch", "--receipt", self.receipt, "--writers-stopped", success=False)
        self.assertIn("replaced", result["reason"])
        self.assertIn("--writers-stopped", result["resume"])
        self.assertEqual((scratch / "foreign").read_text(), "preserve")

    @unittest.skipUnless(sys.platform == "darwin" or sys.platform.startswith("linux"), "writer observation requires POSIX")
    def test_scratch_refusal_does_not_block_local_only_delivery(self):
        scratch = Path(self.allocate()["scratch"])
        (scratch / ".git").mkdir()
        result, _ = self.cli("complete", "--receipt", self.receipt, "--local-only", "--writers-stopped")
        self.assertEqual(result["status"], "LOCAL_ONLY")
        self.assertEqual(result["scratch_cleanup"]["status"], "RETAINED")
        self.assertIn("Git recovery data", result["scratch_cleanup"]["reason"])
        self.assertEqual(json.loads(self.receipt.read_text())["scratch_cleanup"]["status"], "RETAINED")
        self.assertTrue((scratch / ".git").is_dir())

    @unittest.skipUnless(sys.platform == "darwin" or sys.platform.startswith("linux"), "writer observation requires POSIX")
    def test_scratch_refusal_reports_delivery_separately(self):
        scratch = Path(self.allocate()["scratch"])
        self.accept()
        (scratch / ".git").mkdir()
        result, _ = self.cli("complete", "--receipt", self.receipt, "--acceptance", self.acceptance, "--writers-stopped", "--mode", "auto")
        self.assertEqual(result["status"], "CLEANUP_PENDING")
        self.assertEqual(result["delivery_status"], "COMPLETE")
        self.assertEqual(result["scratch_cleanup"]["status"], "RETAINED")
        self.assertIn("--writers-stopped", result["scratch_cleanup"]["resume"])
        self.assertIn("--writers-stopped", result["resume"])
        (scratch / ".git").rmdir()
        result, _ = self.cli("complete", "--receipt", self.receipt, "--writers-stopped")
        self.assertEqual(result["status"], "COMPLETE")

    @unittest.skipUnless(sys.platform == "darwin" or sys.platform.startswith("linux"), "writer observation requires POSIX")
    def test_scratch_mount_and_scan_failure_preserve_contents(self):
        from unittest.mock import patch
        scratch = Path(self.allocate()["scratch"])
        (scratch / "keep").write_text("retained")
        receipt = json.loads(self.receipt.read_text())
        with patch.dict(clean_scratch.__globals__, {"scratch_mounts": lambda: [scratch / "same-device-bind"]}):
            with self.assertRaisesRegex(CompletionError, "mounted filesystem"):
                clean_scratch(receipt, self.receipt, True)
        def failed_walk(*args, **kwargs):
            kwargs["onerror"](PermissionError("unreadable subtree"))
        with patch.object(os, "walk", failed_walk):
            with self.assertRaisesRegex(PermissionError, "unreadable subtree"):
                clean_scratch(receipt, self.receipt, True)
        self.assertEqual((scratch / "keep").read_text(), "retained")

    def test_scratch_mount_table_parsing_preserves_ambiguous_literal_paths(self):
        from unittest.mock import patch
        target = "/task/scratch/name on inside\\040literal"
        with patch.object(sys, "platform", "darwin"), patch.dict(scratch_mounts.__globals__, {
            "command": lambda args: "device on source on " + target + " (local, journaled)",
        }):
            self.assertIn(Path(target).resolve(), scratch_mounts())
        alias = self.root / "scratch-alias"
        alias.symlink_to(self.root, target_is_directory=True)
        with patch.object(sys, "platform", "darwin"), patch.dict(scratch_mounts.__globals__, {
            "command": lambda args: "device on " + str(alias / "mounted") + " (local)",
        }):
            self.assertEqual(scratch_mounts(), [(self.root / "mounted").resolve()])
        with patch.object(sys, "platform", "linux"), patch.object(Path, "read_text", return_value="truncated row"):
            with self.assertRaisesRegex(CompletionError, "cannot parse mount table"):
                scratch_mounts()

    def accept(self, pipeline=False, queue=False, spec_expected=None, spec_name="spec.md"):
        if spec_expected is not None:
            (self.task / spec_name).write_text("# Fixture\nProduct contains accepted bytes.\n", encoding="utf-8")
            (self.task / "spec.expected.json").write_text(json.dumps(spec_expected), encoding="utf-8")
            self.g("add", spec_name, "spec.expected.json", work=self.task)
        (self.task / "product").write_text("accepted\n", encoding="utf-8")
        self.g("add", "product", work=self.task)
        self.g("commit", "-m", "scoped task", work=self.task)
        self.sha = self.g("rev-parse", "HEAD", work=self.task)
        evidence = self.task / ".devlyn"
        evidence.mkdir(exist_ok=True)
        (evidence / "checks.txt").write_text("actual fixture check: accepted bytes\n", encoding="utf-8")
        a = {"kind": "direct", "task": "fixture", "source_sha": self.sha,
             "checks": [{"command": "fixture byte assertion", "evidence": ".devlyn/checks.txt"}]}
        self.assertEqual((self.task / "product").read_text(encoding="utf-8"), "accepted\n")
        if pipeline:
            a = {"kind": "pipeline", "task": "fixture", "source_sha": self.sha, "run_id": "fixture-run"}
            archive = evidence / "runs" / a["run_id"]
            archive.mkdir(parents=True)
            self.archive = archive
            report = "<!-- devlyn:final-report run_id=fixture-run -->\nFixture completed.\n"
            (archive / "final-report.md").write_text(report, encoding="utf-8")
            phases = {n: {"started_at": "2026-09-10T00:00:00Z", "completed_at": "2026-09-10T00:00:01Z", "verdict": "PASS"}
                      for n in ("plan", "implement", "build_gate", "cleanup", "verify", "final_report")}
            phases["cleanup"]["post_sha"] = self.sha
            phases["final_report"].update(output_sha256=hashlib.sha256(report.encode()).hexdigest(), artifacts={"log_file": ".devlyn/final-report.md"})
            criteria = "# Fixture acceptance\nProduct contains accepted bytes.\n"
            (archive / "criteria.generated.md").write_text(criteria, encoding="utf-8")
            source = {"type": "generated", "criteria_path": ".devlyn/criteria.generated.md", "criteria_sha256": hashlib.sha256(criteria.encode()).hexdigest()}
            self.state = {"run_id": a["run_id"], "mode": "free-form", "source": source, "phases": phases, "process_evidence": None}
            if spec_expected is not None:
                self.state["mode"] = "spec"
                self.state["source"] = {"type": "spec", "spec_path": spec_name, "spec_sha256": hashlib.sha256((self.task / spec_name).read_bytes()).hexdigest()}
            (archive / "pipeline.state.json").write_text(json.dumps(self.state), encoding="utf-8")
            (archive / "finish-gate.summary.json").write_text(json.dumps({"mode": self.state["mode"], "exit": 0, "offenders": 0, "checked": 1}), encoding="utf-8")
            (archive / "verify-merge.summary.json").write_text(json.dumps({"verdict": "PASS"}), encoding="utf-8")
        if queue:
            (self.task / "queue.md").write_text("- [x] fixture\n", encoding="utf-8")
            self.g("add", "queue.md", work=self.task)
            self.g("commit", "-m", "terminal queue", work=self.task)
            a["queue"] = {"commit": self.g("rev-parse", "HEAD", work=self.task), "file": "queue.md"}
        self.acceptance = evidence / "acceptance.json"
        self.acceptance.write_text(json.dumps(a), encoding="utf-8")

    def complete(self, *args, success=True, cwd=None, acceptance=True):
        command_args = ["complete", "--receipt", self.receipt]
        if acceptance:
            command_args += ["--acceptance", self.acceptance]
        return self.cli(*command_args, *args, success=success, cwd=cwd)

    def test_reject_repository_rewrite_before_allocation(self):
        intended = "https://github.com/test/project.git"
        destination = "https://github.com/test/other.git"
        self.g("config", "url." + destination + ".insteadOf", intended)
        self.assertEqual(self.g("config", "--get", "remote.origin.url"), intended)
        self.assertEqual(self.g("remote", "get-url", "--all", "origin"), destination)
        self.assertEqual(self.g("remote", "get-url", "--push", "--all", "origin"), destination)
        local_refs = self.g("show-ref")
        remote_refs = self.run_cmd(["git", "--git-dir", str(self.bare), "show-ref"]).stdout
        server = self.data.read_bytes()
        result, r = self.cli("allocate", "--repo", self.work, "--task", "fixture", "--branch", "task/fixture", "--repository", "test/project", "--base", "main", "--worktree", self.root / "linked", success=False)
        self.assertEqual(self.g("show-ref"), local_refs, r.stdout)
        self.assertEqual(self.run_cmd(["git", "--git-dir", str(self.bare), "show-ref"]).stdout, remote_refs)
        self.assertEqual(self.data.read_bytes(), server)
        self.assertEqual(self.g("branch", "--show-current"), "main")
        self.assertFalse((self.root / "linked").exists())
        self.assertFalse((self.work / ".git/devlyn-completion").exists())
        self.assertNotEqual(r.returncode, 0)
        self.assertEqual(result["status"], "BLOCKED")
        self.assertIn("repository differs from remote", result["reason"])

    def test_same_repository_transport_alias(self):
        intended = "https://github.com/test/project.git"
        alias = "git@github.com:test/project.git"
        self.g("config", "url." + alias + ".insteadOf", intended)
        self.allocate(); self.accept()
        self.assertEqual(json.loads(self.receipt.read_text(encoding="utf-8"))["remote_url"], {"literal": intended, "fetch": alias, "push": alias})
        result, _ = self.complete("--mode", "pr")
        self.assertEqual(result["status"], "PR")
        self.assertEqual(self.g("ls-remote", "origin", "refs/heads/task/fixture").split()[0], self.sha)
        d = json.loads(self.data.read_text(encoding="utf-8"))
        self.assertEqual((d["pushs"], d.get("merges", 0), d["pr"]["autoMergeRequest"]), (1, 0, None))

    def test_pr_mode_disables_only_owned_auto_merge(self):
        self.allocate(); self.accept()
        self.configure(pending=True)
        result, _ = self.complete("--mode", "auto")
        self.assertEqual(result["status"], "PENDING")
        result, _ = self.complete("--mode", "pr")
        self.assertEqual(result["status"], "PR")
        d = json.loads(self.data.read_text(encoding="utf-8"))
        self.assertEqual((d["disables"], d["pr"]["autoMergeRequest"]), (1, None))
        self.configure(pr=dict(d["pr"], isCrossRepository=True, autoMergeRequest={"enabledAt": "now"}))
        _, r = self.complete("--mode", "pr", success=False)
        self.assertIn("PR head repository differs", json.loads(r.stdout)["reason"])
        d = json.loads(self.data.read_text(encoding="utf-8"))
        self.assertEqual((d["disables"], d["pr"]["autoMergeRequest"]), (1, {"enabledAt": "now"}))

    def test_remote_rewrite_after_allocation_is_rejected(self):
        self.allocate(); self.accept()
        self.g("config", "url.git@github.com:test/project.git.insteadOf", "https://github.com/test/project.git")
        local_refs = self.g("show-ref")
        remote_refs = self.run_cmd(["git", "--git-dir", str(self.bare), "show-ref"]).stdout
        server = self.data.read_bytes()
        result, r = self.complete(success=False)
        self.assertNotEqual(r.returncode, 0)
        self.assertIn("remote URL changed since allocation", result["reason"])
        self.assertEqual(self.g("show-ref"), local_refs)
        self.assertEqual(self.run_cmd(["git", "--git-dir", str(self.bare), "show-ref"]).stdout, remote_refs)
        self.assertEqual(self.data.read_bytes(), server)
        self.assertTrue(self.task.exists())

    def test_reject_previously_bound_repository_rewrite(self):
        self.allocate(); self.accept()
        destination = "https://github.com/test/other.git"
        self.g("config", "url." + destination + ".insteadOf", "https://github.com/test/project.git")
        # Reproduce a receipt the old literal-only allocation check accepted.
        receipt = json.loads(self.receipt.read_text(encoding="utf-8"))
        receipt["remote_url"].update(fetch=destination, push=destination)
        self.receipt.write_text(json.dumps(receipt), encoding="utf-8")
        local_refs = self.g("show-ref")
        remote_refs = self.run_cmd(["git", "--git-dir", str(self.bare), "show-ref"]).stdout
        server = self.data.read_bytes()
        result, r = self.complete(success=False)
        self.assertNotEqual(r.returncode, 0)
        self.assertIn("repository differs from remote", result["reason"])
        self.assertEqual(self.g("show-ref"), local_refs)
        self.assertEqual(self.run_cmd(["git", "--git-dir", str(self.bare), "show-ref"]).stdout, remote_refs)
        self.assertEqual(self.data.read_bytes(), server)
        self.assertTrue(self.task.exists())

    def test_pr_pending_and_retry(self):
        self.allocate(); self.accept()
        result, _ = self.complete("--mode", "pr")
        self.assertEqual(result["status"], "PR")
        self.assertTrue(self.task.exists())
        self.configure(pending=True)
        for _ in range(2):
            result, _ = self.complete("--mode", "auto")
            self.assertEqual(result["status"], "PENDING")
        d = json.loads(self.data.read_text(encoding="utf-8"))
        self.assertEqual((d["creates"], d["merges"], d["pushs"]), (1, 1, 1))

    def test_legacy_in_place_retains_checked_out_branch_then_retires_refs(self):
        self.allocate_legacy(); self.accept()
        (self.task / "ignored").mkdir()
        (self.task / "ignored" / "user.txt").write_text("retain me", encoding="utf-8")
        self.complete("--mode", "pr", "--writers-stopped")
        self.merge_pr()
        before = self.anchor_state()
        receipt, task = self.receipt, self.task
        result = self.allocate("next")
        self.assertEqual(result["reconciled"][0]["status"], "RETAINED")
        self.assertIn(str(task), result["reconciled"][0]["reason"])
        self.assertIn("switch", result["reconciled"][0]["reason"])
        self.assertEqual(self.anchor_state(), before)
        self.assertNotEqual(self.g("branch", "--list", "task/fixture"), "")
        self.assertEqual(self.g("ls-remote", "origin", "refs/heads/task/fixture").split()[0], self.sha)
        self.g("switch", "main")
        (self.work / "product").write_text("owner edits\n", encoding="utf-8")
        (self.work / "untracked").write_bytes(b"owner data")
        before = self.anchor_state()
        result = self.allocate("retired")
        self.assertEqual([(row["receipt"], row["status"]) for row in result["reconciled"]], [(str(receipt), "COMPLETE")])
        self.assertEqual(self.anchor_state(), before)
        self.assertEqual((self.work / "untracked").read_bytes(), b"owner data")
        self.assertEqual((task / "ignored/user.txt").read_text(encoding="utf-8"), "retain me")
        self.assertEqual(self.g("branch", "--list", "task/fixture"), "")
        self.assertEqual(self.g("ls-remote", "origin", "refs/heads/task/fixture"), "")
        self.receipt, self.task = receipt, task
        again, _ = self.complete(acceptance=False)
        self.assertEqual(again["status"], "COMPLETE")

    def test_pr_mode_cleans_after_human_merge(self):
        self.allocate(); self.accept()
        self.complete("--mode", "pr")
        self.merge_pr()
        before = self.data.read_bytes()
        result, _ = self.complete("--mode", "pr", "--writers-stopped")
        self.assertEqual(result["status"], "COMPLETE")
        self.assertFalse(self.task.exists())
        self.assertEqual(self.g("branch", "--list", "task/fixture"), "")
        self.assertEqual(self.g("ls-remote", "origin", "refs/heads/task/fixture"), "")
        saved, current = json.loads(before), json.loads(self.data.read_bytes())
        self.assertEqual((current["merges"], current.get("disables", 0)), (saved["merges"], saved.get("disables", 0)))

    @unittest.skipUnless(sys.platform == "darwin" or sys.platform.startswith("linux"), "writer observation requires POSIX")
    def test_nested_repository_or_worktree_retains_tree(self):
        self.allocate(); self.accept()
        _, r = self.cli("allocate", "--repo", self.work, "--task", "inner", "--branch", "task/inner", "--repository", "test/project",
                        "--base", "main", "--worktree", self.task / "ignored" / "inner", success=False)
        self.assertIn("disjoint from every registered worktree", json.loads(r.stdout)["reason"])
        nested = self.task / "ignored" / "nested"
        self.g("worktree", "add", "-b", "nested/work", str(nested), "main")
        (nested / "product").write_text("unsaved nested work\n", encoding="utf-8")
        clone = self.task / "ignored" / "clone"
        self.run_cmd(["git", "init", "--initial-branch=main", str(clone)])
        for remove in (lambda: self.g("worktree", "remove", "--force", str(nested)), lambda: shutil.rmtree(clone)):
            _, r = self.complete("--mode", "auto", "--writers-stopped", success=False)
            self.assertIn("nested repository or worktree", json.loads(r.stdout)["reason"])
            self.assertTrue(self.task.exists())
            self.assertNotEqual(self.g("branch", "--list", "task/fixture"), "")
            if nested.exists():
                self.assertEqual((nested / "product").read_text(encoding="utf-8"), "unsaved nested work\n")
            remove()
        result, _ = self.complete("--mode", "auto", "--writers-stopped")
        self.assertEqual(result["status"], "COMPLETE")
        self.assertFalse(self.task.exists())

    @unittest.skipUnless(sys.platform == "darwin" or sys.platform.startswith("linux"), "writer observation requires POSIX")
    def test_default_mode_merges_when_possible_and_cleans(self):
        self.allocate(); self.accept()
        result, _ = self.complete("--writers-stopped")
        self.assertEqual(result["status"], "COMPLETE")
        self.assertEqual(json.loads(self.data.read_text(encoding="utf-8")).get("merges"), 1)
        self.assertFalse(self.task.exists())
        self.assertEqual(self.g("branch", "--list", "task/fixture"), "")

    def test_release_is_refused_from_inside_the_task_tree(self):
        self.allocate(); self.accept()
        _, r = self.complete("--mode", "pr", "--writers-stopped", cwd=self.task, success=False)
        self.assertIn("caller cwd is inside", json.loads(r.stdout)["reason"])
        self.assertNotIn("writers_released", json.loads(self.receipt.read_text(encoding="utf-8")))

    @unittest.skipUnless(sys.platform == "darwin" or sys.platform.startswith("linux"), "writer observation requires POSIX")
    def test_squash_merge_cleans_and_recovery_ref_keeps_commit(self):
        self.allocate(); self.accept()
        result, _ = self.complete("--mode", "pr", "--writers-stopped")
        self.assertEqual(result["status"], "PR")
        bare = ["git", "--git-dir", str(self.bare)]
        base = self.run_cmd(bare + ["rev-parse", "refs/heads/main"]).stdout.strip()
        tree = self.run_cmd(bare + ["rev-parse", self.sha + "^{tree}"]).stdout.strip()
        squash = self.run_cmd(bare + ["commit-tree", tree, "-p", base, "-m", "squash fixture"]).stdout.strip()
        self.run_cmd(bare + ["update-ref", "refs/heads/main", squash, base])
        pr = json.loads(self.data.read_text(encoding="utf-8"))["pr"]
        self.configure(pr=dict(pr, state="MERGED", mergedAt="now", mergeCommit={"oid": squash}))
        result, _ = self.complete()
        self.assertEqual(result["status"], "COMPLETE")
        self.assertFalse(self.task.exists())
        self.assertEqual(self.g("branch", "--list", "task/fixture"), "")
        self.assertEqual(self.g("ls-remote", "origin", "refs/heads/task/fixture"), "")
        self.assertEqual(self.g("rev-parse", json.loads(self.receipt.read_text(encoding="utf-8"))["recovery_ref"]), self.sha)
        self.assertFalse((self.work / ".git" / "FETCH_HEAD").exists())

    def test_linked_ignored_output_disposed_and_records_preserved(self):
        self.allocate(); self.accept()
        for relative, raw in (("node_modules/x", b"build"), (".env", b"SECRET=value\n"), (".devlyn/runs/extra/log", b"extra\x00bytes\n")):
            path = self.task / relative
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(raw)
            path.chmod(0o640)
        records = snapshot_files(self.task, [".devlyn"])
        (self.task / "untracked").write_bytes(b"owner data")
        _, process = self.complete("--mode", "auto", "--writers-stopped", success=False)
        self.assertNotEqual(process.returncode, 0)
        self.assertTrue(self.task.exists())
        self.assertEqual((self.task / "untracked").read_bytes(), b"owner data")
        self.assertNotEqual(self.g("branch", "--list", "task/fixture"), "")
        (self.task / "untracked").unlink()
        result, _ = self.complete("--mode", "auto", "--writers-stopped")
        self.assertEqual(result["status"], "COMPLETE")
        self.assertFalse(self.task.exists())
        verify_files(self.receipt.parent / "records", records)
        self.assertEqual(snapshot_files(self.receipt.parent / "records", [".devlyn"]), records)
        self.assertEqual(self.g("branch", "--list", "task/fixture"), "")
        self.assertEqual(self.g("ls-remote", "origin", "refs/heads/task/fixture"), "")

    def test_reconcile_released_merge_and_retains_without_release(self):
        self.allocate(); self.accept()
        result, _ = self.complete("--mode", "pr")
        self.assertEqual(result["status"], "PR")
        receipt, task = self.receipt, self.task
        self.merge_pr()
        result = self.allocate("unreleased")
        self.assertEqual(len(result["reconciled"]), 1)
        self.assertEqual(result["reconciled"][0]["status"], "RETAINED")
        self.assertIn("writers", result["reconciled"][0]["reason"])
        self.assertTrue(task.exists())
        self.assertNotEqual(self.g("branch", "--list", "task/fixture"), "")
        self.assertEqual(self.g("ls-remote", "origin", "refs/heads/task/fixture").split()[0], self.sha)
        # Reopen only the fixture PR to exercise the owner's pre-merge release.
        d = json.loads(self.data.read_text())
        self.configure(pr=dict(d["pr"], state="OPEN", mergedAt=None, mergeCommit=None))
        self.receipt, self.task = receipt, task
        result, _ = self.complete("--mode", "pr", "--writers-stopped")
        self.assertEqual(result["status"], "PR")
        self.assertTrue(json.loads(receipt.read_text())["writers_released"])
        self.merge_pr()
        server = json.loads(self.data.read_text())
        result = self.allocate("released")
        self.assertEqual([(row["receipt"], row["status"]) for row in result["reconciled"]], [(str(receipt), "COMPLETE")])
        self.assertFalse(task.exists())
        self.assertEqual(self.g("branch", "--list", "task/fixture"), "")
        self.assertEqual(self.g("ls-remote", "origin", "refs/heads/task/fixture"), "")
        current = json.loads(self.data.read_text())
        self.assertEqual((current["pushs"], current["creates"], current["merges"], current.get("disables", 0)),
                         (server["pushs"], server["creates"], server["merges"], server.get("disables", 0)))

    def test_reconcile_checks_repo_policy_before_cleanup(self):
        self.allocate(); self.accept()
        self.complete("--mode", "pr", "--writers-stopped")
        self.merge_pr()
        receipt, task = self.receipt, self.task
        self.configure(default_branch="changed")
        result = self.allocate("next")
        self.assertEqual([(row["receipt"], row["status"]) for row in result["reconciled"]], [(str(receipt), "RETAINED")])
        self.assertIn("base/default branch changed", result["reconciled"][0]["reason"])
        self.assertTrue(task.exists())
        self.assertEqual(self.g("rev-parse", "task/fixture"), self.sha)
        self.assertEqual(self.g("ls-remote", "origin", "refs/heads/task/fixture").split()[0], self.sha)

    def test_reconcile_skips_open_and_unaccepted_and_retains_in_use_tree(self):
        self.allocate(); self.accept()
        self.complete("--mode", "pr", "--writers-stopped")
        receipt, task = self.receipt, self.task
        before = receipt.read_bytes()
        result = self.allocate("unaccepted")
        self.assertEqual(result["reconciled"], [])
        self.assertEqual(receipt.read_bytes(), before)
        unaccepted, unaccepted_tree = self.receipt, self.task
        saved = json.loads(unaccepted.read_text())
        saved.update(pr_number=1, writers_released=True)
        unaccepted.write_text(json.dumps(saved))
        unaccepted_before = unaccepted.read_bytes()
        pr = json.loads(self.data.read_text())["pr"]
        self.configure(pr=dict(pr, state="CLOSED"))
        result = self.allocate("closed")
        self.assertEqual(result["reconciled"], [])
        self.assertEqual(receipt.read_bytes(), before)
        self.assertTrue(task.exists())
        self.configure(pr=pr)
        self.merge_pr()
        self.g("worktree", "lock", str(task))
        result = self.allocate("locked")
        self.assertEqual(len(result["reconciled"]), 1)
        self.assertEqual(result["reconciled"][0]["status"], "RETAINED")
        self.assertIn("locked", result["reconciled"][0]["reason"])
        self.assertTrue(task.exists())
        self.g("worktree", "unlock", str(task))
        child = subprocess.Popen([sys.executable, "-c", "import time; time.sleep(30)"], cwd=task)
        try:
            result = self.allocate("active")
            self.assertEqual(len(result["reconciled"]), 1)
            self.assertEqual(result["reconciled"][0]["status"], "RETAINED")
            self.assertIn("active process", result["reconciled"][0]["reason"])
            self.assertTrue(task.exists())
            self.assertIsNone(child.poll())
        finally:
            child.terminate(); child.wait(timeout=5)
        self.assertNotEqual(self.g("branch", "--list", "task/fixture"), "")
        self.assertEqual(self.g("ls-remote", "origin", "refs/heads/task/fixture").split()[0], self.sha)
        self.assertEqual(unaccepted.read_bytes(), unaccepted_before)
        self.assertTrue(unaccepted_tree.exists())

    def test_reconcile_already_retired_tree_and_branch(self):
        self.allocate(); self.accept()
        self.complete("--mode", "pr", "--writers-stopped")
        self.merge_pr()
        receipt, task = self.receipt, self.task
        self.g("worktree", "remove", str(task))
        self.g("update-ref", "-d", "refs/heads/task/fixture", self.sha)
        before = self.anchor_state()
        result = self.allocate("next")
        self.assertEqual([(row["receipt"], row["status"]) for row in result["reconciled"]], [(str(receipt), "COMPLETE")])
        self.assertFalse(task.exists())
        self.assertEqual(self.g("branch", "--list", "task/fixture"), "")
        self.assertEqual(self.g("ls-remote", "origin", "refs/heads/task/fixture"), "")
        self.assertEqual(self.anchor_state(), before)

    def test_reconcile_never_removes_allocation_anchor(self):
        self.allocate(); self.accept()
        self.complete("--mode", "pr", "--writers-stopped")
        self.merge_pr()
        before = self.anchor_state(self.task)
        result, _ = self.cli("allocate", "--repo", self.task, "--task", "next", "--branch", "task/next",
            "--repository", "test/project", "--base", "main", "--worktree", self.root / "next")
        self.assertEqual(result["status"], "ALLOCATED")
        self.assertEqual(len(result["reconciled"]), 1)
        self.assertEqual(result["reconciled"][0]["status"], "RETAINED")
        self.assertIn("anchor", result["reconciled"][0]["reason"])
        self.assertEqual(self.anchor_state(self.task), before)
        self.assertNotEqual(self.g("branch", "--list", "task/fixture"), "")
        self.assertEqual(self.g("ls-remote", "origin", "refs/heads/task/fixture").split()[0], self.sha)

    def test_reconcile_reports_scratch_cleanup_pending(self):
        scratch = Path(self.allocate()["scratch"])
        self.accept()
        self.complete("--mode", "pr", "--writers-stopped")
        self.merge_pr()
        receipt, task = self.receipt, self.task
        (scratch / "object").write_bytes(b"rebuildable")
        child = subprocess.Popen([sys.executable, "-c", "import time; time.sleep(30)"], cwd=scratch)
        try:
            result = self.allocate("next")
            self.assertEqual(len(result["reconciled"]), 1)
            row = result["reconciled"][0]
            self.assertEqual((row["status"], row["delivery_status"]), ("CLEANUP_PENDING", "COMPLETE"))
            self.assertEqual(row["scratch_cleanup"]["status"], "RETAINED")
            self.assertIn("active process", row["scratch_cleanup"]["reason"])
            self.assertEqual((scratch / "object").read_bytes(), b"rebuildable")
            self.assertIsNone(child.poll())
        finally:
            child.terminate(); child.wait(timeout=5)
        self.assertFalse(task.exists())
        self.assertEqual(self.g("branch", "--list", "task/fixture"), "")
        self.assertEqual(self.g("ls-remote", "origin", "refs/heads/task/fixture"), "")
        self.configure(default_branch="changed")
        server = json.loads(self.data.read_text())
        result = self.allocate("retry")
        self.assertEqual([(row["receipt"], row["status"]) for row in result["reconciled"]], [(str(receipt), "COMPLETE")])
        self.assertFalse(any(scratch.iterdir()))
        self.assertEqual(json.loads(self.data.read_text()), server)
        self.assertEqual(self.allocate("later")["reconciled"], [])

    def test_reconcile_retries_unattempted_scratch_cleanup(self):
        scratch = Path(self.allocate()["scratch"])
        self.accept()
        self.complete("--mode", "auto", "--writers-stopped")
        receipt = self.receipt
        saved = json.loads(receipt.read_text())
        del saved["scratch_cleanup"]
        receipt.write_text(json.dumps(saved))
        (scratch / "object").write_bytes(b"rebuildable")
        result = self.allocate("next")
        self.assertEqual([(row["receipt"], row["status"]) for row in result["reconciled"]], [(str(receipt), "COMPLETE")])
        self.assertFalse(any(scratch.iterdir()))

    def test_reconcile_retains_busy_receipt_without_waiting(self):
        self.allocate(); self.accept()
        self.complete("--mode", "pr", "--writers-stopped")
        self.merge_pr()
        code = "import pathlib, runpy, sys, time\nwith runpy.run_path(sys.argv[1])['file_lock'](pathlib.Path(sys.argv[2]), blocking=True):\n print('locked', flush=True)\n time.sleep(30)\n"
        child = subprocess.Popen([sys.executable, "-c", code, str(Path(__file__).resolve().with_name("platform-support.py")),
                                  str(self.receipt.parent / "lock")], stdout=subprocess.PIPE, text=True)
        try:
            self.assertEqual(child.stdout.readline().strip(), "locked")
            process = subprocess.run([sys.executable, str(Path(__file__).resolve()), "allocate", "--repo", str(self.work),
                "--task", "next", "--branch", "task/next", "--repository", "test/project", "--base", "main",
                "--worktree", str(self.root / "next")], cwd=self.root, env=self.env, capture_output=True, text=True, timeout=10)
            self.assertEqual(process.returncode, 0, process.stdout+process.stderr)
            result = json.loads(process.stdout)
            self.assertEqual(result["status"], "ALLOCATED")
            self.assertEqual(len(result["reconciled"]), 1)
            self.assertEqual(result["reconciled"][0]["status"], "RETAINED")
            self.assertIn("lock", result["reconciled"][0]["reason"])
            self.assertTrue(self.task.exists())
            self.assertNotEqual(self.g("branch", "--list", "task/fixture"), "")
            self.assertEqual(self.g("ls-remote", "origin", "refs/heads/task/fixture").split()[0], self.sha)
            self.assertIsNone(child.poll())
        finally:
            child.terminate(); child.wait(timeout=5)
            child.stdout.close()

    def test_reconcile_retains_malformed_receipt_without_failing_allocation(self):
        self.allocate()
        receipt, task = self.receipt, self.task
        receipt.write_text("[]", encoding="utf-8")
        result = self.allocate("next")
        self.assertEqual(result["status"], "ALLOCATED")
        self.assertTrue(self.task.exists())
        self.assertEqual(len(result["reconciled"]), 1)
        self.assertEqual(result["reconciled"][0]["status"], "RETAINED")
        self.assertEqual(result["reconciled"][0]["receipt"], str(receipt))
        self.assertTrue(result["reconciled"][0]["reason"])
        self.assertEqual(receipt.read_text(), "[]")
        self.assertTrue(task.exists())
        self.assertNotEqual(self.g("branch", "--list", "task/fixture"), "")

    def test_records_refuse_symlink_nonregular_and_tampered_resume(self):
        self.allocate(); self.accept()
        self.complete("--mode", "pr", "--writers-stopped")
        self.merge_pr()
        other = self.root / "owner-file"
        other.write_bytes(b"owner data")
        link = self.task / ".devlyn/link"
        link.symlink_to(other)
        result, _ = self.complete(success=False)
        self.assertIn("path escapes custody", result["reason"])
        self.assertTrue(self.task.exists())
        self.assertTrue(link.is_symlink())
        self.assertEqual(other.read_bytes(), b"owner data")
        link.unlink()
        if hasattr(os, "mkfifo"):
            os.mkfifo(link)
            result, _ = self.complete(success=False)
            self.assertIn("regular file", result["reason"])
            self.assertTrue(self.task.exists())
            link.unlink()
        saved = self.receipt.parent / "records/.devlyn"
        shutil.copytree(self.task / ".devlyn", saved)
        (saved / "checks.txt").write_bytes(b"tampered copy")
        result, _ = self.complete(success=False)
        self.assertIn("bytes/mode changed", result["reason"])
        self.assertEqual((saved / "checks.txt").read_bytes(), b"tampered copy")
        self.assertTrue(self.task.exists())
        self.assertNotEqual(self.g("branch", "--list", "task/fixture"), "")
        self.assertEqual(self.g("ls-remote", "origin", "refs/heads/task/fixture").split()[0], self.sha)
        shutil.copy2(self.task / ".devlyn/checks.txt", saved / "checks.txt")
        result, _ = self.complete()
        self.assertEqual(result["status"], "COMPLETE")
        self.assertFalse(self.task.exists())

    def test_linked_custody_and_interrupted_removal(self):
        self.allocate(); self.accept(pipeline=True)
        self.configure(interrupt_remove=True)
        result, r = self.complete("--writers-stopped", "--mode", "auto", success=False)
        self.assertNotEqual(r.returncode, 0)
        self.assertFalse(self.task.exists())
        saved = json.loads(self.receipt.read_text(encoding="utf-8"))
        self.assertNotIn("cleanup_started", saved)
        recovered = self.receipt.parent / "custody" / ".devlyn/runs/fixture-run/final-report.md"
        self.assertEqual(hashlib.sha256(recovered.read_bytes()).hexdigest(), saved["files"][".devlyn/runs/fixture-run/final-report.md"]["sha256"])
        result, _ = self.complete("--writers-stopped", acceptance=False)
        self.assertEqual(result["status"], "COMPLETE")
        self.assertEqual(self.g("show", saved["recovery_ref"]+":product"), "accepted")

    def test_reject_acceptance_and_policy_before_push(self):
        self.allocate(); self.accept(pipeline=True)
        original = json.loads(json.dumps(self.state))
        for case in ("failed", "verify-only", "blocked", "unfinished", "digest", "source"):
            state = json.loads(json.dumps(original))
            if case == "failed": state["phases"]["verify"]["verdict"] = "NEEDS_WORK"
            if case == "verify-only": state["mode"] = "verify-only"
            if case == "blocked": state["phases"]["implement"]["verdict"] = "BLOCKED"
            if case == "unfinished": state["phases"]["verify"]["completed_at"] = None
            if case == "digest": state["phases"]["final_report"]["output_sha256"] = "0"*64
            if case == "source": state["phases"]["cleanup"]["post_sha"] = self.g("rev-parse", "main")
            (self.archive / "pipeline.state.json").write_text(json.dumps(state), encoding="utf-8")
            with self.subTest(case=case):
                _, r = self.complete(success=False)
                self.assertNotEqual(r.returncode, 0)
                self.assertEqual(self.g("ls-remote", "origin", "refs/heads/task/fixture"), "")
        (self.archive / "pipeline.state.json").write_text(json.dumps(original), encoding="utf-8")
        for value in ("typo", "", " auto"):
            self.g("config", "--local", "devlyn.completionMode", value)
            _, r = self.complete("--mode", "pr", success=False)
            self.assertNotEqual(r.returncode, 0)
        result, _ = self.complete("--local-only")
        self.assertEqual(result["status"], "LOCAL_ONLY")
        self.assertEqual(json.loads(self.data.read_text(encoding="utf-8")).get("creates", 0), 0)

    def test_queue_only_and_unverified_descendant(self):
        self.allocate(); self.accept(pipeline=True, queue=True)
        result, _ = self.complete("--mode", "pr")
        self.assertEqual(result["status"], "PR")
        (self.task / "product").write_text("unverified", encoding="utf-8")
        self.g("add", "product", work=self.task)
        self.g("commit", "-m", "unverified", work=self.task)
        _, r = self.complete(success=False)
        self.assertNotEqual(r.returncode, 0)
        self.assertEqual(json.loads(self.data.read_text(encoding="utf-8")).get("merges", 0), 0)

    def test_interrupted_external_effects(self):
        self.allocate(); self.accept()
        for effect in ("push", "create"):
            self.configure(**{"interrupt_"+effect: True})
            _, r = self.complete("--writers-stopped", "--mode", "auto", success=False)
            self.assertNotEqual(r.returncode, 0)
        # A merge command that fails after merging is judged by the PR state, not its exit code.
        self.configure(interrupt_merge=True)
        result, _ = self.complete("--writers-stopped")
        self.assertEqual(result["status"], "COMPLETE")
        d = json.loads(self.data.read_text(encoding="utf-8"))
        self.assertEqual((d["pushs"], d["creates"], d["merges"]), (1, 1, 1))

    def test_retains_dirty_locked_and_active_tree(self):
        self.allocate(); self.accept()
        for case in ("no-yield", "dirty", "untracked", "locked", "cwd"):
            path = self.task / ("product" if case == "dirty" else "unknown")
            if case in {"dirty", "untracked"}:
                path.parent.mkdir(exist_ok=True); path.write_text("do not delete", encoding="utf-8")
            if case == "locked": self.g("worktree", "lock", str(self.task))
            with self.subTest(case=case):
                _, r = self.complete("--mode", "auto", *([] if case == "no-yield" else ["--writers-stopped"]), cwd=self.task if case == "cwd" else None, success=False)
                self.assertNotEqual(r.returncode, 0)
                self.assertTrue(self.task.exists())
                self.assertNotEqual(self.g("branch", "--list", "task/fixture"), "")
            if case == "untracked": path.unlink()
            if case == "dirty": path.write_text("accepted\n", encoding="utf-8")
            if case == "locked": self.g("worktree", "unlock", str(self.task))

    def test_no_adoption_and_remote_head_race(self):
        _, r = self.cli("allocate", "--repo", self.work, "--task", "foreign", "--branch", "main", "--repository", "test/project", "--base", "main", "--worktree", self.root / "foreign", success=False)
        self.assertNotEqual(r.returncode, 0)
        self.allocate(); self.accept()
        self.complete("--mode", "pr")
        self.run_cmd(["git", "--git-dir", str(self.bare), "update-ref", "refs/heads/task/fixture", self.g("rev-parse", "main")])
        _, r = self.complete(success=False)
        self.assertNotEqual(r.returncode, 0)
        self.assertEqual(json.loads(self.data.read_text(encoding="utf-8")).get("merges",0), 0)

    def test_concurrent_completions(self):
        self.allocate(); self.accept(); self.configure(pending=True)
        args = [sys.executable, str(Path(__file__).resolve()), "complete", "--receipt", str(self.receipt), "--acceptance", str(self.acceptance), "--mode", "auto"]
        procs = [subprocess.Popen(args, cwd=self.root, env=self.env, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, encoding="utf-8") for _ in range(2)]
        for proc in procs:
            out, err = proc.communicate(timeout=30)
            self.assertEqual(proc.returncode, 0, out+err)
        d = json.loads(self.data.read_text(encoding="utf-8"))
        self.assertEqual((d["pushs"], d["creates"], d["merges"]), (1,1,1))

    def test_custody_failure_and_evidence_tamper(self):
        self.allocate(); self.accept()
        bad = self.receipt.parent / "custody/.devlyn/checks.txt"
        bad.parent.mkdir(parents=True)
        bad.write_text("partial interrupted copy", encoding="utf-8")
        _, r = self.complete("--writers-stopped", success=False)
        self.assertNotEqual(r.returncode, 0)
        self.assertTrue(self.task.exists())
        self.assertEqual((self.task / ".devlyn/checks.txt").read_text(encoding="utf-8"), "actual fixture check: accepted bytes\n")
        self.assertEqual(self.g("ls-remote", "origin", "refs/heads/task/fixture"), "")
        bad.unlink()  # Owner repairs only the identified corrupt fixture copy.
        self.complete("--mode", "pr")
        (self.task / ".devlyn/checks.txt").write_text("altered after acceptance", encoding="utf-8")
        _, r = self.complete("--mode", "auto", success=False)
        self.assertNotEqual(r.returncode, 0)
        self.assertEqual(json.loads(self.data.read_text(encoding="utf-8")).get("merges",0), 0)

    def test_actual_foreign_writer_and_registration(self):
        self.allocate(); self.accept()
        child = subprocess.Popen([sys.executable, "-c", "import time; time.sleep(30)"], cwd=self.task)
        try:
            _, r = self.complete("--writers-stopped", "--mode", "auto", success=False)
            self.assertNotEqual(r.returncode, 0)
            self.assertTrue(self.task.exists())
            self.assertIn("active process", json.loads(r.stdout)["reason"])
        finally:
            child.terminate(); child.wait(timeout=5)
        # A foreign branch in the same registered tree never inherits ownership.
        self.g("switch", "-c", "foreign", work=self.task)
        _, r = self.complete("--writers-stopped", success=False)
        self.assertNotEqual(r.returncode, 0)
        self.assertTrue(self.task.exists())
        self.assertNotEqual(self.g("branch", "--list", "task/fixture"), "")

    def test_remote_compare_delete_race(self):
        self.allocate(); self.accept()
        race = self.g("rev-parse", "main")
        self.configure(remote_delete_race=True, race_sha=race)
        _, r = self.complete("--writers-stopped", "--mode", "auto", success=False)
        self.assertNotEqual(r.returncode, 0)
        self.assertEqual(self.g("ls-remote", "origin", "refs/heads/task/fixture").split()[0], race)
        self.assertNotEqual(self.g("branch", "--list", "task/fixture"), "")

    def test_policy_and_local_only_persist(self):
        self.allocate(); self.accept()
        self.configure(merge_allowed=False)
        result, _ = self.complete()
        self.assertEqual((result["status"], result["merge_refused"]), ("PR", "repository disallows merge commits"))
        d = json.loads(self.data.read_text(encoding="utf-8"))
        self.assertEqual((d.get("pushs", 0), d.get("merges", 0)), (1, 0))
        self.complete("--mode", "pr")
        result, _ = self.complete()
        self.assertEqual(result["status"], "PR")
        self.assertNotIn("merge_refused", result)
        self.configure(merge_allowed=True, auto_allowed=False, pending=True)
        result, _ = self.complete("--mode", "auto")
        self.assertEqual(result["status"], "PR")
        self.assertIn("disallows auto merge", result["merge_refused"])
        self.assertTrue(self.task.exists())
        result, _ = self.complete("--no-push")
        self.assertEqual(result["status"], "LOCAL_ONLY")
        result, _ = self.complete(acceptance=False)
        self.assertEqual(result["status"], "LOCAL_ONLY")

    def test_queue_commit_cannot_hide_product_changes(self):
        self.allocate(); self.accept(pipeline=True, queue=True)
        (self.task / "product").write_text("unverified extra\n", encoding="utf-8")
        self.g("add", "product", work=self.task)
        self.g("commit", "--amend", "--no-edit", work=self.task)
        a = json.loads(self.acceptance.read_text(encoding="utf-8"))
        a["queue"]["commit"] = self.g("rev-parse", "HEAD", work=self.task)
        self.acceptance.write_text(json.dumps(a), encoding="utf-8")
        _, r = self.complete(success=False)
        self.assertNotEqual(r.returncode, 0)
        self.assertEqual(json.loads(self.data.read_text(encoding="utf-8")).get("pushs",0), 0)

    def test_pipeline_sealed_process_evidence(self):
        self.allocate(); self.accept(pipeline=True)
        evidence_module = shared("process-evidence")
        obligation = {"id": "actual-check", "phase": "verify", "argv": [sys.executable, "-c", "print('fixture passed')"], "exit_code": 0, "stdout_contains": ["fixture passed"], "timeout_sec": 10}
        relative = ".devlyn/process-evidence/fixture-run/verify/round-0/manifest.json"
        evidence_module["capture_process"](self.task, self.task / relative, "fixture-run", "verify", 0, obligation)
        carrier = evidence_module["validate_manifest"](self.task, relative, "fixture-run", "verify", 0, [obligation])
        results = {"commands": evidence_module["bound_carrier_summary_commands"](self.task, carrier), "process_evidence": carrier}
        self.state["phases"]["verify"]["round"] = 0
        self.state["process_evidence"] = [carrier]
        (self.archive / "pipeline.state.json").write_text(json.dumps(self.state), encoding="utf-8")
        (self.archive / "spec-verify.results.json").write_text(json.dumps(results), encoding="utf-8")
        shutil.move(str(self.task / ".devlyn/process-evidence"), str(self.archive / "process-evidence"))
        stdout = self.archive / carrier["streams"][0]["stdout"]["path"].removeprefix(".devlyn/")
        before = stdout.read_bytes()
        stdout.write_text("tampered", encoding="utf-8")
        _, r = self.complete(success=False)
        self.assertNotEqual(r.returncode, 0)
        self.assertEqual(json.loads(self.data.read_text(encoding="utf-8")).get("pushs",0), 0)
        stdout.write_bytes(before)
        result, _ = self.complete("--mode", "pr")
        self.assertEqual(result["status"], "PR")

    def test_legacy_in_place_resume_does_not_overwrite_ignored_collision(self):
        self.allocate_legacy(); self.accept()
        self.complete("--mode", "pr", "--writers-stopped")
        self.merge_pr()
        self.g("switch", "main")
        user_file = self.task / "ignored/user.txt"
        user_file.parent.mkdir()
        user_file.write_text("retained user data", encoding="utf-8")
        before = self.anchor_state()
        self.configure(interrupt_delete=True)
        _, r = self.complete(acceptance=False, success=False)
        self.assertNotEqual(r.returncode, 0)
        self.assertEqual(self.anchor_state(), before)
        other = self.root / "advance"
        self.run_cmd(["git", "clone", str(self.bare), str(other)])
        (other / "ignored").mkdir()
        (other / "ignored/user.txt").write_text("new upstream tracked file", encoding="utf-8")
        self.g("add", "-f", "ignored/user.txt", work=other)
        self.g("commit", "-m", "upstream collision", work=other)
        self.g("push", "origin", "main", work=other)
        result, _ = self.complete(acceptance=False)
        self.assertEqual(result["status"], "COMPLETE")
        self.assertEqual(self.anchor_state(), before)
        self.assertEqual(user_file.read_text(encoding="utf-8"), "retained user data")
        self.assertEqual(self.g("branch", "--list", "task/fixture"), "")
        self.assertEqual(self.g("ls-remote", "origin", "refs/heads/task/fixture"), "")

    def test_replaced_tree_and_unsafe_custody(self):
        self.allocate(); self.accept()
        elsewhere = self.root / "elsewhere"
        elsewhere.mkdir()
        (self.receipt.parent / "custody").symlink_to(elsewhere, target_is_directory=True)
        _, r = self.complete(success=False)
        self.assertNotEqual(r.returncode, 0)
        self.assertEqual(list(elsewhere.iterdir()), [])
        (self.receipt.parent / "custody").unlink()
        old = self.root / "old-tree"
        self.task.rename(old)
        shutil.copytree(old, self.task)
        _, r = self.complete(success=False)
        self.assertNotEqual(r.returncode, 0)
        self.assertIn("replaced", json.loads(r.stdout)["reason"])
        self.assertTrue(self.task.exists())
        self.assertEqual(json.loads(self.data.read_text(encoding="utf-8")).get("pushs",0), 0)

    def test_spec_source_and_report_binding(self):
        self.allocate(); self.accept(pipeline=True, spec_expected={"verification_commands": []})
        report = self.archive / "final-report.md"
        original = report.read_bytes()
        report.write_text("<!-- devlyn:final-report run_id=another-run -->\nBody\n", encoding="utf-8")
        self.state["phases"]["final_report"]["output_sha256"] = hashlib.sha256(report.read_bytes()).hexdigest()
        (self.archive / "pipeline.state.json").write_text(json.dumps(self.state), encoding="utf-8")
        _, r = self.complete(success=False)
        self.assertNotEqual(r.returncode, 0)
        self.assertEqual(json.loads(self.data.read_text(encoding="utf-8")).get("pushs",0), 0)
        report.write_bytes(original)
        self.state["phases"]["final_report"]["output_sha256"] = hashlib.sha256(original).hexdigest()
        (self.archive / "pipeline.state.json").write_text(json.dumps(self.state), encoding="utf-8")
        result, _ = self.complete("--mode", "pr")
        self.assertEqual(result["status"], "PR")

    def test_missing_required_process_evidence(self):
        expected = {"process_evidence": [{"id": "red-first", "phase": "implement", "argv": [sys.executable, "-c", "print('red')"], "exit_code": 0, "timeout_sec": 10}]}
        self.allocate(); self.accept(pipeline=True, spec_expected=expected)
        _, r = self.complete(success=False)
        self.assertNotEqual(r.returncode, 0)
        self.assertIn("implement process evidence", json.loads(r.stdout)["reason"])
        self.assertEqual(json.loads(self.data.read_text(encoding="utf-8")).get("pushs",0), 0)

    def test_named_spec_custody(self):
        self.allocate(); self.accept(pipeline=True, spec_expected={"pure_design": True}, spec_name="X.md")
        result, _ = self.complete("--mode", "pr")
        self.assertEqual(result["status"], "PR")
        receipt = json.loads(self.receipt.read_text(encoding="utf-8"))
        self.assertIn("spec.expected.json", receipt["files"])
        self.assertEqual((self.receipt.parent / "custody/spec.expected.json").read_bytes(), (self.task / "spec.expected.json").read_bytes())

    def test_named_spec_missing_required_process_evidence(self):
        expected = {"process_evidence": [{"id": "red-first", "phase": "implement", "argv": [sys.executable, "-c", "print('red')"], "exit_code": 0, "timeout_sec": 10}]}
        self.allocate(); self.accept(pipeline=True, spec_expected=expected, spec_name="X.md")
        _, r = self.complete(success=False)
        self.assertNotEqual(r.returncode, 0)
        self.assertIn("implement process evidence", json.loads(r.stdout)["reason"])
        self.assertEqual(json.loads(self.data.read_text(encoding="utf-8")).get("pushs",0), 0)


if __name__ == "__main__":
    runpy.run_path(str(Path(__file__).with_name("platform-support.py")))["configure_utf8"]()
    sys.exit(main())
