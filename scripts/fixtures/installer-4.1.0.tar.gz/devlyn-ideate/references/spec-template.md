# Canonical spec template

The shape `/devlyn-ideate` writes and `/devlyn-resolve --spec` consumes. Single source of truth for spec structure.

## Frontmatter

```yaml
---
id: "<spec-id>"          # kebab-case, unique per spec-dir; auto-generated if user omits
title: "<short title>"    # one line, descriptive
kind: feature             # feature | spike | prototype
status: planned           # planned → in_progress → done. ideate writes "planned"; resolve's CLEANUP flips to "done".
complexity: medium        # trivial | medium | high. Use high when Verification needs compound state/order/failure checks.
depends_on: []            # list of spec ids this depends on (empty for standalone). project mode populates this.
---
```

## `# <title>`

Top-level heading repeats the title.

## `## Context`

2-4 sentences answering "why does this exist." User-facing motivation, not implementation detail. Traceable to whatever the user said during elicitation.

## `## Requirements`

Checklist of testable, scoped statements. Each bullet is one observable behavior:

```markdown
- [ ] `node bin/cli.js doctor` exits 0 on a clean machine.
- [ ] `--verbose` lists installed plugins by name.
- [ ] Exit code is `1` when any FAIL line appears.
```

Rules:
- Each Requirement is independently verifiable (a command, a test, a file existence check).
- Avoid implementation language ("use a try/catch") in Requirements; that goes in Constraints.
- Pure-design Requirements are allowed (e.g. "follow the existing pattern in `lib/X.js`") but mark them "design-only" so Verification can be omitted for that bullet.

## `## Constraints`

Concrete rules with reasoning. Examples:

```markdown
- **Zero new npm dependencies.** Use only Node.js built-ins.
- **No silent error catches.** Errors must be visible to the user with actionable messages.
- **Touch only `bin/cli.js` and `tests/cli.test.js`.** Other files are out of scope.
```

Each constraint has a one-line "why" — bare constraints invite negotiation; reasoned constraints lock the contract.

## `## Out of Scope`

Explicit "must NOT build" list. Examples:

```markdown
- Auto-repair (report only).
- Checking remote/registry state.
- Refactoring the argument parser.
```

If the spec is small enough that nothing meaningful is out of scope, write `- (nothing notable; see Constraints for boundary)`.

## `## Verification`

Immediately precede the heading with a `<!-- devlyn:verification -->` sentinel
comment on its own line, directly above `## Verification` (no blank line
between them). This is the machine locator `spec-verify-check.py` uses to
find the section — it is language-neutral: the heading text after the
sentinel may be any human language (`## Verification`, `## 검증`, etc.); only
the sentinel itself is fixed ASCII and must never be translated.

Concrete commands or tests whose expected behavior names the success condition:

```markdown
<!-- devlyn:verification -->
## Verification

- `node bin/cli.js doctor` exits 0; output contains `doctor:`.
- `HOME=/nonexistent node bin/cli.js doctor` exits 1; output mentions `/nonexistent`.
- `node --test tests/cli.test.js` passes.
- `git diff -- package.json` is empty.
```

The body of the section reads humanely; the machine-readable contract lives in `spec.expected.json` (sibling file). Each command in this section maps to one entry in `spec.expected.json.verification_commands`.

If all Requirements are pure-design (no observable runtime check), the body of this section is a single descriptive line (e.g. `- No runtime verification commands.`) and sibling `spec.expected.json` declares `"pure_design": true` instead of listing `verification_commands`.

## Sibling file: `spec.expected.json`

Schema: `_shared/expected.schema.json`. Required when Requirements have observable checks; optional when all Requirements are pure-design (declare `"pure_design": true` in that case — contradictory, and rejected, alongside a non-empty `verification_commands`). Validate before announcing ready:

```bash
python3 "$DEVLYN_SHARED_DIR/spec-verify-check.py" --check-expected <expected-path>
```

Map mechanically decidable rules from both Requirements and Constraints into the existing carriers. Preserve specific file constraints even when narrower than PLAN's scope. During BUILD_GATE, with `state.base_ref.sha` recorded, the existing `authorized_surface` check enforces PLAN's scope over the run diff and newly created untracked paths (`.devlyn/` exempt). Do not duplicate this general scope check with a whole-checkout scan in `verification_commands`. Validate each new guard with a violating control that fails and an allowed control that passes, preserving permitted pre-existing occurrences:
- `verification_commands` ← `## Verification` + commands the conversation surfaced. While drafting both Verification and its carrier, omit a standalone check only when another command in that contract runs the same assertions under the required execution conditions and propagates failure; describe that shared coverage in Verification and keep both carriers aligned. Preserve distinct scenarios and required independent verification; execute approved commands unchanged without reusing results across phases. For semantic annotation or exception-handling rules, use a suitable syntax-aware/executable check, preferring existing checks; explicitly retain uncovered semantics as source-review obligations.
- `forbidden_patterns` ← literal syntax constraints only; regex does not prove semantics. It scans the whole file-filtered diff, including context, deletions and headers; additions-only guards must exclude those lines.
- `required_files` / `forbidden_files` ← literal file paths from Requirements, Constraints and Out of Scope; `forbidden_files` matches exact Git-relative paths (forward slashes, no leading `./`), including both names of a rename. Globs and directory-wide exclusions need a suitable `verification_commands` guard, not wildcard-looking entries in these lists.
- `max_deps_added` ← dependency limits in Requirements or Constraints (default 0 unless the spec licenses a new dep).
- `required_risk_probe_requirements` ← for specs where a Requirement combines ordering/priority, rollback, idempotency, auth/signature, concurrency, atomic-batch, or exact output shape, declare the risk categories PHASE 1.5 risk-probe derivation must cover directly, e.g. `[{"tag": "rollback_state", "derived_from": "<exact ## Verification bullet>"}]`. This replaces guessing the required categories from prose — declare them explicitly so the check works in any language. `tag` must be one of the risk-probe tags in `_shared/spec-verify-check.py:RISK_PROBE_TAGS`; `derived_from` must be an exact substring of `## Verification`. Omit entirely when the spec has no ordering/rollback/idempotency/auth/concurrency/atomic-batch/exact-shape risk.

## Quality bar (lint enforces structurally; ideate enforces substantively)

Structural (lint):
- Frontmatter valid + required fields present.
- All five H2 sections present.
- Requirements has ≥ 1 bullet.
- Verification has either commands or `spec.expected.json` declares `"pure_design": true`.

Substantive (ideate's job during elicitation):
- Each Requirement is independently verifiable.
- Each Constraint has a reasoning clause.
- Out of Scope explicitly enumerates non-goals.
- Verification commands actually verify the Requirement they map to (no "looks plausible" verification).
- Avoid formatter-sensitive single-line adjacency checks — prefer a semantic test (runtime, DB, or CLI check), or grep one stable line-local anchor and assert required context separately.
- Frontmatter `complexity` reflects verification shape: `high` when the spec combines state mutation with ordering/priority, idempotency, auth/error priority, rollback/failure handling, or exact output shape; `medium` for ordinary multi-step work; `trivial` only for a single localized behavior.
- When Requirements combine state mutation, ordering/priority, idempotency, auth/error priority, or exact output shape, Verification includes at least one compound scenario that exercises the interaction end-to-end; isolated happy paths are insufficient.
- Spec text is plain language — no jargon walls, no "for future flexibility" hedging.
